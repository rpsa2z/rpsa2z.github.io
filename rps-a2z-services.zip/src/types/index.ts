export type CategoryId =
  | 'printing'
  | 'photo-printing'
  | 'photo-frames'
  | 'customized-gifts'
  | 'stationery'
  | 'id-cards'
  | 'visiting-cards'
  | 'banners-flex'
  | 'tshirt-printing'
  | 'mug-printing'
  | 'mobile-covers'
  | 'keychains'
  | 'wedding-cards'
  | 'office-school'
  | 'digital-services'
  | 'document-services'
  | 'custom-order';

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  iconName: string;
  itemCount: number;
  description?: string;
  isPopular?: boolean;
}

export interface PrintingCustomizationOptions {
  uploadedFile?: {
    name: string;
    size: string;
    type: string;
    url?: string;
    dataUrl?: string;
  };
  customText?: string;
  orientation?: 'Portrait' | 'Landscape' | 'portrait' | 'landscape';
  printSize: 'A4' | 'A3' | '12x18' | 'Letter' | 'Legal' | 'Custom';
  paperType?: 'Bond' | 'Art Paper' | 'Glossy' | 'Matte' | 'Ivory' | 'Sticker Paper';
  paperGsm: '75 GSM' | '100 GSM' | '130 GSM' | '170 GSM' | '250 GSM' | '300 GSM';
  printType?: 'single-side' | 'double-side';
  colorType?: 'bw' | 'color';
  lamination?: 'none' | 'gloss' | 'matte' | 'velvet';
  binding?: 'none' | 'spiral' | 'wiro' | 'hardbound' | 'staple';
  quantity?: number;
  copies?: number;
  specialInstructions?: string;
  calculatedPricePerUnit?: number;
}

export interface PhotoFrameCustomizationOptions {
  size: string;
  frameColor: 'Black' | 'Walnut Brown' | 'Classic Gold' | 'Crisp White' | 'Rose Gold' | 'Teak Wood' | string;
  frameDesign: 'Minimalist Sleek' | 'Classic Carved' | 'Deep Box Frame' | 'Floating Border' | 'Vintage Ornate' | string;
  hasGlass?: boolean;
  glassType?: string;
  matteBorder?: string;
  orientation?: 'Portrait' | 'Landscape' | 'portrait' | 'landscape';
  photoUrl?: string;
  uploadedPhotoUrl?: string;
  uploadedPhotoName?: string;
  customMessage?: string;
  quantity?: number;
  calculatedPrice?: number;
}

export type PhotoFrameConfig = PhotoFrameCustomizationOptions;

export interface ProductCustomization {
  type: 'printing' | 'photo_frame' | 'standard_custom' | 'none';
  printingConfig?: PrintingCustomizationOptions;
  photoFrameConfig?: PhotoFrameCustomizationOptions;
  standardCustomText?: string;
  standardUploadedImageUrl?: string;
  customText?: string;
  uploadedImages?: string[];
  notes?: string;
}

export interface Product {
  id: string; // e.g. "RPS-PRD-101"
  sku: string;
  name: string;
  category: string;
  subCategory?: string;
  mrp: number;
  price: number;
  discountPercentage: number;
  rating: number;
  reviewsCount: number;
  stock: number;
  minQuantity: number;
  maxQuantity: number;
  images: string[];
  description: string;
  features: string[];
  specifications: Record<string, string>;
  isCustomizable: boolean;
  customizationType: 'printing' | 'photo_frame' | 'standard_custom' | 'none';
  availableSizes?: string[];
  availableColors?: string[];
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isTodayDeal?: boolean;
  dealEndsAt?: string;
  deliveryDays: number;
}

export interface CartItem {
  cartItemId: string;
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  customization?: ProductCustomization;
  unitPrice: number;
  totalPrice: number;
}

export type OrderStatus =
  | 'Order Placed'
  | 'Payment Confirmed'
  | 'Order Accepted'
  | 'Design Pending'
  | 'Design Ready'
  | 'Design Approved'
  | 'Printing Started'
  | 'Processing'
  | 'Ready For Dispatch'
  | 'Assigned To Delivery Boy'
  | 'Out For Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Rejected';

export interface TrackingStep {
  status: OrderStatus;
  date: string;
  time: string;
  message: string;
  completed: boolean;
  isCurrent: boolean;
}

export interface DesignProof {
  proofId: string;
  proofUrl: string;
  uploadedAt: string;
  adminNote?: string;
  status: 'Pending Customer Approval' | 'Approved' | 'Changes Requested';
  customerComment?: string;
  respondedAt?: string;
}

export type PaymentMethod =
  | 'COD'
  | 'UPI'
  | 'QR Code'
  | 'GPay'
  | 'PhonePe'
  | 'Paytm'
  | 'Net Banking'
  | 'Debit/Credit Card'
  | 'Manual Verification'
  | 'Card'
  | 'NetBanking';

export interface CustomerAddress {
  fullName: string;
  mobile: string;
  altMobile?: string;
  email: string;
  house: string;
  street: string;
  area: string;
  landmark?: string;
  city: string;
  district: string;
  state: string;
  pinCode: string;
}

export interface Order {
  id: string; // ORDRPS000001
  createdAt: string;
  customerName: string;
  customerMobile: string;
  customerEmail: string;
  customerAddress: CustomerAddress;
  billingAddressSameAsShipping: boolean;
  items: CartItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  deliveryCharge: number;
  gstAmount: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'Pending' | 'Verified' | 'Paid' | 'Failed';
  manualPaymentDetails?: {
    transactionId: string;
    paymentScreenshotUrl?: string;
    paymentDate: string;
    amount: number;
  };
  orderStatus: OrderStatus;
  trackingHistory: TrackingStep[];
  assignedDeliveryBoyId?: string;
  assignedDeliveryBoyName?: string;
  assignedDeliveryBoy?: {
    id: string;
    name: string;
    mobile: string;
    vehicle?: string;
  };
  deliveryOtp?: string;
  expectedDeliveryDate: string;
  adminRemarks?: string;
  designProof?: DesignProof;
}

export interface CustomOrder {
  id: string; // CUS000001
  createdAt: string;
  customerName: string;
  customerMobile: string;
  customerEmail: string;
  serviceOrProductName: string;
  category: string;
  requiredQuantity: number;
  requiredSize: string;
  requiredDate: string;
  budget: number;
  attachmentName?: string;
  attachmentDataUrl?: string;
  orderDescription: string;
  specialInstructions?: string;
  deliveryAddress: string;
  status: 'Received' | 'Quoted' | 'In Review' | 'Accepted' | 'Rejected' | 'Converted to Order';
  quotedPrice?: number;
  adminRemark?: string;
  convertedOrderId?: string;
}

export interface DeliveryBoy {
  id: string;
  name: string;
  mobile: string;
  aadhaarNumber?: string;
  email?: string;
  address?: string;
  userId?: string;
  active?: boolean;
  assignedOrderCount?: number;
  activeOrdersCount?: number;
  vehicle?: string;
  status?: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  discountBadge: string;
  image: string;
  buttonText: string;
  targetCategoryOrProduct: string;
  active: boolean;
  bgGradient: string;
}

export interface Coupon {
  code: string;
  discountType: 'flat' | 'percentage';
  value: number; // e.g. 50 flat or 15%
  minOrder: number;
  maxDiscount?: number;
  expiryDate: string;
  active: boolean;
  description: string;
}

export interface CustomerReview {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
  photoUrl?: string;
  approved: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: 'order' | 'offer' | 'design' | 'system';
  relatedId?: string;
}

export interface WebsiteSettings {
  businessName: string;
  tagline: string;
  mobileNumber: string;
  whatsappNumber: string;
  email: string;
  businessAddress: string;
  googleMapUrl: string;
  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  freeDeliveryThreshold: number;
  defaultDeliveryCharge: number;
  gstRatePercentage: number;
}
