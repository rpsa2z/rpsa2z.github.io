import React, { useEffect } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/layout/Header';
import { CategoryNav } from './components/layout/CategoryNav';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { Footer } from './components/layout/Footer';
import { ToastContainer } from './components/common/ToastContainer';
import { WhatsAppFloating } from './components/common/WhatsAppFloating';
import { QuickViewModal } from './components/common/QuickViewModal';
import { LocationModal } from './components/common/LocationModal';

// Pages
import { HomePage } from './components/pages/HomePage';
import { ProductListingPage } from './components/pages/ProductListingPage';
import { ProductDetailPage } from './components/pages/ProductDetailPage';
import { PhotoFrameCustomizerPage } from './components/pages/PhotoFrameCustomizerPage';
import { CustomOrderPage } from './components/pages/CustomOrderPage';
import { DigitalServicesPage } from './components/pages/DigitalServicesPage';
import { CartPage } from './components/pages/CartPage';
import { CheckoutPage } from './components/pages/CheckoutPage';
import { OrderTrackingPage } from './components/pages/OrderTrackingPage';
import { MyOrdersPage } from './components/pages/MyOrdersPage';
import { CustomerDashboardPage } from './components/pages/CustomerDashboardPage';
import { AboutContactPage } from './components/pages/AboutContactPage';
import { AdminDashboardPage } from './components/admin/AdminDashboardPage';
import { DeliveryBoyPage } from './components/delivery/DeliveryBoyPage';

const MainLayout: React.FC = () => {
  const { currentPage } = useStore();

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'products':
        return <ProductListingPage />;
      case 'product-detail':
        return <ProductDetailPage />;
      case 'photo-frame-customizer':
        return <PhotoFrameCustomizerPage />;
      case 'custom-order':
        return <CustomOrderPage />;
      case 'digital-services':
        return <DigitalServicesPage />;
      case 'cart':
        return <CartPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'order-tracking':
        return <OrderTrackingPage />;
      case 'my-orders':
        return <MyOrdersPage />;
      case 'customer-dashboard':
        return <CustomerDashboardPage />;
      case 'about-contact':
        return <AboutContactPage />;
      case 'admin-dashboard':
        return <AdminDashboardPage />;
      case 'delivery-portal':
        return <DeliveryBoyPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased selection:bg-red-500 selection:text-white">
      {/* Universal Header */}
      <Header />

      {/* Horizontal Category Navigation Bar */}
      <CategoryNav />

      {/* Dynamic View Content */}
      <main className="flex-1 w-full">
        {renderPage()}
      </main>

      {/* Comprehensive Brand Footer */}
      <Footer />

      {/* Fixed UI Floating Helpers & Modals */}
      <MobileBottomNav />
      <WhatsAppFloating />
      <QuickViewModal />
      <LocationModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainLayout />
    </StoreProvider>
  );
}
