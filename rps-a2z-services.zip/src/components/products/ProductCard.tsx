import React from 'react';
import { Product } from '../../types';
import { useStore } from '../../context/StoreContext';
import { Star, Heart, Eye, Share2, ShoppingCart, Zap, CheckCircle2, AlertCircle } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    setSelectedProductId,
    setCurrentPage,
    addToCart,
    toggleWishlist,
    isInWishlist,
    setQuickViewProduct,
    addToast,
  } = useStore();

  const isFavorite = isInWishlist(product.id);

  const handleCardClick = () => {
    setSelectedProductId(product.id);
    if (product.customizationType === 'photo_frame') {
      setCurrentPage('photo-frame-customizer');
    } else {
      setCurrentPage('product-detail');
    }
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator
        .share({
          title: product.name,
          text: `Check out ${product.name} on RPS A2Z SERVICES for ₹${product.price}!`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      addToast('Link Copied', 'Product link copied to clipboard.');
    }
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.customizationType === 'photo_frame') {
      setSelectedProductId(product.id);
      setCurrentPage('photo-frame-customizer');
    } else if (product.isCustomizable) {
      setSelectedProductId(product.id);
      setCurrentPage('product-detail');
    } else {
      addToCart(product, 1);
      setCurrentPage('checkout');
    }
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.customizationType === 'photo_frame') {
      setSelectedProductId(product.id);
      setCurrentPage('photo-frame-customizer');
    } else if (product.isCustomizable) {
      setSelectedProductId(product.id);
      setCurrentPage('product-detail');
    } else {
      addToCart(product, 1);
    }
  };

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={handleCardClick}
      className="bg-white p-3 rounded-xl border border-slate-200 group hover:shadow-xl transition-all relative flex flex-col justify-between cursor-pointer"
    >
      {/* Discount Badge */}
      {product.discountPercentage > 0 && (
        <div className="absolute top-3 left-3 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-md z-10 shadow-xs">
          -{product.discountPercentage}% OFF
        </div>
      )}

      {/* Wishlist Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          toggleWishlist(product.id);
        }}
        className={`absolute top-3 right-3 z-10 transition p-1 rounded-full bg-white/80 backdrop-blur-xs ${
          isFavorite ? 'text-red-600' : 'text-slate-400 hover:text-red-500'
        }`}
        aria-label="Wishlist"
      >
        <Heart className={`w-4 h-4 ${isFavorite ? 'fill-red-600 text-red-600' : ''}`} />
      </button>

      <div>
        {/* Product Image */}
        <div className="w-full aspect-square bg-slate-100 rounded-lg mb-3 flex items-center justify-center overflow-hidden relative">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
          {product.isBestSeller && (
            <span className="absolute bottom-2 left-2 bg-amber-500 text-slate-900 text-[9px] font-black px-1.5 py-0.5 rounded shadow-xs uppercase">
              Best Seller
            </span>
          )}
        </div>

        {/* Category */}
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">
          {product.category.replace('-', ' ')}
        </p>

        {/* Title */}
        <h4 className="text-sm font-bold text-slate-800 mb-1 leading-snug line-clamp-2 group-hover:text-blue-600 transition">
          {product.name}
        </h4>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          <span className="text-xs text-yellow-500 font-bold">{product.rating}</span>
          <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
          <span className="text-[10px] text-slate-400">({product.reviewsCount})</span>
          {product.isCustomizable && (
            <span className="ml-auto text-[9px] font-bold text-blue-600 bg-blue-50 px-1 py-0.5 rounded">
              Customizable
            </span>
          )}
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-lg font-black text-slate-900">₹{product.price}</span>
          <span className="text-xs text-slate-400 line-through">₹{product.mrp}</span>
        </div>
      </div>

      {/* High Density CTA Buttons */}
      <div className="flex items-center gap-2 mt-1">
        <button
          onClick={handleAddToCart}
          className="flex-1 bg-blue-600 text-white text-xs font-bold py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-xs flex items-center justify-center gap-1.5"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>{product.isCustomizable ? 'Customize' : 'Add to Cart'}</span>
        </button>

        <button
          onClick={handleBuyNow}
          className="bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-600 font-bold py-2 px-2.5 rounded-lg text-xs transition"
          title="Instant Checkout"
        >
          <Zap className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
