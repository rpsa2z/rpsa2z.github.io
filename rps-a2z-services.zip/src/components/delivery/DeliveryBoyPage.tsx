import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Bike,
  Phone,
  MapPin,
  CheckCircle2,
  Clock,
  DollarSign,
  Package,
  Navigation,
  KeyRound,
  LogOut,
  AlertCircle,
} from 'lucide-react';

export const DeliveryBoyPage: React.FC = () => {
  const {
    deliveryBoyLoggedIn,
    loginDeliveryBoy,
    logoutDeliveryBoy,
    orders,
    updateOrderStatus,
    addToast,
    setCurrentPage,
  } = useStore();

  const [mobileInput, setMobileInput] = useState('9876543210');
  const [passInput, setPassInput] = useState('rider123');
  const [otpMap, setOtpMap] = useState<{ [orderId: string]: string }>({});

  if (!deliveryBoyLoggedIn) {
    const handleLogin = (e: React.FormEvent) => {
      e.preventDefault();
      if (loginDeliveryBoy(mobileInput, passInput)) {
        addToast('Rider Logged In', 'Welcome, Suraj Kumar (Hero Splendor UP 32 AZ 1001)');
      } else {
        addToast('Login Failed', 'Try Demo: 9876543210 / rider123');
      }
    };

    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-slate-200 shadow-xl text-xs space-y-4">
        <div className="text-center">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Bike className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black text-slate-900">RPS Rider Dispatch App</h2>
          <p className="text-slate-500 mt-1">Delivery partner portal for order route & cash collection</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-3 pt-2">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Registered Mobile Number</label>
            <input
              type="tel"
              required
              value={mobileInput}
              onChange={(e) => setMobileInput(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Password</label>
            <input
              type="password"
              required
              value={passInput}
              onChange={(e) => setPassInput(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <p className="text-[11px] text-slate-400">Demo Rider: <strong>9876543210</strong> / <strong>rider123</strong></p>

          <button
            type="submit"
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition shadow-md"
          >
            Start Delivery Shift
          </button>
        </form>
      </div>
    );
  }

  // Active rider orders
  const myAssignedOrders = orders.filter((o) => o.assignedDeliveryBoy?.id === deliveryBoyLoggedIn.id);
  const pendingDeliveries = myAssignedOrders.filter((o) => o.orderStatus !== 'Delivered' && o.orderStatus !== 'Cancelled');
  const completedDeliveries = myAssignedOrders.filter((o) => o.orderStatus === 'Delivered');
  const codCashToCollect = pendingDeliveries
    .filter((o) => o.paymentMethod === 'COD' && o.paymentStatus === 'Pending')
    .reduce((sum, curr) => sum + curr.grandTotal, 0);

  const handleUpdateStatus = (orderId: string, status: any) => {
    updateOrderStatus(orderId, status);
    addToast('Status Updated', `Order #${orderId} marked as ${status}`);
  };

  const handleVerifyDelivery = (orderId: string) => {
    updateOrderStatus(orderId, 'Delivered');
    addToast('Delivery Successful', `Order #${orderId} delivered and verified`);
  };

  return (
    <div id="delivery-boy-dashboard" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800 text-xs">
      {/* Rider Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold">
            <Bike className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{deliveryBoyLoggedIn.name}</h1>
            <p className="text-slate-500">
              Vehicle: <strong>{deliveryBoyLoggedIn.vehicle}</strong> | Shift: Active
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage('home')}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
          >
            Store
          </button>
          <button
            onClick={logoutDeliveryBoy}
            className="flex items-center gap-1 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 font-bold rounded-xl"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>End Shift</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-slate-400 font-bold uppercase text-[10px]">Pending Stops</span>
          <p className="text-2xl font-black text-amber-600 mt-1">{pendingDeliveries.length}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-slate-400 font-bold uppercase text-[10px]">Delivered Today</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">{completedDeliveries.length}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-slate-400 font-bold uppercase text-[10px]">COD Cash Due</span>
          <p className="text-2xl font-black text-slate-900 mt-1">₹{codCashToCollect}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-slate-400 font-bold uppercase text-[10px]">Assigned Orders</span>
          <p className="text-2xl font-black text-blue-600 mt-1">{myAssignedOrders.length}</p>
        </div>
      </div>

      {/* Active Orders List */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
          Active Delivery Run ({pendingDeliveries.length} Pending)
        </h2>

        {pendingDeliveries.length > 0 ? (
          pendingDeliveries.map((ord) => (
            <div
              key={ord.id}
              className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-black text-red-600 text-sm">#{ord.id}</span>
                  <span className="px-2.5 py-0.5 bg-blue-100 text-blue-800 rounded-full font-bold text-[10px]">
                    {ord.orderStatus}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-500">Collect:</span>
                  <span className="font-black text-slate-900 text-base">
                    {ord.paymentMethod === 'COD' && ord.paymentStatus === 'Pending'
                      ? `₹${ord.grandTotal} (Cash/UPI)`
                      : 'PAID ONLINE'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Customer Details */}
                <div className="space-y-1 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <p className="font-bold text-slate-900 text-sm">{ord.customerAddress.fullName}</p>
                  <p className="text-slate-600">{ord.customerAddress.house}, {ord.customerAddress.street}</p>
                  <p className="text-slate-600">{ord.customerAddress.area}, {ord.customerAddress.city} - <strong>{ord.customerAddress.pinCode}</strong></p>
                  {ord.customerAddress.landmark && (
                    <p className="text-slate-500 text-[11px]">Landmark: Near {ord.customerAddress.landmark}</p>
                  )}

                  <div className="pt-2 flex gap-2">
                    <a
                      href={`tel:${ord.customerAddress.mobile}`}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call Customer</span>
                    </a>
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                        `${ord.customerAddress.street} ${ord.customerAddress.city} ${ord.customerAddress.pinCode}`
                      )}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center gap-1"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Map Route</span>
                    </a>
                  </div>
                </div>

                {/* Items & Delivery Verification */}
                <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col justify-between">
                  <div>
                    <span className="font-bold text-slate-700 text-[11px] block mb-1">Items to Deliver:</span>
                    <ul className="space-y-1">
                      {ord.items.map((it, idx) => (
                        <li key={idx} className="text-slate-800">
                          • <strong>{it.quantity}x</strong> {it.product.name}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-2 flex flex-wrap gap-2">
                    {ord.orderStatus !== 'Out for Delivery' && (
                      <button
                        onClick={() => handleUpdateStatus(ord.id, 'Out for Delivery')}
                        className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold"
                      >
                        Start Trip (Out for Delivery)
                      </button>
                    )}

                    <button
                      onClick={() => handleVerifyDelivery(ord.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1 shadow-sm"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirm Delivered & Handover</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <p className="font-bold text-slate-800">No Pending Deliveries for your route!</p>
            <p className="text-slate-400 mt-0.5">All assigned orders are currently fulfilled.</p>
          </div>
        )}
      </div>
    </div>
  );
};
