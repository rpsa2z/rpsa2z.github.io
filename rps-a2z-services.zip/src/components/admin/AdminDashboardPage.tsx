import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Order, Product, DeliveryBoy } from '../../types';
import { InvoiceModal } from '../common/InvoiceModal';
import {
  Shield,
  Package,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  Plus,
  Trash2,
  Edit2,
  Bike,
  Settings,
  Printer,
  MessageCircle,
  Search,
  Filter,
  ArrowRight,
  LogOut,
  Save,
  Check,
} from 'lucide-react';

export const AdminDashboardPage: React.FC = () => {
  const {
    orders,
    products,
    deliveryBoys,
    settings,
    updateSettings,
    adminLoggedIn,
    loginAdmin,
    logoutAdmin,
    updateOrderStatus,
    assignDeliveryBoy,
    addProduct,
    updateProduct,
    deleteProduct,
    addDeliveryBoy,
    addToast,
    setCurrentPage,
  } = useStore();

  // Admin login credentials
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');

  // Active Tab: 'orders' | 'products' | 'delivery' | 'settings'
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'delivery' | 'settings'>('orders');

  // Modal for Invoice
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  // New Product State
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCat, setNewProdCat] = useState('photo-frames');
  const [newProdPrice, setNewProdPrice] = useState(499);
  const [newProdMrp, setNewProdMrp] = useState(799);
  const [newProdStock, setNewProdStock] = useState(50);
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdImg, setNewProdImg] = useState('https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&q=80');
  const [newProdCustomizable, setNewProdCustomizable] = useState(true);

  // New Delivery Boy State
  const [isAddRiderOpen, setIsAddRiderOpen] = useState(false);
  const [riderName, setRiderName] = useState('');
  const [riderMobile, setRiderMobile] = useState('');
  const [riderVehicle, setRiderVehicle] = useState('Hero Splendor (UP 32 AZ 1001)');

  // Settings State
  const [businessName, setBusinessName] = useState(settings.businessName);
  const [tagline, setTagline] = useState(settings.tagline);
  const [mobileNumber, setMobileNumber] = useState(settings.mobileNumber);
  const [whatsappNumber, setWhatsappNumber] = useState(settings.whatsappNumber);
  const [email, setEmail] = useState(settings.email);
  const [address, setAddress] = useState(settings.businessAddress);
  const [freeDeliveryMin, setFreeDeliveryMin] = useState(settings.freeDeliveryThreshold);

  // If admin is not logged in, show secure login prompt
  if (!adminLoggedIn) {
    const handleLogin = (e: React.FormEvent) => {
      e.preventDefault();
      if (loginAdmin(adminUser, adminPass)) {
        addToast('Admin Authorized', 'Welcome to RPS A2Z Executive Management');
      } else {
        addToast('Invalid Credentials', 'Default demo login: admin / admin123');
      }
    };

    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-slate-200 shadow-xl text-xs space-y-4">
        <div className="text-center">
          <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Shield className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black text-slate-900">Admin Control Center</h2>
          <p className="text-slate-500 mt-1">Authorized access for RPS A2Z staff & management</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-3 pt-2">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Username</label>
            <input
              type="text"
              required
              value={adminUser}
              onChange={(e) => setAdminUser(e.target.value)}
              placeholder="e.g. admin"
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Password</label>
            <input
              type="password"
              required
              value={adminPass}
              onChange={(e) => setAdminPass(e.target.value)}
              placeholder="e.g. admin123"
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <p className="text-[11px] text-slate-400">Demo Login: <strong>admin</strong> / <strong>admin123</strong></p>

          <button
            type="submit"
            className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold transition shadow-md"
          >
            Access Admin Dashboard
          </button>
        </form>
      </div>
    );
  }

  // Calculate Metrics
  const totalSales = orders.reduce((acc, curr) => acc + (curr.paymentStatus === 'Paid' ? curr.grandTotal : 0), 0);
  const pendingOrders = orders.filter((o) => o.orderStatus !== 'Delivered' && o.orderStatus !== 'Cancelled').length;
  const completedOrders = orders.filter((o) => o.orderStatus === 'Delivered').length;

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const discount = Math.round(((newProdMrp - newProdPrice) / newProdMrp) * 100);
    const newP: Product = {
      id: `RPS-PRD-${Math.floor(1000 + Math.random() * 9000)}`,
      name: newProdName,
      category: newProdCat,
      mrp: Number(newProdMrp),
      price: Number(newProdPrice),
      discountPercentage: discount > 0 ? discount : 10,
      stock: Number(newProdStock),
      rating: 4.9,
      reviewsCount: 1,
      images: [newProdImg],
      description: newProdDesc,
      deliveryDays: 2,
      isCustomizable: newProdCustomizable,
      customizationType: 'standard_custom',
      sku: `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      minQuantity: 1,
      maxQuantity: 50,
      features: ['High quality print finish', 'Fast dispatch guaranteed'],
      specifications: {},
    };
    addProduct(newP);
    setIsAddProductOpen(false);
    setNewProdName('');
    addToast('Product Added', `${newP.name} is now live in store`);
  };

  const handleCreateRider = (e: React.FormEvent) => {
    e.preventDefault();
    const rider: DeliveryBoy = {
      id: `RIDER-00${deliveryBoys.length + 1}`,
      name: riderName,
      mobile: riderMobile,
      vehicle: riderVehicle,
      activeOrdersCount: 0,
      status: 'Active',
    };
    addDeliveryBoy(rider);
    setIsAddRiderOpen(false);
    setRiderName('');
    setRiderMobile('');
    addToast('Rider Registered', `${rider.name} added to dispatch fleet`);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      businessName,
      tagline,
      mobileNumber,
      whatsappNumber,
      email,
      businessAddress: address,
      freeDeliveryThreshold: Number(freeDeliveryMin),
    });
    addToast('Settings Saved', 'Business configuration updated');
  };

  return (
    <div id="admin-dashboard-container" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      {/* Admin Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-red-600 text-white flex items-center justify-center font-bold">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">RPS A2Z Command Center</h1>
            <p className="text-xs text-slate-500">Live Order Fulfillment & Inventory Management</p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={() => setCurrentPage('home')}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
          >
            Visit Store
          </button>
          <button
            onClick={logoutAdmin}
            className="flex items-center gap-1 px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded-xl transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-8 text-xs">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Total Revenue</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">₹{totalSales.toLocaleString('en-IN')}</p>
          <span className="text-[10px] text-emerald-600 font-bold">Realized Revenue</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Total Orders</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{orders.length}</p>
          <span className="text-[10px] text-blue-600 font-bold">All Time Logged</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Active Jobs</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-600 mt-2">{pendingOrders}</p>
          <span className="text-[10px] text-slate-400">In Workshop / Transit</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Delivered</span>
            <div className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{completedOrders}</p>
          <span className="text-[10px] text-purple-600 font-bold">Fulfilled Orders</span>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="flex gap-2 border-b border-slate-200 pb-2 mb-6 overflow-x-auto text-xs font-bold">
        {[
          { id: 'orders', label: `Orders (${orders.length})`, icon: <Package className="w-4 h-4" /> },
          { id: 'products', label: `Products & Stock (${products.length})`, icon: <Edit2 className="w-4 h-4" /> },
          { id: 'delivery', label: `Delivery Fleet (${deliveryBoys.length})`, icon: <Bike className="w-4 h-4" /> },
          { id: 'settings', label: 'Business Settings', icon: <Settings className="w-4 h-4" /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl whitespace-nowrap transition ${
              activeTab === tab.id
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: ORDERS FULFILLMENT MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-4 text-xs">
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <span className="font-bold text-slate-900 text-sm">Customer Orders Management</span>
              <span className="text-slate-400">{orders.length} total orders</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px] font-bold">
                  <tr>
                    <th className="p-3.5">Order ID</th>
                    <th className="p-3.5">Customer & Contact</th>
                    <th className="p-3.5">Items & Customization</th>
                    <th className="p-3.5">Grand Total</th>
                    <th className="p-3.5">Workflow Status</th>
                    <th className="p-3.5">Assigned Rider</th>
                    <th className="p-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {orders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-50/60">
                      <td className="p-3.5 font-mono font-bold text-red-600">#{ord.id}</td>
                      <td className="p-3.5">
                        <p className="font-bold text-slate-900">{ord.customerAddress.fullName}</p>
                        <p className="text-[11px] text-slate-500">{ord.customerAddress.mobile}</p>
                        <p className="text-[10px] text-slate-400">{ord.customerAddress.city} - {ord.customerAddress.pinCode}</p>
                      </td>
                      <td className="p-3.5 max-w-xs">
                        {ord.items.map((it, idx) => (
                          <div key={idx} className="truncate">
                            <span className="font-bold text-slate-800">{it.quantity}x</span> {it.product.name}
                            {it.customization?.notes && (
                              <span className="text-[10px] text-blue-600 block truncate">
                                {it.customization.notes}
                              </span>
                            )}
                          </div>
                        ))}
                      </td>
                      <td className="p-3.5">
                        <p className="font-black text-slate-900">₹{ord.grandTotal}</p>
                        <p className={`text-[10px] font-bold ${ord.paymentStatus === 'Paid' ? 'text-emerald-600' : 'text-amber-600'}`}>
                          {ord.paymentMethod} ({ord.paymentStatus})
                        </p>
                      </td>
                      <td className="p-3.5">
                        <select
                          value={ord.orderStatus}
                          onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                          className="p-1.5 border border-slate-200 rounded-lg text-xs font-bold bg-white focus:outline-none"
                        >
                          <option value="Placed">Placed</option>
                          <option value="Confirmed">Confirmed</option>
                          <option value="Design Proofing">Design Proofing</option>
                          <option value="Printing">Printing</option>
                          <option value="Quality Check">Quality Check</option>
                          <option value="Packing">Packing</option>
                          <option value="Out for Delivery">Out for Delivery</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td className="p-3.5">
                        <select
                          value={ord.assignedDeliveryBoy?.id || ''}
                          onChange={(e) => assignDeliveryBoy(ord.id, e.target.value)}
                          className="p-1.5 border border-slate-200 rounded-lg text-xs bg-white focus:outline-none"
                        >
                          <option value="">-- Assign Rider --</option>
                          {deliveryBoys.map((r) => (
                            <option key={r.id} value={r.id}>{r.name} ({r.vehicle})</option>
                          ))}
                        </select>
                      </td>
                      <td className="p-3.5 text-right space-x-1.5">
                        <button
                          onClick={() => setSelectedInvoiceOrder(ord)}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700"
                          title="View / Print Tax Invoice"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <a
                          href={`https://wa.me/91${ord.customerAddress.mobile}?text=${encodeURIComponent(
                            `Hello ${ord.customerAddress.fullName}, your RPS A2Z order #${ord.id} status is now: ${ord.orderStatus}.`
                          )}`}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-block p-1.5 bg-emerald-50 hover:bg-emerald-100 rounded-lg text-emerald-700"
                          title="WhatsApp Customer"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PRODUCTS & INVENTORY MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-4 text-xs">
          <div className="flex justify-between items-center">
            <span className="font-bold text-slate-900 text-sm">Product Catalog & Warehouse Stock</span>
            <button
              onClick={() => setIsAddProductOpen(!isAddProductOpen)}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Product</span>
            </button>
          </div>

          {/* Add Product Drawer */}
          {isAddProductOpen && (
            <form onSubmit={handleCreateProduct} className="p-5 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-bold text-sm text-slate-900">Add New Store Product</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={newProdName}
                    onChange={(e) => setNewProdName(e.target.value)}
                    placeholder="e.g. Magic Mug Gold Edition"
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={newProdCat}
                    onChange={(e) => setNewProdCat(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  >
                    <option value="photo-frames">Photo Frames</option>
                    <option value="mug-printing">Mug Printing</option>
                    <option value="tshirt-printing">T-Shirt Printing</option>
                    <option value="visiting-cards">Visiting Cards</option>
                    <option value="banners-flex">Banners & Flex</option>
                    <option value="customized-gifts">Customized Gifts</option>
                    <option value="stationery">Stationery</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Image URL</label>
                  <input
                    type="text"
                    required
                    value={newProdImg}
                    onChange={(e) => setNewProdImg(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Selling Price (₹)</label>
                  <input
                    type="number"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">MRP Price (₹)</label>
                  <input
                    type="number"
                    required
                    value={newProdMrp}
                    onChange={(e) => setNewProdMrp(Number(e.target.value))}
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Initial Stock</label>
                  <input
                    type="number"
                    required
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(Number(e.target.value))}
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newProdDesc}
                  onChange={(e) => setNewProdDesc(e.target.value)}
                  placeholder="Short product overview..."
                  className="w-full p-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddProductOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-red-600 text-white rounded-xl font-bold"
                >
                  Publish Product
                </button>
              </div>
            </form>
          )}

          {/* Product list table */}
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px] font-bold">
                <tr>
                  <th className="p-3.5">Product</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Price / MRP</th>
                  <th className="p-3.5">Stock Quantity</th>
                  <th className="p-3.5 text-right">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/60">
                    <td className="p-3.5 flex items-center gap-3">
                      <img
                        src={p.images[0]}
                        alt={p.name}
                        className="w-10 h-10 rounded-xl object-cover border border-slate-200"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <p className="font-bold text-slate-900">{p.name}</p>
                        <span className="text-[10px] text-slate-400">{p.id} | {p.sku}</span>
                      </div>
                    </td>
                    <td className="p-3.5 font-medium text-slate-600 uppercase text-[10px]">
                      {p.category.replace('-', ' ')}
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-900">₹{p.price}</span>{' '}
                      <span className="text-slate-400 line-through">₹{p.mrp}</span>
                    </td>
                    <td className="p-3.5">
                      <input
                        type="number"
                        defaultValue={p.stock}
                        onBlur={(e) => {
                          updateProduct(p.id, { stock: Number(e.target.value) });
                          addToast('Stock Updated', `${p.name} stock set to ${e.target.value}`);
                        }}
                        className="w-20 p-1 border border-slate-200 rounded-lg text-center font-bold"
                      />
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => {
                          deleteProduct(p.id);
                          addToast('Product Removed', `${p.name} deleted.`);
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg"
                        title="Delete Product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: DELIVERY FLEET */}
      {activeTab === 'delivery' && (
        <div className="space-y-4 text-xs">
          <div className="flex justify-between items-center">
            <span className="font-bold text-slate-900 text-sm">Delivery Personnel Fleet</span>
            <button
              onClick={() => setIsAddRiderOpen(!isAddRiderOpen)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add Delivery Boy</span>
            </button>
          </div>

          {isAddRiderOpen && (
            <form onSubmit={handleCreateRider} className="p-5 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-3">
              <h4 className="font-bold text-slate-900 text-sm">Register New Courier Executive</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={riderName}
                    onChange={(e) => setRiderName(e.target.value)}
                    placeholder="e.g. Suraj Kumar"
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mobile</label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={riderMobile}
                    onChange={(e) => setRiderMobile(e.target.value)}
                    placeholder="e.g. 9876543210"
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Vehicle & Number</label>
                  <input
                    type="text"
                    required
                    value={riderVehicle}
                    onChange={(e) => setRiderVehicle(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddRiderOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-emerald-600 text-white rounded-xl font-bold"
                >
                  Register Rider
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {deliveryBoys.map((rider) => (
              <div key={rider.id} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                    <Bike className="w-5 h-5" />
                  </div>
                  <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-bold text-[10px]">
                    {rider.status}
                  </span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{rider.name}</h4>
                  <p className="text-slate-500 font-mono text-[11px]">ID: {rider.id}</p>
                  <p className="text-slate-700 mt-1 font-medium">Vehicle: {rider.vehicle}</p>
                  <p className="text-slate-500">Mobile: +91 {rider.mobile}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SETTINGS */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4 text-xs max-w-2xl">
          <h3 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100">
            Store & Contact Configuration
          </h3>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Business Name</label>
            <input
              type="text"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Tagline</label>
            <input
              type="text"
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Mobile Number</label>
              <input
                type="text"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
                className="w-full p-2.5 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">WhatsApp Number</label>
              <input
                type="text"
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                className="w-full p-2.5 border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Physical Business Address</label>
            <textarea
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Free Delivery Order Threshold (₹)</label>
            <input
              type="number"
              value={freeDeliveryMin}
              onChange={(e) => setFreeDeliveryMin(Number(e.target.value))}
              className="w-full p-2.5 border border-slate-200 rounded-xl font-bold"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-sm"
          >
            <Save className="w-4 h-4" />
            <span>Save Configuration</span>
          </button>
        </form>
      )}

      {/* Invoice Modal for Admin */}
      {selectedInvoiceOrder && (
        <InvoiceModal
          order={selectedInvoiceOrder}
          settings={settings}
          onClose={() => setSelectedInvoiceOrder(null)}
        />
      )}
    </div>
  );
};
