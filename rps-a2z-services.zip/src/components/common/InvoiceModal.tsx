import React from 'react';
import { Order, WebsiteSettings } from '../../types';
import { X, Printer, Download, CheckCircle, ShieldCheck } from 'lucide-react';

interface InvoiceModalProps {
  order: Order;
  settings: WebsiteSettings;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, settings, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const invoiceNumber = `INV-${order.id.replace('ORDRPS', 'RPS-2026-')}`;

  return (
    <div
      id="invoice-modal-overlay"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
    >
      <div
        id="invoice-modal-card"
        className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl relative my-6 text-slate-800"
      >
        {/* Actions bar (hidden in print) */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-200 print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900 text-lg">Tax Invoice / Bill of Supply</span>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
              Original Copy
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition"
            >
              <Printer className="w-4 h-4" />
              <span>Print Invoice</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition"
            >
              <Download className="w-4 h-4" />
              <span>Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-700 p-2 rounded-full hover:bg-slate-100 ml-2"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div id="printable-invoice" className="p-4 bg-white">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start border-b border-slate-200 pb-6 gap-4">
            <div>
              {/* Brand Logo with exact Red, Green, Blue colors */}
              <div className="flex items-center tracking-tight text-2xl font-black mb-1">
                <span className="text-red-600">RPS</span>
                <span className="mx-1 text-emerald-600">A2Z</span>
                <span className="text-blue-600">SERVICES</span>
              </div>
              <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                {settings.tagline || 'Complete Printing & Digital Hub'}
              </p>
              <p className="text-xs text-slate-500 max-w-sm">{settings.businessAddress}</p>
              <p className="text-xs text-slate-600 mt-1 font-medium">
                Phone: +91 {settings.mobileNumber || '8090524232'} | Email: {settings.email}
              </p>
              <p className="text-[11px] text-slate-400">GSTIN: 09AAAFR1234P1Z8 | HSN/SAC: 4911 / 9989</p>
            </div>

            <div className="sm:text-right">
              <div className="inline-block bg-slate-50 border border-slate-200 rounded-xl p-3 text-left sm:text-right">
                <p className="text-xs text-slate-500 font-medium">Invoice Number</p>
                <p className="text-sm font-bold text-slate-900">{invoiceNumber}</p>
                <p className="text-xs text-slate-500 font-medium mt-1">Order Reference</p>
                <p className="text-xs font-semibold text-red-600">#{order.id}</p>
                <p className="text-xs text-slate-500 mt-1">
                  Date: {new Date(order.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                </p>
              </div>
            </div>
          </div>

          {/* Billing & Shipping Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 my-5 text-xs">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
              <h4 className="font-bold text-slate-700 uppercase tracking-wider mb-1.5 text-[11px]">Billed To:</h4>
              <p className="font-bold text-slate-900 text-sm">{order.customerAddress.fullName}</p>
              <p className="text-slate-600 mt-0.5">{order.customerAddress.house}, {order.customerAddress.street}</p>
              <p className="text-slate-600">{order.customerAddress.area}, {order.customerAddress.landmark ? `Near ${order.customerAddress.landmark}, ` : ''}{order.customerAddress.city}</p>
              <p className="text-slate-600">{order.customerAddress.district}, {order.customerAddress.state} - {order.customerAddress.pinCode}</p>
              <p className="text-slate-700 font-medium mt-1">Mobile: {order.customerAddress.mobile}</p>
              <p className="text-slate-600">Email: {order.customerAddress.email}</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
              <h4 className="font-bold text-slate-700 uppercase tracking-wider mb-1.5 text-[11px]">Payment & Dispatch:</h4>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Payment Mode:</span>
                  <span className="font-semibold text-slate-800">{order.paymentMethod}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Payment Status:</span>
                  <span className={`font-semibold ${order.paymentStatus === 'Paid' ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {order.paymentStatus}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Order Status:</span>
                  <span className="font-semibold text-blue-600">{order.orderStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Delivery PIN:</span>
                  <span className="font-semibold text-slate-800">{order.customerAddress.pinCode}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="overflow-x-auto my-4">
            <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 uppercase tracking-wider font-bold text-[11px]">
                <tr>
                  <th className="p-3 border-b">#</th>
                  <th className="p-3 border-b">Product / Service Description</th>
                  <th className="p-3 border-b text-center">Qty</th>
                  <th className="p-3 border-b text-right">Unit Rate</th>
                  <th className="p-3 border-b text-right">Total (INR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {order.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/60">
                    <td className="p-3 text-slate-400 font-medium">{idx + 1}</td>
                    <td className="p-3">
                      <p className="font-bold text-slate-900">{item.product.name}</p>
                      <p className="text-[11px] text-slate-500">SKU: {item.product.sku}</p>
                      {item.customization?.type === 'photo_frame' && item.customization.photoFrameConfig && (
                        <p className="text-[11px] text-blue-700 font-medium">
                          Frame: {item.customization.photoFrameConfig.size}, {item.customization.photoFrameConfig.frameColor} ({item.customization.photoFrameConfig.frameDesign})
                        </p>
                      )}
                      {item.customization?.type === 'printing' && item.customization.printingConfig && (
                        <p className="text-[11px] text-emerald-700 font-medium">
                          Print: {item.customization.printingConfig.printSize}, {item.customization.printingConfig.paperGsm}, {item.customization.printingConfig.lamination} lamination
                        </p>
                      )}
                    </td>
                    <td className="p-3 text-center font-bold text-slate-800">{item.quantity}</td>
                    <td className="p-3 text-right text-slate-600 font-medium">₹{item.unitPrice}</td>
                    <td className="p-3 text-right font-bold text-slate-900">₹{item.totalPrice}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Breakdown */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 my-6 text-xs">
            <div className="max-w-xs space-y-2">
              <div className="flex items-center gap-2 p-2.5 bg-emerald-50 rounded-xl text-emerald-800 border border-emerald-100">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                <span className="text-[11px]">Computer generated invoice. No physical signature required.</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>RPS A2Z Services Guarantee & Return Policy Applies.</span>
              </div>
            </div>

            <div className="w-full sm:w-72 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-semibold">₹{order.subtotal}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Discount ({order.couponCode || 'Coupon'})</span>
                  <span>- ₹{order.discount}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Delivery Charge</span>
                <span>{order.deliveryCharge === 0 ? 'FREE' : `₹${order.deliveryCharge}`}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>GST (18% Included)</span>
                <span className="font-semibold">₹{order.gstAmount}</span>
              </div>
              <div className="border-t border-slate-200 pt-2 flex justify-between text-sm font-black text-slate-900">
                <span>Grand Total</span>
                <span className="text-red-600 text-base">₹{order.grandTotal}</span>
              </div>
            </div>
          </div>

          {/* Footer note */}
          <div className="border-t border-slate-200 pt-4 text-center text-xs text-slate-500">
            <p className="font-bold text-slate-700">Thank you for choosing RPS A2Z SERVICES!</p>
            <p className="text-[11px] text-slate-400 mt-1">
              For any queries or customized bulk printing, please call us at +91 {settings.mobileNumber || '8090524232'}.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
