import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Star, ShieldCheck, Truck, ShoppingCart, ArrowRight } from 'lucide-react';

export const QuickViewModal: React.FC = () => {
  const { quickViewProduct, setQuickViewProduct, addToCart, setCurrentPage, setSelectedProductId } = useStore();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);

  if (!quickViewProduct) return null;

  const handleAddToCart = () => {
    addToCart(quickViewProduct, quantity);
    setQuickViewProduct(null);
  };

  const handleViewDetails = () => {
    setSelectedProductId(quickViewProduct.id);
    setCurrentPage('product-detail');
    setQuickViewProduct(null);
  };

  return (
    <div
      id="quick-view-overlay"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
    >
      <div
        id="quick-view-card"
        className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 my-8"
      >
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Images */}
          <div>
            <div className="aspect-square bg-slate-100 rounded-xl overflow-hidden mb-3 border border-slate-200">
              <img
                src={quickViewProduct.images[selectedImageIndex] || quickViewProduct.images[0]}
                alt={quickViewProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {quickViewProduct.images.length > 1 && (
              <div className="flex gap-2">
                {quickViewProduct.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition ${
                      selectedImageIndex === idx ? 'border-red-600' : 'border-slate-200 opacity-70'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-red-600 bg-red-50 px-2 py-0.5 rounded-md">
                  {quickViewProduct.category.replace('-', ' ')}
                </span>
                <span className="text-xs text-slate-400">ID: {quickViewProduct.id}</span>
              </div>

              <h2 className="text-xl font-bold text-slate-900 leading-snug">{quickViewProduct.name}</h2>

              {/* Rating */}
              <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center gap-1 bg-emerald-600 text-white px-2 py-0.5 rounded-md text-xs font-semibold">
                  <span>{quickViewProduct.rating}</span>
                  <Star className="w-3 h-3 fill-white" />
                </div>
                <span className="text-xs text-slate-500 font-medium">({quickViewProduct.reviewsCount} customer reviews)</span>
                {quickViewProduct.stock > 0 ? (
                  <span className="text-xs font-semibold text-emerald-600 ml-auto bg-emerald-50 px-2 py-0.5 rounded-md">
                    In Stock ({quickViewProduct.stock})
                  </span>
                ) : (
                  <span className="text-xs font-semibold text-red-600 ml-auto bg-red-50 px-2 py-0.5 rounded-md">
                    Out of Stock
                  </span>
                )}
              </div>

              {/* Pricing */}
              <div className="mt-4 flex items-baseline gap-3">
                <span className="text-2xl font-black text-slate-900">₹{quickViewProduct.price}</span>
                <span className="text-sm text-slate-400 line-through">₹{quickViewProduct.mrp}</span>
                <span className="text-sm font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                  {quickViewProduct.discountPercentage}% OFF
                </span>
              </div>

              <p className="text-xs text-slate-600 mt-3 line-clamp-3 leading-relaxed">
                {quickViewProduct.description}
              </p>

              {/* Delivery info */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-4 text-xs text-slate-600">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-blue-600" />
                  <span>Delivers in {quickViewProduct.deliveryDays} days</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>100% Quality Guaranteed</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-3">
              <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 font-bold"
                >
                  -
                </button>
                <span className="px-3 py-2 text-sm font-semibold text-slate-800">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(quickViewProduct.maxQuantity, quantity + 1))}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 font-bold"
                >
                  +
                </button>
              </div>

              <button
                id="quick-view-add-cart-btn"
                onClick={handleAddToCart}
                className="flex-1 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold py-2.5 px-4 rounded-xl shadow-sm transition active:scale-95"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Add to Cart</span>
              </button>

              <button
                id="quick-view-details-btn"
                onClick={handleViewDetails}
                className="flex items-center justify-center gap-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-sm font-semibold py-2.5 px-4 rounded-xl transition"
              >
                <span>Full Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
