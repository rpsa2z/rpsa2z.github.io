import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { MapPin, X, Check, Search } from 'lucide-react';

export const LocationModal: React.FC = () => {
  const { isLocationModalOpen, setIsLocationModalOpen, deliveryPincode, setDeliveryPincode, addToast } = useStore();
  const [inputPin, setInputPin] = useState(deliveryPincode);
  const [error, setError] = useState('');

  if (!isLocationModalOpen) return null;

  const popularPincodes = [
    { pin: '226001', city: 'Lucknow (Hazratganj)' },
    { pin: '226024', city: 'Lucknow (Aliganj)' },
    { pin: '226010', city: 'Lucknow (Gomti Nagar)' },
    { pin: '208001', city: 'Kanpur' },
    { pin: '110001', city: 'New Delhi' },
    { pin: '400001', city: 'Mumbai' },
  ];

  const handleSave = (pinToSet = inputPin) => {
    const cleaned = pinToSet.trim();
    if (!/^\d{6}$/.test(cleaned)) {
      setError('Please enter a valid 6-digit Indian PIN code.');
      return;
    }
    setDeliveryPincode(cleaned);
    setIsLocationModalOpen(false);
    setError('');
    addToast('Delivery Location Updated', `Delivering to PIN Code: ${cleaned}`);
  };

  return (
    <div
      id="location-modal-overlay"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="location-modal-card"
        className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200"
      >
        <button
          onClick={() => setIsLocationModalOpen(false)}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center text-red-600">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800">Select Delivery Location</h3>
            <p className="text-xs text-slate-500">Enter your 6-digit PIN code to check shipping speed</p>
          </div>
        </div>

        <div className="mt-3">
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">Enter PIN Code</label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                id="location-pincode-input"
                type="text"
                maxLength={6}
                value={inputPin}
                onChange={(e) => {
                  setInputPin(e.target.value.replace(/\D/g, ''));
                  setError('');
                }}
                placeholder="e.g. 226001"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 text-sm font-medium tracking-wide"
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
            </div>
            <button
              id="apply-pincode-btn"
              onClick={() => handleSave()}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-xl transition-colors shrink-0 shadow-sm"
            >
              Apply
            </button>
          </div>
          {error && <p className="text-xs text-red-600 mt-1.5 font-medium">{error}</p>}
        </div>

        <div className="mt-5 border-t border-slate-100 pt-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2.5">
            Quick Select Locations
          </p>
          <div className="grid grid-cols-2 gap-2">
            {popularPincodes.map((item) => (
              <button
                key={item.pin}
                onClick={() => {
                  setInputPin(item.pin);
                  handleSave(item.pin);
                }}
                className={`text-left p-2.5 rounded-xl border text-xs transition-all flex items-center justify-between ${
                  deliveryPincode === item.pin
                    ? 'border-red-500 bg-red-50/60 font-semibold text-red-700'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div>
                  <div className="font-bold">{item.pin}</div>
                  <div className="text-[11px] text-slate-500 truncate">{item.city}</div>
                </div>
                {deliveryPincode === item.pin && <Check className="w-4 h-4 text-red-600 shrink-0" />}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
