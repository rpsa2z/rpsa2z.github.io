import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { MessageCircle, X, HelpCircle, FileText, Send, Phone } from 'lucide-react';

export const WhatsAppFloating: React.FC = () => {
  const { settings, activeTrackingOrderId } = useStore();
  const [isOpen, setIsOpen] = useState(false);

  const phone = settings.whatsappNumber || '8090524232';

  const sendWhatsApp = (customMsg?: string) => {
    const defaultMsg = 'Hello RPS A2Z SERVICES, I need information about this product/service.';
    const msg = customMsg || defaultMsg;
    const url = `https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
    setIsOpen(false);
  };

  return (
    <div id="whatsapp-floating-container" className="fixed bottom-20 sm:bottom-6 right-4 z-40">
      {isOpen && (
        <div
          id="whatsapp-chat-popup"
          className="mb-3 w-80 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200"
        >
          {/* Header */}
          <div className="bg-emerald-600 text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center font-bold text-base">
                RPS
              </div>
              <div>
                <h4 className="font-bold text-sm leading-tight">RPS A2Z Support</h4>
                <p className="text-[11px] text-emerald-100">Usually replies within 5 minutes</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body Options */}
          <div className="p-3.5 space-y-2 bg-slate-50 text-xs">
            <p className="text-slate-600 mb-2 font-medium">How can we assist you today?</p>

            <button
              onClick={() => sendWhatsApp('Hello RPS A2Z SERVICES, I want to place a custom printing order.')}
              className="w-full text-left p-2.5 bg-white hover:bg-emerald-50 border border-slate-200 rounded-xl transition flex items-center gap-2 text-slate-700 hover:text-emerald-700"
            >
              <FileText className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Order Custom Printing / Gifts</span>
            </button>

            {activeTrackingOrderId && (
              <button
                onClick={() =>
                  sendWhatsApp(
                    `Hello RPS A2Z SERVICES, I want to inquire about status of my Order #${activeTrackingOrderId}.`
                  )
                }
                className="w-full text-left p-2.5 bg-white hover:bg-emerald-50 border border-slate-200 rounded-xl transition flex items-center gap-2 text-slate-700 hover:text-emerald-700"
              >
                <HelpCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Track Order #{activeTrackingOrderId}</span>
              </button>
            )}

            <button
              onClick={() =>
                sendWhatsApp('Hello RPS A2Z SERVICES, I want to send photos or design proof for printing.')
              }
              className="w-full text-left p-2.5 bg-white hover:bg-emerald-50 border border-slate-200 rounded-xl transition flex items-center gap-2 text-slate-700 hover:text-emerald-700"
            >
              <Send className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Send Photos / Proof for Printing</span>
            </button>

            <button
              onClick={() =>
                sendWhatsApp('Hello RPS A2Z SERVICES, I need customer support for digital or document services.')
              }
              className="w-full text-left p-2.5 bg-white hover:bg-emerald-50 border border-slate-200 rounded-xl transition flex items-center gap-2 text-slate-700 hover:text-emerald-700"
            >
              <Phone className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>General Inquiry / Call Back</span>
            </button>
          </div>

          <div className="p-3 bg-white border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Direct WhatsApp: +91 {phone}</span>
            <button
              onClick={() => sendWhatsApp()}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium"
            >
              Open Chat
            </button>
          </div>
        </div>
      )}

      {/* Floating Toggle Button */}
      <button
        id="whatsapp-trigger-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-700 text-white p-3 sm:px-4 sm:py-3 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 font-medium group scale-100 hover:scale-105 active:scale-95"
        aria-label="Contact on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 shrink-0 fill-white" />
        <span className="hidden sm:inline text-xs font-semibold tracking-wide">Chat on WhatsApp</span>
      </button>
    </div>
  );
};
