import React from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Printer,
  ShieldCheck,
  Truck,
  Heart,
  CreditCard,
  QrCode,
  ArrowRight,
  Shield,
  Bike,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentPage, setSelectedCategory, settings } = useStore();

  return (
    <footer id="main-app-footer" className="bg-slate-900 text-slate-300 text-xs border-t border-slate-800">
      {/* Top Value Assurance Banner */}
      <div className="border-b border-slate-800 py-8 bg-slate-950/60">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-500/10 text-red-500 flex items-center justify-center shrink-0">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs">High-Definition Output</h4>
              <p className="text-[11px] text-slate-400">12-color archival pigment prints</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs">Free & Safe Shipping</h4>
              <p className="text-[11px] text-slate-400">On all orders above ₹499</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs">Quality Guarantee</h4>
              <p className="text-[11px] text-slate-400">100% damage-proof packaging</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 text-purple-500 flex items-center justify-center shrink-0">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs">24/7 WhatsApp Support</h4>
              <p className="text-[11px] text-slate-400">Prompt order updates & proofing</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Col (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div
              onClick={() => setCurrentPage('home')}
              className="cursor-pointer inline-flex items-center gap-2"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-600 via-emerald-600 to-blue-600 flex items-center justify-center text-white font-black text-sm shadow-md">
                RPS
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-black tracking-tight flex items-baseline gap-1">
                  <span className="text-red-500">RPS</span>
                  <span className="text-emerald-400">A2Z</span>
                  <span className="text-blue-400">SERVICES</span>
                </span>
                <span className="text-[9px] tracking-wider uppercase font-semibold text-slate-400">
                  {settings.tagline}
                </span>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Your comprehensive e-commerce destination for personalized photo frames, digital sublimation mugs,
              corporate apparel, premium stationery, and government digital document assistance.
            </p>

            <div className="pt-2 space-y-2 text-[11px] text-slate-400">
              <p className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0" />
                <span>{settings.businessAddress}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Helpline: +91 {settings.mobileNumber}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-400 shrink-0" />
                <span>{settings.email}</span>
              </p>
            </div>
          </div>

          {/* Categories Col */}
          <div className="space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider">Top Categories</h3>
            <ul className="space-y-2 text-slate-400">
              {[
                { name: 'Photo Frames & Collages', id: 'photo-frames' },
                { name: 'Custom Printed Mugs', id: 'mug-printing' },
                { name: 'T-Shirts & Apparel', id: 'tshirt-printing' },
                { name: 'Business Visiting Cards', id: 'visiting-cards' },
                { name: 'Large Flex & Banners', id: 'banners-flex' },
                { name: 'Personalized Gifts', id: 'customized-gifts' },
              ].map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => {
                      setSelectedCategory(c.id);
                      setCurrentPage('products');
                    }}
                    className="hover:text-white transition flex items-center gap-1.5"
                  >
                    <ArrowRight className="w-3 h-3 text-red-500" />
                    <span>{c.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider">Services & Tools</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => setCurrentPage('photo-frame-customizer')}
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                  <span>3D Frame Studio</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('digital-services')}
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                  <span>Digital Cyber Services</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('custom-order')}
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                  <span>Custom / Bulk Orders</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('order-tracking')}
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                  <span>Track Live Order</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('about-contact')}
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                  <span>Contact & Workshop Info</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Portals & Management */}
          <div className="space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider">Staff Portals</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => setCurrentPage('admin-dashboard')}
                  className="hover:text-red-400 transition flex items-center gap-1.5"
                >
                  <Shield className="w-3.5 h-3.5 text-red-500" />
                  <span>Admin Control Panel</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('delivery-portal')}
                  className="hover:text-emerald-400 transition flex items-center gap-1.5"
                >
                  <Bike className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Delivery Rider Portal</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('customer-dashboard')}
                  className="hover:text-blue-400 transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-blue-500" />
                  <span>Customer Account</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('my-orders')}
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                  <span>Order Invoices</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar with payment methods and legal disclaimer */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <p>© {new Date().getFullYear()} RPS A2Z SERVICES. All Rights Reserved. Crafted with precision for high-quality printing.</p>

          <div className="flex items-center gap-3">
            <span className="text-[10px] uppercase font-bold text-slate-500">Supported Payments:</span>
            <div className="flex items-center gap-2 text-slate-300">
              <span className="px-2 py-0.5 bg-slate-800 rounded font-semibold text-[10px]">UPI</span>
              <span className="px-2 py-0.5 bg-slate-800 rounded font-semibold text-[10px]">RuPay</span>
              <span className="px-2 py-0.5 bg-slate-800 rounded font-semibold text-[10px]">Visa / Master</span>
              <span className="px-2 py-0.5 bg-slate-800 rounded font-semibold text-[10px]">COD</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
