import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Home, Grid, Search, ShoppingCart, User } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { currentPage, setCurrentPage, cart, user } = useStore();

  const totalCartCount = cart.reduce((total, item) => total + item.quantity, 0);

  const navItems = [
    { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" /> },
    { id: 'products', label: 'Categories', icon: <Grid className="w-5 h-5" /> },
    { id: 'search', label: 'Search', icon: <Search className="w-5 h-5" /> },
    {
      id: 'cart',
      label: 'Cart',
      icon: (
        <div className="relative">
          <ShoppingCart className="w-5 h-5" />
          {totalCartCount > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-red-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              {totalCartCount}
            </span>
          )}
        </div>
      ),
    },
    {
      id: 'customer-dashboard',
      label: user.role === 'customer' ? 'Account' : 'Login',
      icon: <User className="w-5 h-5" />,
    },
  ];

  return (
    <nav
      id="mobile-bottom-nav"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 py-1.5 px-3 flex items-center justify-around shadow-lg"
    >
      {navItems.map((item) => {
        const isActive =
          currentPage === item.id ||
          (item.id === 'search' && currentPage === 'products') ||
          (item.id === 'customer-dashboard' && currentPage === 'my-orders');

        return (
          <button
            key={item.id}
            onClick={() => {
              if (item.id === 'search') {
                setCurrentPage('products');
              } else {
                setCurrentPage(item.id as any);
              }
            }}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
              isActive ? 'text-red-600 font-bold scale-105' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {item.icon}
            <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
