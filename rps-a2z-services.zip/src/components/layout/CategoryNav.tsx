import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Menu,
  Flame,
  Tag,
  Sparkles,
  Sliders,
  ChevronDown,
  Layers,
  Printer,
  Frame,
  Gift,
  CreditCard,
  IdCard,
  Shirt,
  Coffee,
  Laptop,
} from 'lucide-react';

export const CategoryNav: React.FC = () => {
  const { categories, selectedCategoryId, setSelectedCategoryId, setCurrentPage } = useStore();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const quickNavItems = [
    { label: "Today's Deals", icon: <Flame className="w-3.5 h-3.5 text-red-500" />, filter: 'deals' },
    { label: 'Special Offers', icon: <Tag className="w-3.5 h-3.5 text-emerald-500" />, filter: 'offers' },
    { label: 'New Arrivals', icon: <Sparkles className="w-3.5 h-3.5 text-amber-500" />, filter: 'new' },
    { label: 'Custom Order', icon: <Sliders className="w-3.5 h-3.5 text-blue-500" />, action: 'custom-order' },
    { label: 'Digital Services', icon: <Laptop className="w-3.5 h-3.5 text-indigo-500" />, action: 'digital-services' },
    { label: 'Photo Frame', id: 'photo-frames', icon: <Frame className="w-3.5 h-3.5 text-rose-500" /> },
    { label: 'Mug Printing', id: 'mug-printing', icon: <Coffee className="w-3.5 h-3.5 text-amber-600" /> },
    { label: 'T-Shirt Printing', id: 'tshirt-printing', icon: <Shirt className="w-3.5 h-3.5 text-teal-600" /> },
    { label: 'Visiting Cards', id: 'visiting-cards', icon: <CreditCard className="w-3.5 h-3.5 text-blue-600" /> },
    { label: 'ID Cards', id: 'id-cards', icon: <IdCard className="w-3.5 h-3.5 text-purple-600" /> },
    { label: 'Banners & Flex', id: 'banners-flex', icon: <Printer className="w-3.5 h-3.5 text-red-600" /> },
    { label: 'Customized Gifts', id: 'customized-gifts', icon: <Gift className="w-3.5 h-3.5 text-pink-600" /> },
    { label: 'Stationery', id: 'stationery', icon: <Layers className="w-3.5 h-3.5 text-slate-600" /> },
  ];

  return (
    <nav id="category-nav-bar" className="bg-slate-800 text-white border-b border-slate-700 relative text-xs">
      <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center gap-4 sm:gap-6 text-xs font-semibold whitespace-nowrap overflow-x-auto no-scrollbar">
        {/* All Categories Trigger */}
        <div className="relative shrink-0">
          <button
            id="all-categories-dropdown-btn"
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-1.5 cursor-pointer hover:text-green-400 transition"
          >
            <Menu className="w-4 h-4" />
            <span>All Categories</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* All Categories Mega Popover */}
          {isDropdownOpen && (
            <div
              id="all-categories-mega-menu"
              className="absolute left-0 top-full mt-2 w-72 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 z-50 p-2 max-h-[75vh] overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-150"
            >
              <div className="p-2 border-b border-slate-100 font-bold text-[11px] uppercase tracking-wider text-slate-400">
                Explore 27+ Printing & Hub Categories
              </div>
              <div className="py-1 space-y-0.5">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategoryId(cat.id);
                      setCurrentPage('products');
                      setIsDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 rounded-lg text-xs flex items-center justify-between transition ${
                      selectedCategoryId === cat.id
                        ? 'bg-red-50 text-red-700 font-bold'
                        : 'hover:bg-slate-100 text-slate-700'
                    }`}
                  >
                    <span>{cat.name}</span>
                    <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-full">
                      {cat.itemCount} items
                    </span>
                  </button>
                ))}
              </div>

              <div className="p-2 border-t border-slate-100 bg-slate-50 mt-1 rounded-lg">
                <button
                  onClick={() => {
                    setCurrentPage('custom-order');
                    setIsDropdownOpen(false);
                  }}
                  className="w-full py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-md font-bold text-center text-xs block transition"
                >
                  Need Custom Specification? Click Here
                </button>
              </div>
            </div>
          )}
        </div>

        {/* High Density Horizontal Nav Links */}
        <button
          onClick={() => {
            setSelectedCategoryId('printing');
            setCurrentPage('products');
          }}
          className="hover:text-green-400 transition cursor-pointer"
        >
          Printing
        </button>

        <button
          onClick={() => setCurrentPage('photo-frame-customizer')}
          className="hover:text-green-400 transition cursor-pointer"
        >
          Photo Frames
        </button>

        <button
          onClick={() => {
            setSelectedCategoryId('customized-gifts');
            setCurrentPage('products');
          }}
          className="hover:text-green-400 transition cursor-pointer"
        >
          Customized Gifts
        </button>

        <button
          onClick={() => {
            setSelectedCategoryId('stationery');
            setCurrentPage('products');
          }}
          className="hover:text-green-400 transition cursor-pointer"
        >
          Stationery
        </button>

        <button
          onClick={() => {
            setSelectedCategoryId('id-cards');
            setCurrentPage('products');
          }}
          className="hover:text-green-400 transition cursor-pointer"
        >
          ID Cards
        </button>

        <button
          onClick={() => {
            setSelectedCategoryId('tshirt-printing');
            setCurrentPage('products');
          }}
          className="hover:text-green-400 transition cursor-pointer"
        >
          T-Shirt Printing
        </button>

        <button
          onClick={() => {
            setSelectedCategoryId(null);
            setCurrentPage('products');
          }}
          className="text-red-400 font-bold hover:text-green-400 transition cursor-pointer flex items-center gap-1"
        >
          <Flame className="w-3.5 h-3.5 text-red-400" />
          <span>Today's Deals</span>
        </button>

        <button
          onClick={() => setCurrentPage('digital-services')}
          className="text-blue-400 hover:text-green-400 transition cursor-pointer flex items-center gap-1"
        >
          <Laptop className="w-3.5 h-3.5 text-blue-400" />
          <span>Digital Services</span>
        </button>

        <button
          onClick={() => {
            setSelectedCategoryId('wedding-cards');
            setCurrentPage('products');
          }}
          className="hover:text-green-400 transition cursor-pointer"
        >
          Wedding Products
        </button>

        <button
          onClick={() => setCurrentPage('custom-order')}
          className="hover:text-green-400 transition cursor-pointer border-l border-slate-600 pl-4"
        >
          Custom Order
        </button>
      </div>
    </nav>
  );
};
