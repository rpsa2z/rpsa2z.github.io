import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Search,
  MapPin,
  ShoppingCart,
  Heart,
  User,
  Bell,
  Headphones,
  Globe,
  Package,
  Sliders,
  ChevronDown,
  X,
  Shield,
  Bike,
  Sparkles,
  CheckCircle,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    setCurrentPage,
    setSelectedProductId,
    setSelectedCategoryId,
    deliveryPincode,
    setIsLocationModalOpen,
    searchQuery,
    setSearchQuery,
    currentLanguage,
    setCurrentLanguage,
    products,
    categories,
    cart,
    wishlist,
    notifications,
    user,
    logoutUser,
    adminLoggedIn,
    deliveryBoyLoggedIn,
    settings,
  } = useStore();

  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
      if (accountRef.current && !accountRef.current.contains(e.target as Node)) {
        setIsAccountOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filtered search suggestions
  const cleanQuery = searchQuery.trim().toLowerCase();
  const matchedProducts = cleanQuery
    ? products.filter(
        (p) =>
          p.name.toLowerCase().includes(cleanQuery) ||
          p.id.toLowerCase().includes(cleanQuery) ||
          p.sku.toLowerCase().includes(cleanQuery) ||
          p.category.toLowerCase().includes(cleanQuery) ||
          p.description.toLowerCase().includes(cleanQuery)
      ).slice(0, 5)
    : [];

  const matchedCategories = cleanQuery
    ? categories.filter((c) => c.name.toLowerCase().includes(cleanQuery)).slice(0, 3)
    : [];

  const totalCartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const unreadNotifCount = notifications.filter((n) => !n.read).length;

  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (cleanQuery) {
      setCurrentPage('products');
      setIsSearchFocused(false);
    }
  };

  return (
    <header id="main-header" className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Utility Announcement Bar */}
      <div className="bg-slate-900 text-slate-300 text-[11px] py-1.5 px-4 hidden sm:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Flat 15% OFF on Custom Printing with Code: <strong>PRINT15</strong></span>
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400">Complete Printing & Digital Hub</span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={`tel:${settings.mobileNumber || '8090524232'}`}
              className="hover:text-white transition flex items-center gap-1"
            >
              <Headphones className="w-3 h-3 text-red-400" />
              <span>Call Us: +91 {settings.mobileNumber || '8090524232'}</span>
            </a>
            <span className="text-slate-600">|</span>
            <button
              onClick={() => setCurrentPage('admin')}
              className="hover:text-white transition flex items-center gap-1 text-slate-400 hover:text-red-400"
            >
              <Shield className="w-3 h-3" />
              <span>Admin Portal</span>
            </button>
            <span className="text-slate-600">|</span>
            <button
              onClick={() => setCurrentPage('delivery-boy')}
              className="hover:text-white transition flex items-center gap-1 text-slate-400 hover:text-emerald-400"
            >
              <Bike className="w-3 h-3" />
              <span>Rider Portal</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Row - High Density Theme */}
      <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between gap-4 sm:gap-6">
        {/* Brand Logo & Deliver To */}
        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          <div
            id="brand-logo"
            onClick={() => {
              setSelectedCategoryId(null);
              setSelectedProductId(null);
              setCurrentPage('home');
            }}
            className="cursor-pointer select-none group flex flex-col"
          >
            <div className="text-xl sm:text-2xl font-black tracking-tighter flex items-center">
              <span className="text-red-600">RPS</span>
              <span className="text-green-600 ml-1">A2Z</span>
              <span className="text-blue-600 ml-1">SERVICES</span>
            </div>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest hidden sm:block -mt-1">
              Printing & Digital Hub
            </span>
          </div>

          {/* Location Indicator */}
          <div
            id="header-location-btn"
            onClick={() => setIsLocationModalOpen(true)}
            className="flex flex-col text-[10px] border-l pl-3 border-slate-300 ml-1 cursor-pointer group"
          >
            <span className="text-slate-400 uppercase font-bold tracking-widest">Deliver to</span>
            <span className="font-bold flex items-center text-slate-700 group-hover:text-red-600 transition">
              <MapPin className="w-3 h-3 mr-1 text-red-600 shrink-0" />
              <span className="truncate max-w-[100px] sm:max-w-none">Lucknow, {deliveryPincode}</span>
            </span>
          </div>
        </div>

        {/* High Density Search Bar with Blue Border & Button */}
        <div ref={searchRef} className="flex-1 max-w-2xl relative">
          <form onSubmit={handleSearchSubmit} className="flex items-stretch">
            <div className="relative flex-1">
              <input
                id="header-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="Search products, printing services, gifts, stationery and more..."
                className="w-full border-2 border-blue-600 rounded-l-md px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm focus:outline-none placeholder-slate-400 text-slate-800"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <button
              id="header-search-submit-btn"
              type="submit"
              className="bg-blue-600 text-white px-4 sm:px-6 rounded-r-md hover:bg-blue-700 transition-colors flex items-center justify-center shrink-0"
              aria-label="Search"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </form>

          {/* Autocomplete Suggestions Popover */}
          {isSearchFocused && cleanQuery.length > 0 && (
            <div
              id="search-suggestions-popover"
              className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50 text-xs animate-in fade-in zoom-in-95 duration-150"
            >
              {/* Category matches */}
              {matchedCategories.length > 0 && (
                <div className="p-2 border-b border-slate-100 bg-slate-50/70">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2">
                    Categories
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {matchedCategories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setSelectedCategoryId(cat.id);
                          setCurrentPage('products');
                          setIsSearchFocused(false);
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-red-50 border border-slate-200 hover:border-red-200 rounded-lg text-slate-700 hover:text-red-700 text-xs font-medium transition"
                      >
                        {cat.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Product matches */}
              {matchedProducts.length > 0 ? (
                <div className="p-2 divide-y divide-slate-100">
                  {matchedProducts.map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => {
                        setSelectedProductId(prod.id);
                        setCurrentPage('product-detail');
                        setIsSearchFocused(false);
                      }}
                      className="p-2 hover:bg-slate-50 rounded-lg cursor-pointer flex items-center gap-3 transition"
                    >
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        className="w-10 h-10 object-cover rounded-md border border-slate-200 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-800 truncate">{prod.name}</p>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500">
                          <span className="text-red-600 font-bold">₹{prod.price}</span>
                          <span className="line-through text-slate-400">₹{prod.mrp}</span>
                          <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">
                            {prod.id}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-center text-slate-500">
                  <p className="font-medium">No direct matches found for "{searchQuery}"</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Press Enter to view all products or browse by category.
                  </p>
                </div>
              )}

              <div className="p-2 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Searching Products, Services & IDs</span>
                <button
                  onClick={() => {
                    setCurrentPage('products');
                    setIsSearchFocused(false);
                  }}
                  className="font-bold text-red-600 hover:text-red-700"
                >
                  View All Search Results →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Navigation Actions: Account, Wishlist, Cart, Support */}
        <div className="flex items-center gap-3 sm:gap-5 text-slate-600 shrink-0">
          {/* Account Dropdown */}
          <div ref={accountRef} className="relative">
            <div
              id="header-account-btn"
              onClick={() => setIsAccountOpen(!isAccountOpen)}
              className="flex flex-col items-center cursor-pointer select-none hover:text-blue-600 transition"
            >
              <span className="text-[10px] font-bold text-slate-400">
                {user ? `Hello, ${user.name.split(' ')[0]}` : 'Hello, Login'}
              </span>
              <span className="text-xs font-black text-slate-800 flex items-center gap-0.5">
                <span>Account</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </span>
            </div>

            {isAccountOpen && (
              <div
                id="header-account-popover"
                className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50 text-xs animate-in fade-in zoom-in-95 duration-150"
              >
                <div className="p-3 bg-slate-50 border-b border-slate-100">
                  <p className="font-bold text-slate-900 text-sm">{user.name}</p>
                  <p className="text-[11px] text-slate-500">{user.email || user.mobile}</p>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded">
                      Customer Profile
                    </span>
                  </div>
                </div>

                <div className="p-1.5 space-y-0.5">
                  <button
                    onClick={() => {
                      setCurrentPage('customer-dashboard');
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-slate-100 rounded-lg font-medium text-slate-700 flex items-center gap-2.5"
                  >
                    <User className="w-4 h-4 text-slate-500" />
                    <span>My Dashboard & Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      setCurrentPage('my-orders');
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-slate-100 rounded-lg font-medium text-slate-700 flex items-center gap-2.5"
                  >
                    <Package className="w-4 h-4 text-blue-600" />
                    <span>My Orders & Tracking</span>
                  </button>

                  <button
                    onClick={() => {
                      setCurrentPage('custom-order');
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-slate-100 rounded-lg font-medium text-slate-700 flex items-center gap-2.5"
                  >
                    <Sliders className="w-4 h-4 text-emerald-600" />
                    <span>Custom Bulk Order</span>
                  </button>

                  <button
                    onClick={() => {
                      setCurrentPage('about-contact');
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-slate-100 rounded-lg font-medium text-slate-700 flex items-center gap-2.5"
                  >
                    <Headphones className="w-4 h-4 text-amber-600" />
                    <span>Help & Customer Support</span>
                  </button>
                </div>

                <div className="p-1.5 border-t border-slate-100 bg-slate-50/60 space-y-0.5">
                  <button
                    onClick={() => {
                      setCurrentPage('admin');
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-red-50 text-red-700 rounded-lg font-semibold flex items-center gap-2 text-[11px]"
                  >
                    <Shield className="w-3.5 h-3.5 text-red-600" />
                    <span>Admin Control Center</span>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentPage('delivery-boy');
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-emerald-50 text-emerald-700 rounded-lg font-semibold flex items-center gap-2 text-[11px]"
                  >
                    <Bike className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Delivery Rider Login</span>
                  </button>
                </div>

                <div className="p-1.5 border-t border-slate-100">
                  <button
                    onClick={() => {
                      logoutUser();
                      setIsAccountOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-slate-500 hover:text-red-600 hover:bg-slate-50 rounded-lg text-xs font-medium"
                  >
                    Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Wishlist Icon with Red Badge */}
          <div
            id="header-wishlist-btn"
            onClick={() => setCurrentPage('customer-dashboard')}
            className="relative cursor-pointer group text-slate-600 hover:text-red-600 transition p-1"
            title="Wishlist"
          >
            <Heart className="w-6 h-6" />
            <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
              {wishlist.length}
            </span>
          </div>

          {/* Shopping Cart Icon with Green Badge */}
          <div
            id="header-cart-btn"
            onClick={() => setCurrentPage('cart')}
            className="relative cursor-pointer text-slate-600 hover:text-green-600 transition p-1"
            title="Shopping Cart"
          >
            <ShoppingCart className="w-6 h-6" />
            <span className="absolute -top-1 -right-1 bg-green-600 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
              {totalCartCount}
            </span>
          </div>

          {/* Direct Support Icon Button */}
          <div
            onClick={() => setCurrentPage('about-contact')}
            className="bg-slate-100 p-2 rounded-full cursor-pointer hover:bg-slate-200 transition text-blue-600"
            title="Customer Support & Helpline"
          >
            <Headphones className="w-5 h-5" />
          </div>
        </div>
      </div>
    </header>
  );
};
