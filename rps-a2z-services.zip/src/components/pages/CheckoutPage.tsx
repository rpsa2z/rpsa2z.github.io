import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { CustomerAddress, PaymentMethod } from '../../types';
import {
  MapPin,
  CreditCard,
  QrCode,
  Truck,
  CheckCircle2,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Phone,
  Building,
} from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    deliveryPincode,
    getCartTotals,
    placeOrder,
    setCurrentPage,
    setActiveTrackingOrderId,
    appliedCoupon,
    addToast,
  } = useStore();

  const totals = getCartTotals();

  // Address State
  const [fullName, setFullName] = useState('Rahul Verma');
  const [mobile, setMobile] = useState('8090524232');
  const [altMobile, setAltMobile] = useState('');
  const [email, setEmail] = useState('rahul.verma@example.com');
  const [pinCode, setPinCode] = useState(deliveryPincode);
  const [house, setHouse] = useState('House 42-B');
  const [street, setStreet] = useState('RPS Digital Complex Road');
  const [area, setArea] = useState('Hazratganj');
  const [landmark, setLandmark] = useState('Near Metro Station');
  const [city, setCity] = useState('Lucknow');
  const [district, setDistrict] = useState('Lucknow');
  const [state, setState] = useState('Uttar Pradesh');

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [upiUpiId, setUpiId] = useState('8090524232@upi');
  const [isProcessing, setIsProcessing] = useState(false);

  if (cart.length === 0) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center text-slate-800">
        <h2 className="text-xl font-bold text-slate-900">Your Cart is Empty</h2>
        <p className="text-xs text-slate-500 mt-2">Please add items to your cart before proceeding to checkout.</p>
        <button
          onClick={() => setCurrentPage('products')}
          className="mt-4 px-6 py-2.5 bg-red-600 text-white rounded-xl text-xs font-bold"
        >
          Browse Products
        </button>
      </div>
    );
  }

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !mobile || !pinCode || !house || !city) {
      addToast('Missing Required Fields', 'Please complete your shipping address');
      return;
    }

    setIsProcessing(true);

    const address: CustomerAddress = {
      fullName,
      mobile,
      altMobile: altMobile || undefined,
      email,
      pinCode,
      house,
      street,
      area,
      landmark: landmark || undefined,
      city,
      district,
      state,
    };

    setTimeout(() => {
      const order = placeOrder(address, paymentMethod);
      setIsProcessing(false);
      setActiveTrackingOrderId(order.id);
      setCurrentPage('order-tracking');
      addToast('Order Placed Successfully!', `Order #${order.id} registered.`);
    }, 1200);
  };

  return (
    <div id="checkout-page-container" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      <div className="pb-4 mb-6 border-b border-slate-200">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900">Secure Checkout</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Fast and safe checkout powered by RPS A2Z SERVICES digital payments & COD
        </p>
      </div>

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Address & Payment Form (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* 1. SHIPPING ADDRESS */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <div className="w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center font-bold text-xs">
                1
              </div>
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Delivery Address Information
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Recipient Full Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Number (Primary) *</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Alternate Phone (Optional)</label>
                <input
                  type="tel"
                  maxLength={10}
                  value={altMobile}
                  onChange={(e) => setAltMobile(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 9876543210"
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Email for Invoice & Updates *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">6-Digit PIN Code *</label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={pinCode}
                  onChange={(e) => setPinCode(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Flat / House No. / Building *</label>
                <input
                  type="text"
                  required
                  value={house}
                  onChange={(e) => setHouse(e.target.value)}
                  placeholder="e.g. Flat 301, Tower A"
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Street / Colony / Mohalla *</label>
                <input
                  type="text"
                  required
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Area / Sector *</label>
                <input
                  type="text"
                  required
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Landmark (Optional)</label>
                <input
                  type="text"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="e.g. Near Shiv Mandir or Petrol Pump"
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">City / Town *</label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">District *</label>
                <input
                  type="text"
                  required
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">State *</label>
                <input
                  type="text"
                  required
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl font-medium"
                />
              </div>
            </div>
          </div>

          {/* 2. PAYMENT METHOD SELECTION */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <div className="w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center font-bold text-xs">
                2
              </div>
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Select Payment Method
              </h2>
            </div>

            <div className="space-y-2.5">
              {/* UPI */}
              <div
                onClick={() => setPaymentMethod('UPI')}
                className={`p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'UPI'
                    ? 'border-emerald-600 bg-emerald-50/40 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                      <QrCode className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-xs">UPI Instant Payment (Fastest)</p>
                      <p className="text-[11px] text-slate-500">Google Pay, PhonePe, Paytm, BHIM</p>
                    </div>
                  </div>
                  {paymentMethod === 'UPI' && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                </div>

                {paymentMethod === 'UPI' && (
                  <div className="mt-3 pt-3 border-t border-emerald-200/60 text-xs space-y-2">
                    <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-emerald-200">
                      <span className="text-slate-500">Business UPI ID:</span>
                      <strong className="text-emerald-700">8090524232@upi</strong>
                    </div>
                    <p className="text-[11px] text-emerald-700">
                      Zero convenience fee. Instant confirmation and printing priority queue.
                    </p>
                  </div>
                )}
              </div>

              {/* Cash On Delivery */}
              <div
                onClick={() => setPaymentMethod('COD')}
                className={`p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'COD'
                    ? 'border-red-600 bg-red-50/40 ring-2 ring-red-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-xs">Cash on Delivery (COD)</p>
                      <p className="text-[11px] text-slate-500">Pay cash or UPI at your doorstep upon delivery</p>
                    </div>
                  </div>
                  {paymentMethod === 'COD' && <CheckCircle2 className="w-5 h-5 text-red-600" />}
                </div>
              </div>

              {/* Cards */}
              <div
                onClick={() => setPaymentMethod('Card')}
                className={`p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'Card'
                    ? 'border-blue-600 bg-blue-50/40 ring-2 ring-blue-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
                      <CreditCard className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-xs">Debit / Credit Card</p>
                      <p className="text-[11px] text-slate-500">Visa, Mastercard, RuPay, Maestro</p>
                    </div>
                  </div>
                  {paymentMethod === 'Card' && <CheckCircle2 className="w-5 h-5 text-blue-600" />}
                </div>
              </div>

              {/* Net Banking */}
              <div
                onClick={() => setPaymentMethod('NetBanking')}
                className={`p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'NetBanking'
                    ? 'border-purple-600 bg-purple-50/40 ring-2 ring-purple-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
                      <Building className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-xs">Net Banking</p>
                      <p className="text-[11px] text-slate-500">SBI, HDFC, ICICI, Axis, PNB, Bank of Baroda</p>
                    </div>
                  </div>
                  {paymentMethod === 'NetBanking' && <CheckCircle2 className="w-5 h-5 text-purple-600" />}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Summary & Place Order (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider pb-3 border-b border-slate-100">
              Items in Order ({cart.length})
            </h3>

            {/* Quick mini-cart list */}
            <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 pr-1">
              {cart.map((c) => (
                <div key={c.id} className="py-2.5 flex items-center gap-2.5">
                  <img
                    src={c.customization?.uploadedImages?.[0] || c.product.images[0]}
                    alt={c.product.name}
                    className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-slate-800 truncate">{c.product.name}</p>
                    <p className="text-[10px] text-slate-400">Qty: {c.quantity} × ₹{c.unitPrice}</p>
                  </div>
                  <span className="font-bold text-slate-900 shrink-0">₹{c.totalPrice}</span>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="space-y-2 pt-3 border-t border-slate-100">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-semibold">₹{totals.subtotal}</span>
              </div>
              {totals.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Coupon ({appliedCoupon?.code})</span>
                  <span>- ₹{totals.discount}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Delivery Charge</span>
                <span>{totals.deliveryCharge === 0 ? 'FREE' : `₹${totals.deliveryCharge}`}</span>
              </div>
              <div className="flex justify-between text-slate-500 text-[11px]">
                <span>GST (18% Included)</span>
                <span>₹{totals.gstAmount}</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
                <span className="text-sm font-bold text-slate-900">Total Payable</span>
                <span className="text-2xl font-black text-red-600">₹{totals.grandTotal}</span>
              </div>
            </div>

            {/* Place Order CTA Button */}
            <button
              id="confirm-place-order-btn"
              type="submit"
              disabled={isProcessing}
              className="w-full py-3.5 bg-red-600 hover:bg-red-700 disabled:bg-slate-400 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition shadow-md active:scale-95"
            >
              {isProcessing ? (
                <span>Generating Order Reference...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Place Order & Pay (₹{totals.grandTotal})</span>
                </>
              )}
            </button>

            <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-500 justify-center">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>256-Bit SSL Encrypted & Genuine Invoice Guarantee</span>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
