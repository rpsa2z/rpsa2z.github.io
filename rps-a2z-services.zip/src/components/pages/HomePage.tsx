import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from '../products/ProductCard';
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Flame,
  Clock,
  ArrowRight,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  Printer,
  Frame,
  Gift,
  Laptop,
  CheckCircle2,
  Star,
  MessageCircle,
  FileCheck,
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const {
    banners,
    categories,
    products,
    reviews,
    setSelectedCategoryId,
    setCurrentPage,
    setSelectedProductId,
    settings,
  } = useStore();

  const [activeBannerIndex, setActiveBannerIndex] = useState(0);

  // Auto slide banners
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveBannerIndex((prev) => (prev + 1) % banners.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [banners.length]);

  const currentBanner = banners[activeBannerIndex] || banners[0];

  const todayDeals = products.filter((p) => p.isTodayDeal);
  const bestSellers = products.filter((p) => p.isBestSeller);
  const photoFrames = products.filter((p) => p.category === 'photo-frames');
  const customizedGifts = products.filter(
    (p) => p.category === 'customized-gifts' || p.category === 'mug-printing' || p.category === 'keychains'
  );
  const stationeryItems = products.filter(
    (p) => p.category === 'stationery' || p.category === 'document-services' || p.category === 'visiting-cards'
  );

  return (
    <div id="homepage-content" className="space-y-8 pb-14">
      {/* 1. HERO SECTION: 12-COL HIGH DENSITY GRID (8-COL HERO + 4-COL STACKED CARDS) */}
      <section id="hero-banner-slider" className="max-w-7xl mx-auto px-4 pt-4">
        <div className="grid grid-cols-12 gap-4 sm:gap-5">
          {/* Col 8 Hero Banner */}
          <div className="col-span-12 lg:col-span-8 bg-gradient-to-r from-blue-700 via-blue-600 to-blue-500 rounded-2xl p-6 sm:p-8 text-white flex flex-col justify-center relative overflow-hidden min-h-[280px] shadow-sm">
            {/* Background image tint */}
            <div className="absolute inset-0 z-0">
              <img
                src={currentBanner.image}
                alt={currentBanner.title}
                className="w-full h-full object-cover opacity-20 mix-blend-overlay scale-105 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-900/60 to-transparent" />
            </div>

            <div className="relative z-10 max-w-xl">
              <span className="bg-white/20 px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider backdrop-blur-xs inline-block">
                {currentBanner.discountBadge || 'Special Offer'}
              </span>

              <h1 className="text-2xl sm:text-4xl font-black mt-3 mb-2 leading-tight tracking-tight">
                {currentBanner.title}
              </h1>

              <p className="text-blue-50 opacity-90 max-w-sm mb-6 text-xs sm:text-sm leading-relaxed">
                {currentBanner.subtitle}
              </p>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => {
                    setSelectedCategoryId(currentBanner.targetCategoryOrProduct);
                    setCurrentPage('products');
                  }}
                  className="bg-white text-blue-700 px-6 sm:px-8 py-2.5 sm:py-3 rounded-xl font-bold hover:shadow-lg transition-all text-xs sm:text-sm active:scale-95"
                >
                  {currentBanner.buttonText || 'Order Now'}
                </button>

                <button
                  onClick={() => setCurrentPage('photo-frame-customizer')}
                  className="bg-blue-600/40 border border-white/40 text-white px-6 sm:px-8 py-2.5 sm:py-3 rounded-xl font-bold backdrop-blur-sm text-xs sm:text-sm hover:bg-blue-600/60 transition active:scale-95"
                >
                  View Styles
                </button>
              </div>
            </div>

            {/* Slider Dots */}
            <div className="absolute bottom-4 right-4 z-20 flex items-center gap-1.5 bg-black/20 backdrop-blur-xs px-2.5 py-1 rounded-full">
              {banners.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveBannerIndex(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    activeBannerIndex === idx ? 'w-5 bg-white' : 'w-1.5 bg-white/40 hover:bg-white/70'
                  }`}
                  aria-label={`Slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>

          {/* Col 4 Stacked Promo Cards */}
          <div className="col-span-12 lg:col-span-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
            {/* Top Green Card */}
            <div
              onClick={() => {
                setSelectedCategoryId('visiting-cards');
                setCurrentPage('products');
              }}
              className="bg-green-600 rounded-2xl p-5 sm:p-6 text-white relative overflow-hidden flex flex-col justify-between cursor-pointer hover:shadow-md hover:scale-[1.01] transition min-h-[130px]"
            >
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                  Business Essentials
                </span>
                <h3 className="text-lg sm:text-xl font-bold mt-1 leading-snug">Visiting Cards</h3>
                <p className="text-xs mt-1 text-green-50">500 Premium Cards from ₹299</p>
              </div>
              <span className="mt-3 text-xs font-bold underline inline-flex items-center gap-1">
                Create Your Own →
              </span>
            </div>

            {/* Bottom Red Card */}
            <div
              onClick={() => {
                setSelectedCategoryId('tshirt-printing');
                setCurrentPage('products');
              }}
              className="bg-red-600 rounded-2xl p-5 sm:p-6 text-white relative overflow-hidden flex flex-col justify-between cursor-pointer hover:shadow-md hover:scale-[1.01] transition min-h-[130px]"
            >
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                  New Service
                </span>
                <h3 className="text-lg sm:text-xl font-bold mt-1 leading-snug">T-Shirt Printing</h3>
                <p className="text-xs mt-1 text-red-50">Bulk & Individual Orders Available</p>
              </div>
              <span className="mt-3 text-xs font-bold underline inline-flex items-center gap-1">
                Get Quote →
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. TRUST ASSURANCE ROW - COMPACT */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-3.5 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center shrink-0">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">HD Printing Quality</p>
              <p className="text-[10px] text-slate-500">260-350 GSM Genuine Stock</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <Truck className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">Express Local Delivery</p>
              <p className="text-[10px] text-slate-500">Same day dispatch available</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">Design Approval First</p>
              <p className="text-[10px] text-slate-500">Print only after your preview</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
              <Headphones className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">Direct Phone Support</p>
              <p className="text-[10px] text-slate-500">Call/WhatsApp: 8090524232</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. SHOP BY CATEGORY (HIGH DENSITY GRID) */}
      <section id="shop-by-category-section" className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <span className="w-2 h-6 bg-red-600 rounded-full"></span>
            <span>Shop by Category</span>
          </h2>
          <button
            onClick={() => {
              setSelectedCategoryId(null);
              setCurrentPage('products');
            }}
            className="text-blue-600 text-sm font-bold flex items-center hover:underline"
          >
            <span>View All ({categories.length})</span>
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {categories.slice(0, 12).map((cat) => (
            <div
              key={cat.id}
              onClick={() => {
                if (cat.id === 'photo-frames') {
                  setCurrentPage('photo-frame-customizer');
                } else if (cat.id === 'custom-order') {
                  setCurrentPage('custom-order');
                } else if (cat.id === 'digital-services') {
                  setCurrentPage('digital-services');
                } else {
                  setSelectedCategoryId(cat.id);
                  setCurrentPage('products');
                }
              }}
              className="bg-white rounded-xl border border-slate-200 hover:border-blue-400 p-3 flex flex-col items-center text-center cursor-pointer transition hover:shadow-md group"
            >
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden mb-2 bg-slate-100 border border-slate-200 group-hover:scale-105 transition">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h3 className="text-xs font-bold text-slate-800 group-hover:text-blue-600 transition line-clamp-1">
                {cat.name}
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">{cat.itemCount} items</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. TODAY'S DEALS SECTION (HIGH DENSITY) */}
      {todayDeals.length > 0 && (
        <section id="todays-deals-section" className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-3.5">
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <span className="w-2 h-6 bg-red-600 rounded-full"></span>
              <span>Today's Flash Deals</span>
            </h2>
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-3 py-1 rounded-md text-xs font-bold border border-red-200">
              <Clock className="w-3.5 h-3.5 text-red-600" />
              <span>Ends Tonight 11:59 PM</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {todayDeals.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}

      {/* 5. BEST SELLING PRODUCTS (HIGH DENSITY 4-COL GRID) */}
      <section id="best-sellers-section" className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <span className="w-2 h-6 bg-red-600 rounded-full"></span>
            <span>Best Selling Products</span>
          </h2>
          <button
            onClick={() => {
              setSelectedCategoryId(null);
              setCurrentPage('products');
            }}
            className="text-blue-600 text-sm font-bold flex items-center hover:underline"
          >
            <span>View All</span>
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 6. PHOTO FRAMES SHOWCASE */}
      <section id="photo-frames-showcase" className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <span className="w-2 h-6 bg-green-600 rounded-full"></span>
            <span>Custom Photo Frames & Collage Art</span>
          </h2>
          <button
            onClick={() => setCurrentPage('photo-frame-customizer')}
            className="text-blue-600 text-sm font-bold flex items-center hover:underline"
          >
            <span>Launch 3D Customizer</span>
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
          {/* Promo Card */}
          <div className="bg-slate-900 rounded-xl p-5 text-white flex flex-col justify-between border border-slate-800">
            <div>
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
                All Sizes Available
              </span>
              <h3 className="text-xl font-black mt-2 leading-tight">
                4x6" to 18x24" Custom Sizes
              </h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Choose from Teak Wood, Walnut, Classic Gold, Matte Black and Deep Box Frames with unbreakable acrylic glass and HD 260 GSM photo printing.
              </p>
              <div className="mt-4 space-y-1.5 text-xs text-slate-200">
                <p className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Free photo editing & color enhancement</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Safe thermocol 5-layer bubble packaging</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => setCurrentPage('photo-frame-customizer')}
              className="mt-5 w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs transition text-center shadow-xs"
            >
              Configure Photo Frame Now →
            </button>
          </div>

          {/* Products */}
          <div className="md:col-span-2 grid grid-cols-2 gap-4">
            {photoFrames.slice(0, 2).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* 7. DIGITAL SERVICES SECTION (Section 44 with required official disclaimer) */}
      <section id="digital-services-hub" className="max-w-7xl mx-auto px-4">
        <div className="bg-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-blue-400 bg-blue-900/50 px-2.5 py-0.5 rounded border border-blue-700/50">
                Digital & Cyber Services Hub
              </span>
              <h2 className="text-xl sm:text-2xl font-black mt-2">
                Document, Application & Digital Services
              </h2>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                Quick assistance for online examination forms, PAN card assistance, Aadhaar PVC prints, resume building, document scanning and project lamination.
              </p>
            </div>

            <button
              onClick={() => setCurrentPage('digital-services')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold self-start sm:self-auto transition shadow-xs shrink-0"
            >
              View All Digital Services →
            </button>
          </div>

          {/* Crucial Required Disclaimer as stated in Prompt Section 44 */}
          <div className="mt-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs font-medium flex items-start gap-2">
            <span className="font-bold shrink-0">⚠️ Disclaimer:</span>
            <span>
              RPS A2Z SERVICES is an independent service provider and is not an official government website. We provide technical assistance, form printing, and documentation services.
            </span>
          </div>

          {/* Quick Digital Service Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
            {[
              { title: 'PAN Card Assistance', desc: 'New / correction filing & PVC print', icon: <Laptop className="w-5 h-5 text-blue-400" /> },
              { title: 'Resume Designing', desc: 'ATS standard formats & prints', icon: <Printer className="w-5 h-5 text-emerald-400" /> },
              { title: 'Aadhaar Card Print', desc: 'High-res PVC card assistance', icon: <FileCheck className="w-5 h-5 text-amber-400" /> },
              { title: 'Spiral & Lamination', desc: 'Project binding up to 300 pages', icon: <Sparkles className="w-5 h-5 text-purple-400" /> },
            ].map((svc, idx) => (
              <div
                key={idx}
                onClick={() => setCurrentPage('digital-services')}
                className="bg-slate-800/80 hover:bg-slate-800 p-3.5 rounded-xl border border-slate-700/80 cursor-pointer transition"
              >
                <div className="mb-2">{svc.icon}</div>
                <h4 className="font-bold text-xs text-white">{svc.title}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">{svc.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. CUSTOMIZED GIFTS SPOTLIGHT */}
      <section id="customized-gifts-section" className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <span className="w-2 h-6 bg-blue-600 rounded-full"></span>
            <span>Customized Gifts & Novelties</span>
          </h2>
          <button
            onClick={() => {
              setSelectedCategoryId('customized-gifts');
              setCurrentPage('products');
            }}
            className="text-blue-600 text-sm font-bold flex items-center hover:underline"
          >
            <span>View All Gifts</span>
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {customizedGifts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 9. STATIONERY & OFFICE PRODUCTS */}
      <section id="stationery-section" className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <span className="w-2 h-6 bg-red-600 rounded-full"></span>
            <span>Stationery & Corporate Printing</span>
          </h2>
          <button
            onClick={() => {
              setSelectedCategoryId('stationery');
              setCurrentPage('products');
            }}
            className="text-blue-600 text-sm font-bold flex items-center hover:underline"
          >
            <span>View All Stationery</span>
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stationeryItems.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 10. CUSTOMER REVIEWS */}
      <section id="customer-reviews-section" className="max-w-7xl mx-auto px-4">
        <div className="bg-white rounded-2xl p-6 border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <span className="w-2 h-6 bg-amber-500 rounded-full"></span>
              <span>Verified Customer Feedback</span>
            </h2>
            <span className="text-xs text-slate-500">4.9/5 Average Rating</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {reviews.slice(0, 3).map((rev) => (
              <div
                key={rev.id}
                className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-1 mb-1.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < rev.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-bold text-slate-800 ml-1">{rev.rating}.0</span>
                  </div>

                  <h4 className="font-bold text-xs text-slate-900">{rev.title}</h4>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed italic">"{rev.comment}"</p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-bold text-slate-800 text-[11px]">{rev.customerName}</p>
                    <p className="text-[10px] text-slate-400">{rev.productName}</p>
                  </div>
                  <span className="text-[9px] bg-emerald-50 text-emerald-700 font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5">
                    <CheckCircle2 className="w-3 h-3" /> Verified
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 11. QUICK CONTACT & WHATSAPP ORDER BANNER */}
      <section id="contact-cta-section" className="max-w-7xl mx-auto px-4">
        <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800 shadow-sm">
          <div>
            <span className="text-xs font-bold text-red-500 uppercase tracking-widest">Instant Support & Orders</span>
            <h3 className="text-xl sm:text-2xl font-black mt-1">Have a Bulk or Custom Order?</h3>
            <p className="text-xs text-slate-300 mt-1.5 max-w-lg">
              Send your files directly via WhatsApp or call our printing specialists at{' '}
              <strong className="text-white">8090524232</strong>. We offer same-day quotes and expedited processing.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href={`https://wa.me/91${settings.whatsappNumber || '8090524232'}?text=${encodeURIComponent(
                'Hello RPS A2Z SERVICES, I want to inquire about a custom printing order.'
              )}`}
              target="_blank"
              rel="noreferrer"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs sm:text-sm transition flex items-center gap-2 shadow-xs"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Chat on WhatsApp</span>
            </a>

            <button
              onClick={() => setCurrentPage('custom-order')}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs sm:text-sm transition flex items-center gap-2 shadow-xs"
            >
              <FileCheck className="w-4 h-4" />
              <span>Submit Custom Form</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
