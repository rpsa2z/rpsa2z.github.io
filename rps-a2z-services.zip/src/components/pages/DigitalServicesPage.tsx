import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Laptop,
  FileText,
  IdCard,
  CreditCard,
  Camera,
  Layers,
  CheckCircle2,
  Lock,
  Upload,
  Send,
  AlertTriangle,
  HelpCircle,
  Clock,
  Printer,
} from 'lucide-react';

export const DigitalServicesPage: React.FC = () => {
  const { addToast, setCurrentPage } = useStore();

  const [selectedService, setSelectedService] = useState<string>('pan-card');
  const [applicantName, setApplicantName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [remarks, setRemarks] = useState('');
  const [docUploaded, setDocUploaded] = useState(false);
  const [isBooked, setIsBooked] = useState(false);

  const serviceCategories = [
    {
      id: 'pan-card',
      title: 'PAN Card Assistance & PVC Print',
      rate: '₹180',
      eta: '24-48 Hours',
      desc: 'Assistance in filing new application, address/name correction, and high-density PVC card printout.',
      icon: <CreditCard className="w-6 h-6 text-blue-600" />,
      requirements: ['Aadhaar Card Copy', 'Passport Photo', 'Old PAN copy (if correction)'],
    },
    {
      id: 'exam-form',
      title: 'Online Examination & Admission Form',
      rate: '₹120',
      eta: 'Instant / Same Day',
      desc: 'Expert online application filling for SSC, UPSC, UP Police, Railway, CUET, NEET, and university entrance exams.',
      icon: <FileText className="w-6 h-6 text-emerald-600" />,
      requirements: ['10th/12th Marksheet', 'Signature scan', 'Photo scan', 'Category certificate (if applicable)'],
    },
    {
      id: 'aadhaar-pvc',
      title: 'Aadhaar PVC Card Printout',
      rate: '₹70',
      eta: '1-2 Hours',
      desc: 'Waterproof durable PVC card print with QR code, hologram simulation and UV resistant lamination.',
      icon: <IdCard className="w-6 h-6 text-amber-600" />,
      requirements: ['Aadhaar PDF / OTP authorization', 'Delivery address'],
    },
    {
      id: 'passport-photo',
      title: 'Passport Photo Studio Package',
      rate: '₹80',
      eta: '15 Minutes',
      desc: 'Set of 16 glossy passport size photographs with pure white or blue background and facial retouching.',
      icon: <Camera className="w-6 h-6 text-rose-600" />,
      requirements: ['Digital selfie / existing portrait image'],
    },
    {
      id: 'resume-creation',
      title: 'Professional Resume & CV Building',
      rate: '₹250',
      eta: '2-4 Hours',
      desc: 'Modern ATS-friendly resume formatting in PDF and Word formats + 5 physical printouts on 100 GSM bond paper.',
      icon: <Laptop className="w-6 h-6 text-indigo-600" />,
      requirements: ['Current experience details', 'Educational history', 'Contact details'],
    },
    {
      id: 'spiral-lamination',
      title: 'Project Binding & Heavy Lamination',
      rate: '₹60',
      eta: 'Same Day',
      desc: 'Spiral coil binding up to 300 pages with clear plastic front sheet and opaque back cover.',
      icon: <Layers className="w-6 h-6 text-teal-600" />,
      requirements: ['Printed document or PDF for printing'],
    },
  ];

  const activeServiceObj = serviceCategories.find((s) => s.id === selectedService) || serviceCategories[0];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName || !mobileNumber) {
      addToast('Information Needed', 'Please fill applicant name and mobile number.');
      return;
    }
    setIsBooked(true);
    addToast('Service Request Booked', `Our executive will assist you with ${activeServiceObj.title}`);
  };

  return (
    <div id="digital-services-portal" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      {/* Mandatory Official Disclaimer Header */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 flex items-start gap-3 text-xs text-amber-900">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold">Public Consumer Advisory:</h4>
          <p className="mt-0.5 leading-relaxed">
            <strong>RPS A2Z SERVICES is an independent service provider and is not an official government website.</strong> We
            act as an intermediary and assistance center offering computer services, form printing, formatting, scanning, and
            courier deliveries. All official statutory government fees are payable directly to respective departments.
          </p>
        </div>
      </div>

      {/* Main Title */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
          Document & Application Desk
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
          Digital Services & Document Center
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Fast, error-free documentation, online government exam registration, and PVC card printing at your doorstep.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Service Selection Grid (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Select Digital Service</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {serviceCategories.map((svc) => (
              <div
                key={svc.id}
                onClick={() => setSelectedService(svc.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all duration-200 flex flex-col justify-between ${
                  selectedService === svc.id
                    ? 'border-blue-600 bg-blue-50/50 shadow-md ring-2 ring-blue-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/70'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="p-2 bg-slate-100 rounded-xl">{svc.icon}</div>
                    <span className="text-sm font-black text-slate-900">{svc.rate}</span>
                  </div>
                  <h3 className="font-bold text-xs text-slate-900 leading-snug">{svc.title}</h3>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{svc.desc}</p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {svc.eta}
                  </span>
                  {selectedService === svc.id && (
                    <span className="text-blue-600 font-bold flex items-center gap-0.5">
                      <CheckCircle2 className="w-3 h-3" /> Selected
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Privacy & Security Guarantee */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center gap-3 text-xs text-slate-600">
            <Lock className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold text-slate-800">100% Data Confidentiality Guarantee</p>
              <p className="text-[11px] text-slate-500">
                Uploaded ID proofs and certificates are stored encrypted and permanently deleted upon successful job dispatch.
              </p>
            </div>
          </div>
        </div>

        {/* Right Application Booking Form (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-xs space-y-5">
          {isBooked ? (
            <div className="py-6 text-center space-y-3">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Service Request Confirmed!</h3>
              <p className="text-xs text-slate-600">
                Thank you, <strong>{applicantName}</strong>. Our digital services desk has received your request for{' '}
                <strong>{activeServiceObj.title}</strong>.
              </p>
              <p className="text-[11px] text-slate-500">
                Our operator will call on <strong>{mobileNumber}</strong> within 15 minutes to verify documents.
              </p>
              <button
                onClick={() => {
                  setIsBooked(false);
                  setCurrentPage('home');
                }}
                className="mt-4 px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold text-xs"
              >
                Done
              </button>
            </div>
          ) : (
            <form onSubmit={handleBooking} className="space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Selected Service</span>
                <h3 className="text-base font-bold text-slate-900">{activeServiceObj.title}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-lg font-black text-blue-600">{activeServiceObj.rate}</span>
                  <span className="text-[11px] text-slate-400">Processing Fee</span>
                </div>
              </div>

              {/* Required Documents Checklist */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                <p className="font-bold text-slate-700 text-[11px] mb-1.5 flex items-center gap-1">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
                  <span>Required Documents for this service:</span>
                </p>
                <ul className="space-y-1 text-[11px] text-slate-600">
                  {activeServiceObj.requirements.map((req, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Applicant Full Name *</label>
                <input
                  type="text"
                  required
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  placeholder="As per official Aadhaar / Marksheet"
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">WhatsApp / Contact Mobile *</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 8090524232"
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Upload Documents (PDF or Images)
                </label>
                <div className="border border-dashed border-slate-300 rounded-xl p-3 text-center bg-slate-50 hover:bg-slate-100/60 cursor-pointer transition">
                  <input
                    type="file"
                    id="doc-upload"
                    onChange={() => setDocUploaded(true)}
                    className="hidden"
                  />
                  <label htmlFor="doc-upload" className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-5 h-5 text-blue-600 mb-1" />
                    <span className="font-bold text-slate-700 text-[11px]">
                      {docUploaded ? 'Document Attached (Ready)' : 'Click to Upload Aadhaar / Photo'}
                    </span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Specific Instructions / Form Details</label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="e.g. Need correction in Father's name, or applying for SSC CGL 2026..."
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs transition shadow-md active:scale-95 flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Book Service Assistance</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
