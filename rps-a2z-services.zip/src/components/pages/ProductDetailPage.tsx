import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCustomization } from '../../types';
import {
  Star,
  Heart,
  Share2,
  Truck,
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
  ShoppingCart,
  Zap,
  MessageCircle,
  Upload,
  ArrowRight,
  Sliders,
  Check,
  Eye,
} from 'lucide-react';

export const ProductDetailPage: React.FC = () => {
  const {
    products,
    selectedProductId,
    setSelectedProductId,
    deliveryPincode,
    addToCart,
    toggleWishlist,
    isInWishlist,
    setCurrentPage,
    addToast,
    settings,
  } = useStore();

  const product = products.find((p) => p.id === selectedProductId) || products[0];

  const [selectedImgIdx, setSelectedImgIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [checkPin, setCheckPin] = useState(deliveryPincode);
  const [pinCheckedStatus, setPinCheckedStatus] = useState<string | null>(null);

  // Customization State
  const [uploadedPreview, setUploadedPreview] = useState<string | null>(null);
  const [customText, setCustomText] = useState('');
  const [mugType, setMugType] = useState('Standard Ceramic White');
  const [tshirtSize, setTshirtSize] = useState('L');
  const [tshirtColor, setTshirtColor] = useState('Black');
  const [tshirtPosition, setTshirtPosition] = useState('Front Only');
  const [printSize, setPrintSize] = useState('8x12 Inch');
  const [paperGsm, setPaperGsm] = useState('300 GSM Premium Matte');
  const [lamination, setLamination] = useState('Matte Lamination');
  const [cardSide, setCardSide] = useState<'Single Side' | 'Both Sides'>('Both Sides');
  const [cardQty, setCardQty] = useState(500);
  const [bannerWidth, setBannerWidth] = useState(6);
  const [bannerHeight, setBannerHeight] = useState(3);
  const [bannerType, setBannerType] = useState('Star Flex (High Density)');

  // Calculate live dynamic price based on options
  const calculatedUnitPrice = useMemo(() => {
    let base = product.price;

    // Custom Mug adjustments
    if (product.customizationType === 'mug' && mugType.includes('Magic')) {
      base += 100;
    }

    // T-shirt adjustments
    if (product.customizationType === 'tshirt' && tshirtPosition === 'Both Sides') {
      base += 120;
    }

    // Visiting card quantity adjustments
    if (product.customizationType === 'visiting_card') {
      if (cardQty === 100) base = 250;
      else if (cardQty === 200) base = 420;
      else if (cardQty === 500) base = 699;
      else if (cardQty === 1000) base = 1250;
      if (cardSide === 'Both Sides') base += 150;
    }

    // Banner square feet calculation (Width x Height x rate)
    if (product.customizationType === 'banner') {
      const sqft = bannerWidth * bannerHeight;
      const ratePerSqft = bannerType.includes('Star') ? 25 : 18;
      base = Math.max(150, sqft * ratePerSqft);
    }

    return base;
  }, [product, mugType, tshirtPosition, cardQty, cardSide, bannerWidth, bannerHeight, bannerType]);

  const isFavorite = isInWishlist(product.id);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedPreview(reader.result as string);
        addToast('File Attached', `${file.name} ready for printing preview`);
      };
      reader.readAsDataURL(file);
    }
  };

  const buildCustomizationObject = (): ProductCustomization | undefined => {
    if (!product.isCustomizable) return undefined;

    return {
      type: product.customizationType || 'general',
      uploadedImages: uploadedPreview ? [uploadedPreview] : [],
      customText: customText || undefined,
      notes: `Customized via website preview`,
      printingConfig:
        product.customizationType === 'printing'
          ? {
              printSize,
              paperGsm,
              lamination,
              orientation: 'portrait',
              copies: quantity,
            }
          : undefined,
    };
  };

  const handleAddToCart = () => {
    const customization = buildCustomizationObject();
    addToCart(product, quantity, customization);
  };

  const handleBuyNow = () => {
    const customization = buildCustomizationObject();
    addToCart(product, quantity, customization);
    setCurrentPage('checkout');
  };

  const handleWhatsAppOrder = () => {
    const msg = `Hello RPS A2Z SERVICES, I want to order "${product.name}" (ID: ${product.id}) for ₹${calculatedUnitPrice}. Please confirm file/proof procedure.`;
    const url = `https://wa.me/91${settings.whatsappNumber || '8090524232'}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleCheckPin = () => {
    if (/^\d{6}$/.test(checkPin.trim())) {
      setPinCheckedStatus(`Available! Free delivery to ${checkPin} in 2-3 business days.`);
    } else {
      setPinCheckedStatus('Please enter a valid 6-digit PIN.');
    }
  };

  return (
    <div id="product-detail-container" className="max-w-7xl mx-auto px-4 py-6 pb-20 text-slate-800">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-5">
        <button onClick={() => setCurrentPage('home')} className="hover:text-red-600">Home</button>
        <span>/</span>
        <button onClick={() => setCurrentPage('products')} className="hover:text-red-600">Products</button>
        <span>/</span>
        <span className="font-semibold text-slate-800 truncate">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Visual Gallery (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="relative aspect-square bg-slate-100 rounded-3xl overflow-hidden border border-slate-200 group shadow-xs">
            <img
              src={uploadedPreview || product.images[selectedImgIdx] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />

            {/* Badges */}
            <div className="absolute top-3 left-3 flex flex-col gap-1.5">
              <span className="bg-red-600 text-white text-xs font-black px-2.5 py-1 rounded-lg shadow-sm">
                {product.discountPercentage}% OFF
              </span>
              {uploadedPreview && (
                <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm">
                  Your Custom Photo Loaded
                </span>
              )}
            </div>

            {/* Action buttons on image */}
            <div className="absolute top-3 right-3 flex flex-col gap-2">
              <button
                onClick={() => toggleWishlist(product.id)}
                className={`w-9 h-9 rounded-full bg-white/95 shadow-md flex items-center justify-center transition hover:scale-110 ${
                  isFavorite ? 'text-red-600' : 'text-slate-600'
                }`}
                aria-label="Wishlist"
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-red-600' : ''}`} />
              </button>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  addToast('Link Copied', 'Product link copied to clipboard.');
                }}
                className="w-9 h-9 rounded-full bg-white/95 shadow-md flex items-center justify-center text-slate-600 hover:text-emerald-600 transition hover:scale-110"
                aria-label="Share"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Thumbnail list */}
          {product.images.length > 1 && (
            <div className="flex gap-2.5 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedImgIdx(idx);
                    setUploadedPreview(null);
                  }}
                  className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition shrink-0 ${
                    selectedImgIdx === idx && !uploadedPreview ? 'border-red-600 scale-105' : 'border-slate-200 opacity-70'
                  }`}
                >
                  <img src={img} alt="thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          )}

          {/* Trust Guarantees */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>100% Satisfaction Guarantee</strong> - Reprint or replacement for print defects</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-blue-600 shrink-0" />
              <span><strong>Safe Packaging</strong> - Multi-layer protective bubble wrap & rigid carton</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-amber-600 shrink-0" />
              <span><strong>Design Preview via WhatsApp</strong> - We share proof before final printing</span>
            </div>
          </div>
        </div>

        {/* Right Product Customizer & Order Details (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-red-600 bg-red-50 px-2.5 py-0.5 rounded-md">
                {product.category.replace('-', ' ')}
              </span>
              <span className="text-xs text-slate-400 font-mono">SKU: {product.sku} | ID: {product.id}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 leading-snug">
              {product.name}
            </h1>

            {/* Ratings & Stock */}
            <div className="flex items-center gap-3 mt-2 text-xs">
              <div className="flex items-center gap-1 bg-emerald-600 text-white px-2 py-0.5 rounded-md font-bold">
                <span>{product.rating}</span>
                <Star className="w-3 h-3 fill-white" />
              </div>
              <span className="text-slate-500 font-medium">({product.reviewsCount} customer reviews)</span>
              <span className="text-slate-300">|</span>
              {product.stock > 0 ? (
                <span className="text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> In Stock ({product.stock} available)
                </span>
              ) : (
                <span className="text-red-600 font-bold">Currently Out of Stock</span>
              )}
            </div>
          </div>

          {/* Pricing Box */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-black text-slate-900">₹{calculatedUnitPrice}</span>
              <span className="text-base text-slate-400 line-through">₹{product.mrp}</span>
              <span className="text-sm font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-md">
                {product.discountPercentage}% OFF
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Inclusive of all taxes (GST 18%). Free delivery available on orders above ₹499.
            </p>
          </div>

          {/* 3D Photo Frame Customizer Launcher Banner (if Photo Frame product) */}
          {product.customizationType === 'photo_frame' && (
            <div className="p-4 bg-gradient-to-r from-red-50 to-amber-50 border border-red-200 rounded-2xl flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-900">Interactive 3D Framing Studio</h4>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  Pick wall preview colors, frame thickness, matte borders, and upload your high-res image.
                </p>
              </div>
              <button
                onClick={() => setCurrentPage('photo-frame-customizer')}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shrink-0 shadow-xs"
              >
                <span>Launch Studio</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* DYNAMIC CUSTOMIZATION CONTROLS */}
          {product.isCustomizable && product.customizationType !== 'photo_frame' && (
            <div className="p-5 bg-white rounded-2xl border border-slate-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-red-600" />
                  <span>Customize Your Order</span>
                </span>
                <span className="text-[11px] text-slate-400 font-medium">All options update live</span>
              </div>

              {/* 1. MUG OPTIONS */}
              {product.customizationType === 'mug' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">Select Mug Type</label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {['Standard Ceramic White', 'Color Changing Magic Mug (+₹100)', 'Red Inner Rim Mug', 'Heart Handle Couple Mug'].map((type) => (
                        <button
                          key={type}
                          onClick={() => setMugType(type)}
                          className={`p-2.5 text-left rounded-xl border transition ${
                            mugType === type ? 'border-red-600 bg-red-50 text-red-700 font-bold' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. T-SHIRT OPTIONS */}
              {product.customizationType === 'tshirt' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">T-Shirt Size</label>
                    <div className="flex gap-2 text-xs">
                      {['S', 'M', 'L', 'XL', 'XXL'].map((sz) => (
                        <button
                          key={sz}
                          onClick={() => setTshirtSize(sz)}
                          className={`w-10 h-10 rounded-xl border flex items-center justify-center font-bold transition ${
                            tshirtSize === sz ? 'border-red-600 bg-red-600 text-white' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">Color & Position</label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <select
                        value={tshirtColor}
                        onChange={(e) => setTshirtColor(e.target.value)}
                        className="p-2 border border-slate-200 rounded-xl"
                      >
                        <option value="Black">Fabric: Jet Black</option>
                        <option value="White">Fabric: Pure White</option>
                        <option value="Navy">Fabric: Navy Blue</option>
                        <option value="Maroon">Fabric: Rich Maroon</option>
                      </select>

                      <select
                        value={tshirtPosition}
                        onChange={(e) => setTshirtPosition(e.target.value)}
                        className="p-2 border border-slate-200 rounded-xl"
                      >
                        <option value="Front Only">Front Print Only</option>
                        <option value="Back Only">Back Print Only</option>
                        <option value="Both Sides">Front + Back Both (+₹120)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* 3. VISITING CARD OPTIONS */}
              {product.customizationType === 'visiting_card' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">Quantity (Units)</label>
                    <div className="grid grid-cols-4 gap-2 text-xs">
                      {[100, 200, 500, 1000].map((qty) => (
                        <button
                          key={qty}
                          onClick={() => setCardQty(qty)}
                          className={`p-2 rounded-xl border text-center font-bold transition ${
                            cardQty === qty ? 'border-red-600 bg-red-50 text-red-700' : 'border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {qty} pcs
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Print Sides</label>
                      <select
                        value={cardSide}
                        onChange={(e) => setCardSide(e.target.value as any)}
                        className="w-full p-2 border border-slate-200 rounded-xl"
                      >
                        <option value="Single Side">Single Side</option>
                        <option value="Both Sides">Both Sides (+₹150)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Paper Quality</label>
                      <select
                        value={paperGsm}
                        onChange={(e) => setPaperGsm(e.target.value)}
                        className="w-full p-2 border border-slate-200 rounded-xl"
                      >
                        <option value="350 GSM Glossy Laminated">350 GSM Glossy</option>
                        <option value="350 GSM Velvet Matte">350 GSM Velvet Matte</option>
                        <option value="Metallic Gold Base">Metallic Special Stock</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. FLEX & BANNER OPTIONS */}
              {product.customizationType === 'banner' && (
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Width (Feet)</label>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        value={bannerWidth}
                        onChange={(e) => setBannerWidth(Math.max(1, Number(e.target.value)))}
                        className="w-full p-2 border border-slate-200 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Height (Feet)</label>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        value={bannerHeight}
                        onChange={(e) => setBannerHeight(Math.max(1, Number(e.target.value)))}
                        className="w-full p-2 border border-slate-200 rounded-xl"
                      />
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Total Area: <strong>{bannerWidth * bannerHeight} sq. ft.</strong> | Includes heavy border folding and brass eyelets every 2 feet.
                  </p>
                </div>
              )}

              {/* Photo / Artwork Upload */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Upload Photo, Artwork or Logo (Optional)
                </label>
                <div className="border-2 border-dashed border-slate-300 hover:border-red-400 rounded-2xl p-4 text-center cursor-pointer transition bg-slate-50/50">
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="product-file-upload"
                  />
                  <label htmlFor="product-file-upload" className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-6 h-6 text-red-600 mb-1" />
                    <span className="text-xs font-bold text-slate-800">
                      {uploadedPreview ? 'Change Selected File' : 'Click to Upload High-Res Photo / Logo'}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">JPG, PNG, PDF up to 25MB supported</span>
                  </label>
                </div>
              </div>

              {/* Custom Message / Name input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Custom Name, Date or Message to Print
                </label>
                <input
                  type="text"
                  value={customText}
                  onChange={(e) => setCustomText(e.target.value)}
                  placeholder="e.g. Happy Birthday Rahul, or RPS A2Z SERVICES Pvt Ltd"
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* Delivery PIN Code Checker */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
            <label className="block font-bold text-slate-700 mb-1.5">Check Delivery Speed to Your PIN Code</label>
            <div className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={checkPin}
                onChange={(e) => setCheckPin(e.target.value.replace(/\D/g, ''))}
                placeholder="e.g. 226001"
                className="w-44 px-3 py-2 border border-slate-300 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-semibold"
              />
              <button
                onClick={handleCheckPin}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs transition"
              >
                Check
              </button>
            </div>
            {pinCheckedStatus && (
              <p className="mt-2 font-medium text-emerald-700 flex items-center gap-1 text-[11px]">
                <Check className="w-3.5 h-3.5" />
                <span>{pinCheckedStatus}</span>
              </p>
            )}
          </div>

          {/* Quantity & CTA Buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-slate-700">Quantity:</span>
              <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden bg-white">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3.5 py-2 text-slate-700 hover:bg-slate-100 font-bold"
                >
                  -
                </button>
                <span className="px-4 py-2 text-xs font-bold text-slate-900">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.maxQuantity, quantity + 1))}
                  className="px-3.5 py-2 text-slate-700 hover:bg-slate-100 font-bold"
                >
                  +
                </button>
              </div>
              <span className="text-xs text-slate-400">Total: ₹{calculatedUnitPrice * quantity}</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                id="add-to-cart-detail-btn"
                onClick={handleAddToCart}
                className="flex-1 py-3 px-6 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition active:scale-95 shadow-xs"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Add to Cart</span>
              </button>

              <button
                id="buy-now-detail-btn"
                onClick={handleBuyNow}
                className="flex-1 py-3 px-6 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition active:scale-95 shadow-md"
              >
                <Zap className="w-4 h-4" />
                <span>Buy Now</span>
              </button>

              <button
                onClick={handleWhatsAppOrder}
                className="py-3 px-5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition active:scale-95 shadow-xs shrink-0"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Order</span>
              </button>
            </div>
          </div>

          {/* Product Specifications Table */}
          <div className="pt-4 border-t border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 mb-3 uppercase tracking-wider text-xs">
              Product Specifications
            </h3>
            <div className="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden text-xs">
              <div className="divide-y divide-slate-200">
                <div className="grid grid-cols-3 p-3">
                  <span className="font-semibold text-slate-500">Brand</span>
                  <span className="col-span-2 font-bold text-slate-800">RPS A2Z SERVICES</span>
                </div>
                <div className="grid grid-cols-3 p-3">
                  <span className="font-semibold text-slate-500">Product Code</span>
                  <span className="col-span-2 font-mono text-slate-800">{product.id}</span>
                </div>
                <div className="grid grid-cols-3 p-3">
                  <span className="font-semibold text-slate-500">Material & Print</span>
                  <span className="col-span-2 text-slate-800">High-Definition Japanese Sublimation & Pigment Inks</span>
                </div>
                <div className="grid grid-cols-3 p-3">
                  <span className="font-semibold text-slate-500">Estimated Delivery</span>
                  <span className="col-span-2 text-slate-800">{product.deliveryDays} Business Days</span>
                </div>
                <div className="grid grid-cols-3 p-3">
                  <span className="font-semibold text-slate-500">Country of Origin</span>
                  <span className="col-span-2 text-slate-800">India (Handcrafted at Lucknow Hub)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
