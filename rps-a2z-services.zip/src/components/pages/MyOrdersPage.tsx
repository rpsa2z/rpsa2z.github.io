import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { InvoiceModal } from '../common/InvoiceModal';
import { Order } from '../../types';
import {
  Package,
  Clock,
  CheckCircle2,
  FileText,
  RotateCcw,
  ArrowRight,
  ExternalLink,
  MessageCircle,
} from 'lucide-react';

export const MyOrdersPage: React.FC = () => {
  const { orders, setActiveTrackingOrderId, setCurrentPage, settings, addToCart, addToast } = useStore();
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredOrders = orders.filter((o) => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'active') return o.orderStatus !== 'Delivered' && o.orderStatus !== 'Cancelled';
    if (filterStatus === 'delivered') return o.orderStatus === 'Delivered';
    if (filterStatus === 'cancelled') return o.orderStatus === 'Cancelled';
    return true;
  });

  const handleTrack = (orderId: string) => {
    setActiveTrackingOrderId(orderId);
    setCurrentPage('order-tracking');
  };

  const handleReorder = (order: Order) => {
    order.items.forEach((item) => {
      addToCart(item.product, item.quantity, item.customization);
    });
    addToast('Items Added to Cart', 'Previous order items reloaded into cart');
    setCurrentPage('cart');
  };

  return (
    <div id="my-orders-container" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">My Orders</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            View order history, reprint tax invoices, and track live workshop progress
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex gap-1.5 bg-slate-100 p-1.5 rounded-2xl text-xs self-start sm:self-auto font-semibold">
          {[
            { id: 'all', label: 'All Orders' },
            { id: 'active', label: 'Active In-Progress' },
            { id: 'delivered', label: 'Delivered' },
            { id: 'cancelled', label: 'Cancelled' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilterStatus(f.id)}
              className={`px-3 py-1.5 rounded-xl transition ${
                filterStatus === f.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {filteredOrders.length > 0 ? (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:border-slate-300 transition text-xs space-y-4"
            >
              {/* Order Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                    <Package className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-mono font-black text-slate-900 text-sm">#{order.id}</span>
                    <p className="text-slate-400 text-[11px]">
                      Ordered on {new Date(order.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`px-3 py-1 rounded-full font-bold text-[11px] ${
                      order.orderStatus === 'Delivered'
                        ? 'bg-emerald-100 text-emerald-800'
                        : order.orderStatus === 'Cancelled'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {order.orderStatus}
                  </span>
                  <span className="font-black text-slate-900 text-base">₹{order.grandTotal}</span>
                </div>
              </div>

              {/* Items preview list */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-2.5 bg-slate-50 rounded-2xl border border-slate-100">
                    <img
                      src={item.customization?.uploadedImages?.[0] || item.product.images[0]}
                      alt={item.product.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0 flex-1">
                      <h4 className="font-bold text-slate-800 truncate">{item.product.name}</h4>
                      <p className="text-[11px] text-slate-500">Qty: {item.quantity} × ₹{item.unitPrice}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                <div className="text-slate-500">
                  <span>Payment: <strong>{order.paymentMethod}</strong> ({order.paymentStatus})</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleTrack(order.id)}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 shadow-xs"
                  >
                    <span>Track Live</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setSelectedInvoiceOrder(order)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition flex items-center gap-1.5"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Invoice</span>
                  </button>

                  <button
                    onClick={() => handleReorder(order)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reorder</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-50 rounded-3xl border border-slate-200">
          <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-slate-800">No Orders in this filter</h3>
          <p className="text-xs text-slate-400 mt-1">Try switching to 'All Orders' or browse our store.</p>
        </div>
      )}

      {/* Invoice Modal */}
      {selectedInvoiceOrder && (
        <InvoiceModal
          order={selectedInvoiceOrder}
          settings={settings}
          onClose={() => setSelectedInvoiceOrder(null)}
        />
      )}
    </div>
  );
};
