import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { InvoiceModal } from '../common/InvoiceModal';
import {
  Search,
  Package,
  CheckCircle2,
  Clock,
  Printer,
  FileText,
  User,
  Phone,
  Bike,
  AlertCircle,
  MessageCircle,
  XCircle,
  MapPin,
} from 'lucide-react';

export const OrderTrackingPage: React.FC = () => {
  const {
    orders,
    activeTrackingOrderId,
    setActiveTrackingOrderId,
    updateOrderStatus,
    settings,
    setCurrentPage,
    addToast,
  } = useStore();

  const [inputOrderId, setInputOrderId] = useState(activeTrackingOrderId || 'ORDRPS000001');
  const [showInvoice, setShowInvoice] = useState(false);

  // Active tracked order
  const currentOrder =
    orders.find((o) => o.id.toLowerCase() === inputOrderId.trim().toLowerCase()) ||
    orders.find((o) => o.id === activeTrackingOrderId) ||
    orders[0];

  const handleSearchOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const found = orders.find((o) => o.id.toLowerCase() === inputOrderId.trim().toLowerCase());
    if (found) {
      setActiveTrackingOrderId(found.id);
      addToast('Order Located', `Displaying live status for #${found.id}`);
    } else {
      addToast('Order Not Found', `No matching order found for ${inputOrderId}. Try ORDRPS000001.`);
    }
  };

  const handleCancelOrder = () => {
    if (currentOrder.orderStatus === 'Placed' || currentOrder.orderStatus === 'Confirmed') {
      updateOrderStatus(currentOrder.id, 'Cancelled');
      addToast('Order Cancelled', `Order #${currentOrder.id} has been cancelled.`);
    } else {
      addToast('Cannot Cancel', 'Printing is already underway. Please contact WhatsApp support.');
    }
  };

  // Full 8-stage progress tracking steps
  const trackingStages = [
    { title: 'Order Placed', desc: 'Order received & logged' },
    { title: 'Order Confirmed', desc: 'Payment/COD verified' },
    { title: 'Design & Proof Checking', desc: 'Art & typography inspection' },
    { title: 'Printing in Progress', desc: 'High-res printing & curing' },
    { title: 'Quality Check Passed', desc: 'Color & trim verified' },
    { title: 'Packed & Dispatched', desc: 'Packed in secure wrap' },
    { title: 'Out for Delivery', desc: 'Rider on route to location' },
    { title: 'Delivered', desc: 'Handed over to customer' },
  ];

  const getStageIndex = (status: string) => {
    switch (status) {
      case 'Placed':
        return 0;
      case 'Confirmed':
        return 1;
      case 'Design Proofing':
        return 2;
      case 'Printing':
        return 3;
      case 'Quality Check':
        return 4;
      case 'Packing':
        return 5;
      case 'Out for Delivery':
        return 6;
      case 'Delivered':
        return 7;
      default:
        return 0;
    }
  };

  const activeIndex = currentOrder ? getStageIndex(currentOrder.orderStatus) : 0;

  return (
    <div id="order-tracking-portal" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      {/* Search Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 mb-8 shadow-xl">
        <div className="max-w-2xl mx-auto text-center space-y-3">
          <span className="text-xs font-bold text-red-500 uppercase tracking-widest">
            Live Order Tracking System
          </span>
          <h1 className="text-2xl sm:text-3xl font-black">
            Track Your Print & Product Delivery
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Enter your 12-character RPS Order ID below to check real-time workshop progress and rider location.
          </p>

          <form onSubmit={handleSearchOrder} className="flex gap-2 max-w-md mx-auto pt-2">
            <input
              type="text"
              value={inputOrderId}
              onChange={(e) => setInputOrderId(e.target.value.toUpperCase())}
              placeholder="e.g. ORDRPS000001"
              className="flex-1 px-4 py-3 bg-white/10 text-white placeholder-slate-400 border border-white/20 rounded-2xl text-xs font-bold uppercase focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-bold transition flex items-center gap-1.5 shadow-md"
            >
              <Search className="w-4 h-4" />
              <span>Track</span>
            </button>
          </form>
        </div>
      </div>

      {currentOrder ? (
        <div className="space-y-6">
          {/* Order Header Summary */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono font-black text-slate-900 text-base">#{currentOrder.id}</span>
                <span
                  className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                    currentOrder.orderStatus === 'Delivered'
                      ? 'bg-emerald-100 text-emerald-800'
                      : currentOrder.orderStatus === 'Cancelled'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {currentOrder.orderStatus}
                </span>
                <span className="text-slate-400">|</span>
                <span className="text-slate-500">
                  Placed on {new Date(currentOrder.createdAt).toLocaleDateString('en-GB')}
                </span>
              </div>
              <p className="text-slate-600">
                Destination: <strong>{currentOrder.customerAddress.city}</strong> (PIN {currentOrder.customerAddress.pinCode})
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setShowInvoice(true)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold flex items-center gap-1.5 transition shadow-xs"
              >
                <FileText className="w-3.5 h-3.5 text-red-400" />
                <span>View Tax Invoice</span>
              </button>

              <a
                href={`https://wa.me/91${settings.whatsappNumber || '8090524232'}?text=${encodeURIComponent(
                  `Hello RPS A2Z SERVICES, I am tracking Order #${currentOrder.id}. Please provide latest status update.`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 transition shadow-xs"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-white" />
                <span>WhatsApp Query</span>
              </a>

              {currentOrder.orderStatus === 'Placed' && (
                <button
                  onClick={handleCancelOrder}
                  className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl font-bold transition"
                >
                  Cancel Order
                </button>
              )}
            </div>
          </div>

          {/* 8-STAGE VERTICAL & HORIZONTAL TIMELINE */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-6">
              Production & Delivery Timeline
            </h2>

            {/* Responsive Stepper */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              {trackingStages.map((stage, idx) => {
                const isComplete = idx < activeIndex;
                const isCurrent = idx === activeIndex;

                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                      isCurrent
                        ? 'border-red-500 bg-red-50/50 shadow-sm ring-2 ring-red-500/20'
                        : isComplete
                        ? 'border-emerald-300 bg-emerald-50/40 text-slate-800'
                        : 'border-slate-100 bg-slate-50/50 opacity-60'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-slate-400">Step {idx + 1}</span>
                        {isComplete ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        ) : isCurrent ? (
                          <Clock className="w-4 h-4 text-red-600 animate-pulse" />
                        ) : null}
                      </div>
                      <h4 className="font-bold text-xs leading-snug text-slate-900">{stage.title}</h4>
                      <p className="text-[10px] text-slate-500 mt-1">{stage.desc}</p>
                    </div>

                    {isCurrent && (
                      <span className="mt-2 text-[9px] bg-red-600 text-white font-bold px-1.5 py-0.5 rounded text-center">
                        Active Stage
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Delivery Boy & Customer Address Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Delivery Rider Card */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-3">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="font-bold text-slate-900 uppercase tracking-wider text-xs">
                  Assigned Delivery Rider
                </span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-md">
                  Active Dispatch
                </span>
              </div>

              {currentOrder.assignedDeliveryBoy ? (
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center">
                    <Bike className="w-6 h-6 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-900 text-sm">{currentOrder.assignedDeliveryBoy.name}</h4>
                    <p className="text-slate-500">RPS Express Courier Associate</p>
                    <p className="text-slate-700 font-bold mt-1">Vehicle: Hero Splendor (UP 32 AZ 4232)</p>
                  </div>
                  <a
                    href={`tel:${currentOrder.assignedDeliveryBoy.mobile}`}
                    className="p-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-2xl transition"
                    title="Call Rider"
                  >
                    <Phone className="w-5 h-5" />
                  </a>
                </div>
              ) : (
                <div className="text-slate-500">
                  <p>Order is currently in printing & quality verification stage.</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Rider contact and vehicle details will appear as soon as packing is completed.
                  </p>
                </div>
              )}
            </div>

            {/* Destination Address Card */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-2">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="font-bold text-slate-900 uppercase tracking-wider text-xs">
                  Delivery Destination
                </span>
                <MapPin className="w-4 h-4 text-red-600" />
              </div>

              <p className="font-bold text-slate-900 text-sm">{currentOrder.customerAddress.fullName}</p>
              <p className="text-slate-600">
                {currentOrder.customerAddress.house}, {currentOrder.customerAddress.street}, {currentOrder.customerAddress.area}
              </p>
              <p className="text-slate-600">
                {currentOrder.customerAddress.city}, {currentOrder.customerAddress.state} -{' '}
                <strong>{currentOrder.customerAddress.pinCode}</strong>
              </p>
              <p className="text-slate-700 font-medium">Contact: {currentOrder.customerAddress.mobile}</p>
            </div>
          </div>

          {/* Ordered Items Table */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Items in This Shipment ({currentOrder.items.length})
            </h3>

            <div className="divide-y divide-slate-100">
              {currentOrder.items.map((item, idx) => (
                <div key={idx} className="py-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.customization?.uploadedImages?.[0] || item.product.images[0]}
                      alt={item.product.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <p className="font-bold text-slate-900">{item.product.name}</p>
                      <p className="text-[11px] text-slate-500">
                        Qty: {item.quantity} | Rate: ₹{item.unitPrice}
                      </p>
                      {item.customization?.notes && (
                        <p className="text-[10px] text-red-600 font-medium">{item.customization.notes}</p>
                      )}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-sm">₹{item.totalPrice}</span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-sm font-black text-slate-900">
              <span>Grand Total Paid / Payable</span>
              <span className="text-red-600 text-base">₹{currentOrder.grandTotal}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 bg-slate-50 rounded-3xl border border-slate-200">
          <p className="text-slate-500 font-medium">No order found with that ID.</p>
        </div>
      )}

      {/* Invoice Modal */}
      {showInvoice && currentOrder && (
        <InvoiceModal
          order={currentOrder}
          settings={settings}
          onClose={() => setShowInvoice(false)}
        />
      )}
    </div>
  );
};
