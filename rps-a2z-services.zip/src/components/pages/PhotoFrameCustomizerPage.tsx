import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { PhotoFrameConfig, ProductCustomization } from '../../types';
import {
  Upload,
  Frame,
  Layers,
  Sparkles,
  ShieldCheck,
  ShoppingCart,
  Zap,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Palette,
  Check,
} from 'lucide-react';

export const PhotoFrameCustomizerPage: React.FC = () => {
  const { products, addToCart, setCurrentPage, addToast } = useStore();

  // Find a base photo frame product or create fallback
  const frameProduct =
    products.find((p) => p.customizationType === 'photo_frame') || products[0];

  // Customizer State
  const [photoUrl, setPhotoUrl] = useState<string>(
    'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&q=80'
  );
  const [frameSize, setFrameSize] = useState<string>('8x12 Inch (A4)');
  const [frameColor, setFrameColor] = useState<string>('Teak Wood Brown');
  const [frameDesign, setFrameDesign] = useState<string>('Classic Beveled');
  const [glassType, setGlassType] = useState<string>('Acrylic Unbreakable Glass');
  const [matteBorder, setMatteBorder] = useState<string>('Pure White Matte Border (1 Inch)');
  const [wallColor, setWallColor] = useState<string>('bg-slate-200');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);

  // Size options with price modifiers
  const sizeOptions = [
    { label: '4x6 Inch', price: 249 },
    { label: '5x7 Inch', price: 349 },
    { label: '6x8 Inch', price: 449 },
    { label: '8x10 Inch', price: 599 },
    { label: '8x12 Inch (A4)', price: 749 },
    { label: '10x12 Inch', price: 899 },
    { label: '12x18 Inch (A3)', price: 1299 },
    { label: '16x20 Inch', price: 1799 },
    { label: '18x24 Inch (Large)', price: 2399 },
  ];

  const currentSizeObj = sizeOptions.find((s) => s.label === frameSize) || sizeOptions[4];

  // Calculate live total price
  const glassModifier = glassType.includes('Acrylic') ? 100 : glassType.includes('Anti-Glare') ? 200 : 0;
  const designModifier = frameDesign.includes('Deep Box') ? 150 : frameDesign.includes('Carved') ? 250 : 0;
  const totalPrice = currentSizeObj.price + glassModifier + designModifier;

  // Frame visual styles according to color & design
  const getFrameBorderClasses = () => {
    switch (frameColor) {
      case 'Matte Black':
        return 'border-slate-900 shadow-2xl';
      case 'Teak Wood Brown':
        return 'border-amber-800 shadow-2xl';
      case 'Warm Walnut':
        return 'border-[#3d2314] shadow-2xl';
      case 'Classic Royal Gold':
        return 'border-amber-500 shadow-2xl';
      case 'Pure Pearl White':
        return 'border-slate-100 shadow-xl';
      default:
        return 'border-slate-800 shadow-2xl';
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoUrl(reader.result as string);
        addToast('Photo Uploaded', 'High resolution image mounted into 3D frame preview');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddToCart = () => {
    const config: PhotoFrameConfig = {
      size: frameSize,
      frameColor,
      frameDesign,
      glassType,
      matteBorder,
      photoUrl,
    };

    const customization: ProductCustomization = {
      type: 'photo_frame',
      uploadedImages: [photoUrl],
      photoFrameConfig: config,
      notes: `Custom 3D Frame: ${frameSize}, ${frameColor}, ${frameDesign}`,
    };

    const customizedProduct = {
      ...frameProduct,
      price: totalPrice,
      name: `Custom ${frameSize} ${frameColor} Photo Frame`,
    };

    addToCart(customizedProduct, 1, customization);
    addToast('Added to Cart', 'Your bespoke framed artwork is in the cart');
  };

  const handleBuyNow = () => {
    handleAddToCart();
    setCurrentPage('checkout');
  };

  return (
    <div id="photo-frame-customizer" className="max-w-7xl mx-auto px-4 py-6 pb-20 text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-red-600 uppercase tracking-wider bg-red-50 px-2.5 py-0.5 rounded-md">
              3D Interactive Studio
            </span>
            <span className="text-xs text-slate-400">RPS A2Z Framing Lab</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
            Custom Photo Frame Designer
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure sizes, wood molding, archival matting and test on different wall backgrounds.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto bg-slate-100 p-2 rounded-2xl">
          <span className="text-xs font-bold text-slate-600">Wall Preview:</span>
          <div className="flex gap-1.5">
            {[
              { id: 'bg-slate-200', name: 'Cool Grey' },
              { id: 'bg-amber-100', name: 'Warm Cream' },
              { id: 'bg-sky-100', name: 'Pastel Blue' },
              { id: 'bg-emerald-100', name: 'Sage Green' },
              { id: 'bg-slate-900', name: 'Charcoal Dark' },
            ].map((col) => (
              <button
                key={col.id}
                onClick={() => setWallColor(col.id)}
                className={`w-6 h-6 rounded-full border-2 transition ${col.id} ${
                  wallColor === col.id ? 'border-red-600 scale-110' : 'border-white shadow-xs'
                }`}
                title={col.name}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Interactive 3D Canvas / Wall (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div
            id="frame-interactive-wall"
            className={`rounded-3xl p-6 sm:p-12 min-h-[460px] sm:min-h-[520px] flex items-center justify-center relative overflow-hidden transition-colors duration-500 border border-slate-300 shadow-inner ${wallColor}`}
          >
            {/* Hanging String/Nail visual for authenticity */}
            <div className="absolute top-4 w-3 h-3 rounded-full bg-slate-500 shadow-sm border border-slate-600" />
            <div className="absolute top-5 w-px h-6 bg-slate-400" />

            {/* The Actual Framed Artwork Box */}
            <div
              id="rendered-frame-box"
              className={`relative transition-all duration-300 border-[16px] sm:border-[22px] ${getFrameBorderClasses()}`}
              style={{
                maxWidth: '90%',
                maxHeight: '440px',
                transform: `scale(${zoomLevel}) rotate(${rotation}deg)`,
                boxShadow:
                  wallColor === 'bg-slate-900'
                    ? '0 25px 50px -12px rgba(0, 0, 0, 0.7)'
                    : '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              }}
            >
              {/* Inner Archival Matte Border (optional padding) */}
              <div
                className={`transition-all duration-200 ${
                  matteBorder.includes('White')
                    ? 'p-4 sm:p-7 bg-[#fdfdfd]'
                    : matteBorder.includes('Cream')
                    ? 'p-4 sm:p-7 bg-[#faf5ec]'
                    : matteBorder.includes('Black')
                    ? 'p-4 sm:p-7 bg-slate-900'
                    : 'p-0'
                }`}
              >
                {/* Photo with Glass reflection overlay */}
                <div className="relative overflow-hidden aspect-[4/5] max-h-[300px] w-auto flex items-center justify-center bg-slate-100">
                  <img
                    src={photoUrl}
                    alt="Framed preview"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />

                  {/* Glass Sheen reflection */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/15 to-transparent pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Floating Zoom & Rotate controls */}
            <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-md rounded-2xl p-1.5 flex items-center gap-1 shadow-md border border-slate-200 text-slate-700">
              <button
                onClick={() => setZoomLevel((prev) => Math.max(0.7, prev - 0.1))}
                className="p-1.5 hover:bg-slate-100 rounded-lg"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-bold px-1">{Math.round(zoomLevel * 100)}%</span>
              <button
                onClick={() => setZoomLevel((prev) => Math.min(1.4, prev + 0.1))}
                className="p-1.5 hover:bg-slate-100 rounded-lg"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setRotation((prev) => (prev + 90) % 360)}
                className="p-1.5 hover:bg-slate-100 rounded-lg ml-1"
                title="Rotate 90 deg"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Upload Button */}
          <div className="flex items-center gap-3">
            <label
              htmlFor="upload-frame-photo"
              className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition active:scale-95"
            >
              <Upload className="w-4 h-4 text-red-400" />
              <span>Upload Your High-Resolution Photo</span>
              <input
                id="upload-frame-photo"
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Right Configuration Control Panel (5 cols) */}
        <div className="lg:col-span-5 space-y-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs text-xs">
          {/* Price Header */}
          <div className="flex items-baseline justify-between border-b border-slate-100 pb-4">
            <div>
              <span className="text-slate-400 uppercase tracking-wider font-bold text-[10px]">Configured Price</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-slate-900">₹{totalPrice}</span>
                <span className="text-xs text-slate-400 line-through">₹{totalPrice + 350}</span>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                  Free Dispatch
                </span>
              </div>
            </div>
            <span className="text-slate-500 font-medium text-[11px]">Size: {frameSize}</span>
          </div>

          {/* 1. Size Selection */}
          <div>
            <label className="block font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
              1. Choose Frame Size
            </label>
            <div className="grid grid-cols-3 gap-2">
              {sizeOptions.map((sz) => (
                <button
                  key={sz.label}
                  onClick={() => setFrameSize(sz.label)}
                  className={`p-2.5 rounded-xl border text-center transition ${
                    frameSize === sz.label
                      ? 'border-red-600 bg-red-50 text-red-700 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <p className="font-bold text-[11px] leading-tight">{sz.label}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">₹{sz.price}</p>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Molding Color */}
          <div>
            <label className="block font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
              2. Frame Color & Wood Finish
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { name: 'Teak Wood Brown', bg: 'bg-amber-800' },
                { name: 'Warm Walnut', bg: 'bg-[#3d2314]' },
                { name: 'Matte Black', bg: 'bg-slate-900' },
                { name: 'Classic Royal Gold', bg: 'bg-amber-500' },
                { name: 'Pure Pearl White', bg: 'bg-slate-100' },
              ].map((fc) => (
                <button
                  key={fc.name}
                  onClick={() => setFrameColor(fc.name)}
                  className={`p-2.5 rounded-xl border flex items-center gap-2 transition text-left ${
                    frameColor === fc.name
                      ? 'border-red-600 bg-red-50 text-red-700 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full ${fc.bg} shrink-0 border border-slate-300`} />
                  <span className="text-[11px] truncate">{fc.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Frame Design Style */}
          <div>
            <label className="block font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
              3. Molding Profile / Design
            </label>
            <div className="grid grid-cols-2 gap-2">
              {['Classic Beveled', 'Modern Thin Border', 'Deep Shadow Box (+₹150)', 'Carved Antique Floral (+₹250)'].map(
                (des) => (
                  <button
                    key={des}
                    onClick={() => setFrameDesign(des)}
                    className={`p-2 rounded-xl border text-left text-[11px] transition ${
                      frameDesign === des
                        ? 'border-red-600 bg-red-50 text-red-700 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    {des}
                  </button>
                )
              )}
            </div>
          </div>

          {/* 4. Glass Type */}
          <div>
            <label className="block font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
              4. Glass / Glazing Material
            </label>
            <div className="space-y-1.5">
              {[
                { name: 'Acrylic Unbreakable Glass (+₹100)', desc: 'Shatter-proof courier safe (Recommended)' },
                { name: 'Normal Float Glass (Standard)', desc: 'Original crystal reflection' },
                { name: 'Anti-Glare Museum Matte Glass (+₹200)', desc: 'Zero reflection under room lighting' },
              ].map((glass) => (
                <button
                  key={glass.name}
                  onClick={() => setGlassType(glass.name)}
                  className={`w-full p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                    glassType === glass.name
                      ? 'border-red-600 bg-red-50 text-red-700 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div>
                    <p className="text-[11px] font-bold">{glass.name}</p>
                    <p className="text-[10px] text-slate-500">{glass.desc}</p>
                  </div>
                  {glassType === glass.name && <Check className="w-4 h-4 text-red-600 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* 5. Matte Border */}
          <div>
            <label className="block font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
              5. Passpartout Matte Board
            </label>
            <select
              value={matteBorder}
              onChange={(e) => setMatteBorder(e.target.value)}
              className="w-full p-2.5 border border-slate-200 rounded-xl font-medium"
            >
              <option value="Pure White Matte Border (1 Inch)">Pure White Matte Border (1 Inch)</option>
              <option value="Warm Cream Archival Matte">Warm Cream Archival Matte</option>
              <option value="Dramatic Black Matte Border">Dramatic Black Matte Border</option>
              <option value="Full Bleed (No Matte Border)">Full Bleed (No Border / Edge-to-Edge)</option>
            </select>
          </div>

          {/* Action CTAs */}
          <div className="pt-3 border-t border-slate-100 flex gap-3">
            <button
              onClick={handleAddToCart}
              className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-xs"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Add to Cart</span>
            </button>

            <button
              onClick={handleBuyNow}
              className="flex-1 py-3 px-4 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md"
            >
              <Zap className="w-4 h-4" />
              <span>Buy Custom Frame</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
