import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Upload,
  Send,
  MessageCircle,
  FileCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';

export const CustomOrderPage: React.FC = () => {
  const { addToast, settings, setCurrentPage } = useStore();

  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [serviceName, setServiceName] = useState('Banners & Hoardings');
  const [quantity, setQuantity] = useState('500');
  const [dimensions, setDimensions] = useState('10x4 Feet');
  const [paperType, setPaperType] = useState('350 GSM Heavy Board / Star Flex');
  const [printingType, setPrintingType] = useState('Full Color HD Pigment Printing');
  const [instructions, setInstructions] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [address, setAddress] = useState('');
  const [fileName, setFileName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      addToast('File Attached', `${file.name} ready for quote analysis`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !mobile || !serviceName) {
      addToast('Missing Details', 'Please provide name, mobile and product details');
      return;
    }
    setIsSubmitted(true);
    addToast('Custom Request Submitted', 'Our printing executive will contact you shortly with proof and quote.');
  };

  const handleWhatsAppSend = () => {
    const text = `Hello RPS A2Z SERVICES, I want to submit a Custom Bulk Order:
- Name: ${fullName || 'Customer'}
- Mobile: ${mobile}
- Service: ${serviceName}
- Quantity: ${quantity}
- Dimensions: ${dimensions}
- Paper/Material: ${paperType}
- Instructions: ${instructions || 'None'}
- Required by: ${deliveryDate || 'Standard'}`;

    const url = `https://wa.me/91${settings.whatsappNumber || '8090524232'}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div id="custom-bulk-order-page" className="max-w-4xl mx-auto px-4 py-8 pb-24 text-slate-800">
      {/* Header */}
      <div className="text-center max-w-xl mx-auto mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-red-600 bg-red-50 px-3 py-1 rounded-full">
          Industrial & Bulk Printing
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
          Custom Specification Order Form
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          For large volume flex banners, brochures, election materials, marriage cards or customized packaging.
        </p>
      </div>

      {isSubmitted ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-8 text-center space-y-4">
          <div className="w-16 h-16 bg-emerald-600 text-white rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-emerald-900">Custom Inquiry Received!</h2>
          <p className="text-xs sm:text-sm text-emerald-700 max-w-md mx-auto">
            Thank you, <strong>{fullName}</strong>. Your custom specifications have been registered under Reference{' '}
            <strong>#RPS-RFQ-{Math.floor(100000 + Math.random() * 900000)}</strong>.
          </p>
          <div className="flex flex-wrap justify-center gap-3 pt-4">
            <button
              onClick={handleWhatsAppSend}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Send Specifications on WhatsApp Now</span>
            </button>
            <button
              onClick={() => {
                setIsSubmitted(false);
                setCurrentPage('home');
              }}
              className="px-6 py-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition"
            >
              Return to Homepage
            </button>
          </div>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 text-xs"
        >
          {/* Section 1: Customer Contact */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 pb-2 border-b border-slate-100 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]">
                1
              </span>
              <span>Contact Information</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Alok Sharma"
                  className="w-full p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Number (WhatsApp) *</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 8090524232"
                  className="w-full p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. info@business.com"
                  className="w-full p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Order Specifications */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 pb-2 border-b border-slate-100 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]">
                2
              </span>
              <span>Product & Job Specifications</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Product / Service Required *</label>
                <select
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-medium"
                >
                  <option value="Banners & Hoardings">Large Flex Banners & Hoardings</option>
                  <option value="Multi-Page Catalogs & Brochures">Multi-Page Catalogs & Brochures</option>
                  <option value="Corporate Visiting Cards & Letterheads">Visiting Cards / Letterhead Stationery</option>
                  <option value="Custom Uniforms / T-Shirts">T-Shirt & Corporate Uniform Printing</option>
                  <option value="Customized Photo Gifts Bulk">Customized Mugs & Gift Kits Bulk</option>
                  <option value="Hardcover Book / Thesis Binding">Thesis Binding & Golden Foil Embossing</option>
                  <option value="Wedding & Invitation Cards">Luxury Wedding & Invitation Cards</option>
                  <option value="Stickers & Product Labels">Die-Cut Waterproof Stickers & Labels</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Quantity *</label>
                <input
                  type="text"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="e.g. 500 pcs, 20 units, 1000 sq ft"
                  className="w-full p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Size / Dimension Requirements</label>
                <input
                  type="text"
                  value={dimensions}
                  onChange={(e) => setDimensions(e.target.value)}
                  placeholder="e.g. 10x4 Feet, A4 Booklet, 3.5x2 Inch"
                  className="w-full p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Paper / Stock / Media Preference</label>
                <input
                  type="text"
                  value={paperType}
                  onChange={(e) => setPaperType(e.target.value)}
                  placeholder="e.g. 300 GSM Matte, Star Flex, Backlit Film"
                  className="w-full p-2.5 border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          </div>

          {/* Section 3: File Upload & Notes */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 pb-2 border-b border-slate-100 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]">
                3
              </span>
              <span>Design File & Special Instructions</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Upload Design File (JPG, PNG, PDF, CDR, PSD, AI, ZIP)
                </label>
                <div className="border-2 border-dashed border-slate-300 rounded-2xl p-4 text-center cursor-pointer hover:border-red-500 bg-slate-50 transition">
                  <input
                    type="file"
                    id="bulk-file-input"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <label htmlFor="bulk-file-input" className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-6 h-6 text-red-600 mb-1" />
                    <span className="font-bold text-slate-800">
                      {fileName ? `Attached: ${fileName}` : 'Click or Drag & Drop Design File'}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">
                      Large files (up to 100MB) can also be sent via WhatsApp
                    </span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Special Finishing / Delivery Instructions</label>
                <textarea
                  rows={3}
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="e.g. Require eyelets every 2 feet, matte lamination on outer cover, individual shrink wrapping..."
                  className="w-full p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Delivery Deadline</label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Delivery Destination / City</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="e.g. Lucknow (Hazratganj) PIN: 226001"
                    className="w-full p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row gap-3">
            <button
              type="submit"
              className="flex-1 py-3.5 px-6 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-md active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span>Submit Custom Quote Request</span>
            </button>

            <button
              type="button"
              onClick={handleWhatsAppSend}
              className="py-3.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-sm active:scale-95"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Send Instantly via WhatsApp</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
