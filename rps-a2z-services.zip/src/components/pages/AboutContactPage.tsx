import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  MessageCircle,
  Printer,
  ShieldCheck,
  Award,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

export const AboutContactPage: React.FC = () => {
  const { settings, addToast } = useStore();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('Printing Quotation');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !message) {
      addToast('Please fill all fields', 'Name, mobile and message are required.');
      return;
    }
    addToast('Message Sent', 'Our printing executive will contact you promptly.');
    setName('');
    setPhone('');
    setMessage('');
  };

  return (
    <div id="about-contact-page" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800 text-xs">
      {/* Hero Intro */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <span className="text-[11px] font-bold uppercase tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full">
          About RPS A2Z SERVICES
        </span>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900 mt-3">
          Complete Printing, Custom Gifts & Digital Hub
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
          Established to deliver ultra-sharp professional print finishes, personalized photo frames, branded corporate merchandise, and seamless digital cyber services directly to homes and enterprises across India.
        </p>
      </div>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
            <Printer className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Industrial Grade Machinery</h3>
          <p className="text-slate-500 leading-relaxed">
            High-definition 12-color pigment photo printers, Konica Minolta production presses, and Swiss CNC computerized frame cutters.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Museum-Quality Framing</h3>
          <p className="text-slate-500 leading-relaxed">
            Synthetic pine wood, acrylic glass with 99% UV resistance, archival mat boards, and airtight dust-free backing.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Reliable Same-Day Turnaround</h3>
          <p className="text-slate-500 leading-relaxed">
            Dedicated dispatch riders for local quick fulfillment and nationwide premium air-courier partnerships.
          </p>
        </div>
      </div>

      {/* Contact Details & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Contact Info (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-6">
          <h2 className="text-base font-bold text-slate-900 pb-3 border-b border-slate-100">
            Get in Touch With Our Workshop
          </h2>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-red-50 text-red-600 rounded-xl shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">Printing Center Address</h4>
                <p className="text-slate-500 mt-0.5">{settings.businessAddress}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">Phone Support</h4>
                <p className="text-slate-600 font-bold mt-0.5">+91 {settings.mobileNumber}</p>
                <p className="text-[11px] text-slate-400">Lines open Monday to Sunday, 9 AM - 9 PM</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">Email Address</h4>
                <p className="text-slate-600 font-bold mt-0.5">{settings.email}</p>
                <p className="text-[11px] text-slate-400">Response guaranteed within 2 business hours</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-purple-50 text-purple-600 rounded-xl shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">Operating Hours</h4>
                <p className="text-slate-600 mt-0.5">Monday – Sunday: 9:00 AM – 9:00 PM</p>
                <p className="text-[11px] text-slate-400">Online custom order desk active 24/7</p>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <a
              href={`https://wa.me/91${settings.whatsappNumber}?text=${encodeURIComponent(
                'Hello RPS A2Z SERVICES, I would like to inquire about printing services.'
              )}`}
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition shadow-sm"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Instant Chat on WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Contact Form (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-base font-bold text-slate-900 pb-3 border-b border-slate-100">
            Send an Inquiry or Custom Request
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Your Full Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Amit Kumar"
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Number *</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="10-digit mobile"
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Inquiry Topic</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full p-2.5 border border-slate-200 rounded-xl"
              >
                <option value="Printing Quotation">Printing Quotation (Bulk / Commercial)</option>
                <option value="Photo Framing Inquiry">Custom Photo Frame Inquiries</option>
                <option value="Digital Services">Digital Forms & PVC Card Assistance</option>
                <option value="Delivery Status">Existing Order Inquiry</option>
                <option value="Corporate Merchandising">Corporate Gifts & T-shirts</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Message / Requirements *</label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe your dimensions, quantities, paper finish, or any questions..."
                className="w-full p-2.5 border border-slate-200 rounded-xl"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition shadow-md active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span>Send Message</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
