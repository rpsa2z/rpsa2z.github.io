import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from '../products/ProductCard';
import {
  User,
  Heart,
  Package,
  MapPin,
  ShieldCheck,
  Edit2,
  Check,
  ArrowRight,
  LogOut,
} from 'lucide-react';

export const CustomerDashboardPage: React.FC = () => {
  const { user, updateUserProfile, orders, wishlist, products, setCurrentPage, logoutUser, addToast } = useStore();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [mobile, setMobile] = useState(user.mobile);

  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ name, email, mobile });
    setIsEditing(false);
    addToast('Profile Updated', 'Your contact information was updated successfully.');
  };

  return (
    <div id="customer-dashboard-container" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      <div className="pb-4 mb-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">My Account Dashboard</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage your personal profile, addresses, wishlist and orders
          </p>
        </div>

        <button
          onClick={logoutUser}
          className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition self-start sm:self-auto"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div
          onClick={() => setCurrentPage('my-orders')}
          className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs cursor-pointer hover:border-red-300 transition"
        >
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <span className="text-2xl font-black text-slate-900">{orders.length}</span>
          </div>
          <h3 className="font-bold text-xs text-slate-800 mt-3">Total Orders Placed</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Click to view order tracking</p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <Heart className="w-5 h-5" />
            </div>
            <span className="text-2xl font-black text-slate-900">{wishlist.length}</span>
          </div>
          <h3 className="font-bold text-xs text-slate-800 mt-3">Saved in Wishlist</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Items saved for later review</p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md">
              Verified
            </span>
          </div>
          <h3 className="font-bold text-xs text-slate-800 mt-3">Account Status</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">RPS A2Z Customer Club</p>
        </div>
      </div>

      {/* Profile & Saved Addresses Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-12">
        {/* Profile Card (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs text-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="font-bold text-slate-900 uppercase tracking-wider">Profile Information</span>
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="text-red-600 hover:text-red-700 font-bold flex items-center gap-1"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                Cancel
              </button>
            )}
          </div>

          {isEditing ? (
            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Number</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Check className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </button>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-700 font-black text-lg flex items-center justify-center">
                  {user.name[0]}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{user.name}</h3>
                  <p className="text-slate-400 text-[11px]">Customer ID: {user.id}</p>
                </div>
              </div>

              <div className="pt-2 space-y-2 text-slate-600">
                <p>
                  <strong>Email:</strong> {user.email}
                </p>
                <p>
                  <strong>Phone:</strong> +91 {user.mobile}
                </p>
                <p>
                  <strong>Member Since:</strong> March 2026
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Saved Addresses (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs text-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="font-bold text-slate-900 uppercase tracking-wider">Default Delivery Address</span>
            <MapPin className="w-4 h-4 text-red-600" />
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1 text-slate-700">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-sm">{user.name}</span>
              <span className="px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-bold rounded-md">
                Primary
              </span>
            </div>
            <p>House 42-B, RPS Digital Complex Road, Near Hazratganj Metro</p>
            <p>Lucknow, Uttar Pradesh - <strong>226001</strong></p>
            <p className="text-slate-500 mt-1">Phone: +91 {user.mobile}</p>
          </div>
        </div>
      </div>

      {/* Wishlist Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div>
            <h2 className="text-lg font-bold text-slate-900">My Saved Wishlist Items</h2>
            <p className="text-xs text-slate-500">Products and custom frames you've marked as favorite</p>
          </div>
          <span className="text-xs font-bold text-slate-500">{wishlist.length} items</span>
        </div>

        {wishlistProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {wishlistProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-10 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500">
            <Heart className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="font-bold text-slate-700">No items saved in wishlist yet</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Click the heart icon on any product to save it here.</p>
          </div>
        )}
      </div>
    </div>
  );
};
