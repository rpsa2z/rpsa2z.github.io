import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from '../products/ProductCard';
import { Filter, SlidersHorizontal, ArrowUpDown, X, Star, Check } from 'lucide-react';

export const ProductListingPage: React.FC = () => {
  const {
    products,
    categories,
    selectedCategoryId,
    setSelectedCategoryId,
    searchQuery,
    setSearchQuery,
    setCurrentPage,
  } = useStore();

  const [selectedCategory, setSelectedCategory] = useState<string>(selectedCategoryId || 'all');
  const [priceMax, setPriceMax] = useState<number>(3000);
  const [minRating, setMinRating] = useState<number>(0);
  const [minDiscount, setMinDiscount] = useState<number>(0);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [customizableOnly, setCustomizableOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating' | 'discount'>('featured');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Sync when selectedCategoryId changes from header/nav
  React.useEffect(() => {
    if (selectedCategoryId) {
      setSelectedCategory(selectedCategoryId);
    }
  }, [selectedCategoryId]);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        // Category filter
        if (selectedCategory !== 'all' && p.category !== selectedCategory) {
          return false;
        }

        // Search query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const match =
            p.name.toLowerCase().includes(q) ||
            p.id.toLowerCase().includes(q) ||
            p.sku.toLowerCase().includes(q) ||
            p.category.toLowerCase().includes(q) ||
            p.description.toLowerCase().includes(q);
          if (!match) return false;
        }

        // Price filter
        if (p.price > priceMax) return false;

        // Rating filter
        if (minRating > 0 && p.rating < minRating) return false;

        // Discount filter
        if (minDiscount > 0 && p.discountPercentage < minDiscount) return false;

        // Stock filter
        if (inStockOnly && p.stock <= 0) return false;

        // Customization filter
        if (customizableOnly && !p.isCustomizable) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'discount') return b.discountPercentage - a.discountPercentage;
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [products, selectedCategory, searchQuery, priceMax, minRating, minDiscount, inStockOnly, customizableOnly, sortBy]);

  const activeCategoryObj = categories.find((c) => c.id === selectedCategory);

  const resetFilters = () => {
    setSelectedCategory('all');
    setSelectedCategoryId(null);
    setSearchQuery('');
    setPriceMax(3000);
    setMinRating(0);
    setMinDiscount(0);
    setInStockOnly(false);
    setCustomizableOnly(false);
    setSortBy('featured');
  };

  return (
    <div id="product-listing-page" className="max-w-7xl mx-auto px-4 py-6 pb-20">
      {/* Header breadcrumb & summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <button onClick={() => setCurrentPage('home')} className="hover:text-red-600">Home</button>
            <span>/</span>
            <span className="font-semibold text-slate-800">
              {activeCategoryObj ? activeCategoryObj.name : searchQuery ? `Search "${searchQuery}"` : 'All Products'}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900">
            {activeCategoryObj ? activeCategoryObj.name : searchQuery ? `Search Results for "${searchQuery}"` : 'Printing & Digital Catalog'}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Showing <strong className="text-slate-800">{filteredProducts.length}</strong> products available for online booking & purchase
          </p>
        </div>

        {/* Sort and mobile filter toggle */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="md:hidden flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold"
          >
            <Filter className="w-4 h-4 text-red-600" />
            <span>Filters</span>
          </button>

          <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 font-medium">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent font-bold text-slate-800 focus:outline-none cursor-pointer text-xs"
            >
              <option value="featured">Featured First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
              <option value="discount">Biggest Discount</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Left Sidebar Filters (Desktop) */}
        <aside className="hidden md:block space-y-6 bg-slate-50 p-5 rounded-2xl border border-slate-200 self-start text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
              <SlidersHorizontal className="w-4 h-4 text-red-600" />
              <span>Filters</span>
            </div>
            <button
              onClick={resetFilters}
              className="text-red-600 hover:text-red-700 font-bold text-xs"
            >
              Reset All
            </button>
          </div>

          {/* Category Filter */}
          <div>
            <h4 className="font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">Categories</h4>
            <div className="space-y-1 max-h-52 overflow-y-auto pr-1">
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedCategoryId(null);
                }}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between transition ${
                  selectedCategory === 'all'
                    ? 'bg-red-600 text-white font-bold'
                    : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>All Categories</span>
                <span>{products.length}</span>
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setSelectedCategoryId(cat.id);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between transition ${
                    selectedCategory === cat.id
                      ? 'bg-red-600 text-white font-bold'
                      : 'text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span className="truncate">{cat.name}</span>
                  <span className="text-[10px] opacity-75">{cat.itemCount}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Price Range Filter */}
          <div className="pt-3 border-t border-slate-200">
            <div className="flex justify-between items-center mb-1.5">
              <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">Max Price</h4>
              <span className="font-bold text-red-600">₹{priceMax}</span>
            </div>
            <input
              type="range"
              min="20"
              max="3000"
              step="50"
              value={priceMax}
              onChange={(e) => setPriceMax(Number(e.target.value))}
              className="w-full accent-red-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>₹20</span>
              <span>₹3,000+</span>
            </div>
          </div>

          {/* Minimum Rating */}
          <div className="pt-3 border-t border-slate-200">
            <h4 className="font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">Customer Rating</h4>
            <div className="space-y-1">
              {[4, 3, 0].map((stars) => (
                <button
                  key={stars}
                  onClick={() => setMinRating(stars)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                    minRating === stars ? 'bg-red-50 text-red-700 font-bold border border-red-200' : 'text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <div className="flex items-center text-amber-500">
                    {stars > 0 ? (
                      [...Array(stars)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />)
                    ) : (
                      <span>All Ratings</span>
                    )}
                  </div>
                  {stars > 0 && <span>& Up</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Minimum Discount */}
          <div className="pt-3 border-t border-slate-200">
            <h4 className="font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">Discount</h4>
            <div className="space-y-1">
              {[40, 20, 10, 0].map((disc) => (
                <button
                  key={disc}
                  onClick={() => setMinDiscount(disc)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between transition ${
                    minDiscount === disc ? 'bg-red-50 text-red-700 font-bold border border-red-200' : 'text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span>{disc > 0 ? `${disc}% and above` : 'Any discount'}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="pt-3 border-t border-slate-200 space-y-2.5">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="w-4 h-4 rounded text-red-600 focus:ring-red-500 border-slate-300"
              />
              <span className="text-slate-700 font-medium">In Stock Only</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={customizableOnly}
                onChange={(e) => setCustomizableOnly(e.target.checked)}
                className="w-4 h-4 rounded text-red-600 focus:ring-red-500 border-slate-300"
              />
              <span className="text-slate-700 font-medium">Customizable Only</span>
            </label>
          </div>
        </aside>

        {/* Mobile Filter Drawer */}
        {mobileFilterOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end md:hidden">
            <div className="w-80 bg-white h-full p-5 overflow-y-auto text-xs space-y-5 animate-in slide-in-from-right">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <span className="font-bold text-sm text-slate-900">Filters</span>
                <button
                  onClick={() => setMobileFilterOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Categories */}
              <div>
                <h4 className="font-bold text-slate-800 mb-2">Category</h4>
                <select
                  value={selectedCategory}
                  onChange={(e) => {
                    setSelectedCategory(e.target.value);
                    setSelectedCategoryId(e.target.value === 'all' ? null : e.target.value);
                  }}
                  className="w-full p-2.5 border border-slate-200 rounded-xl"
                >
                  <option value="all">All Categories</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              {/* Price Max */}
              <div>
                <div className="flex justify-between mb-1 font-bold">
                  <span>Max Price</span>
                  <span className="text-red-600">₹{priceMax}</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="3000"
                  step="50"
                  value={priceMax}
                  onChange={(e) => setPriceMax(Number(e.target.value))}
                  className="w-full accent-red-600"
                />
              </div>

              {/* In stock */}
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                  className="w-4 h-4 rounded text-red-600"
                />
                <span className="text-slate-700 font-medium">In Stock Only</span>
              </label>

              <button
                onClick={() => setMobileFilterOpen(false)}
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-sm"
              >
                Show Results
              </button>
            </div>
          </div>
        )}

        {/* Right Products Grid */}
        <div className="md:col-span-3">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-slate-50 rounded-2xl border border-slate-200 p-8">
              <div className="w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Filter className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">No Products Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                We couldn't find any products matching your current filters or search keywords.
              </p>
              <div className="mt-4 flex justify-center gap-3">
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition"
                >
                  Reset All Filters
                </button>
                <button
                  onClick={() => setCurrentPage('custom-order')}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition"
                >
                  Submit Custom Order
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
