import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Trash2,
  ArrowRight,
  ShoppingBag,
  ShieldCheck,
  Truck,
  Tag,
  MessageCircle,
  Plus,
  Minus,
  Sparkles,
} from 'lucide-react';

export const CartPage: React.FC = () => {
  const {
    cart,
    removeFromCart,
    updateCartQuantity,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    getCartTotals,
    setCurrentPage,
    setSelectedProductId,
    settings,
  } = useStore();

  const [couponInput, setCouponInput] = useState('');
  const totals = getCartTotals();

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponInput.trim()) {
      applyCoupon(couponInput.trim());
      setCouponInput('');
    }
  };

  if (cart.length === 0) {
    return (
      <div id="empty-cart-state" className="max-w-2xl mx-auto px-4 py-16 text-center text-slate-800">
        <div className="w-20 h-20 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-black text-slate-900">Your Cart is Empty</h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto mt-2 leading-relaxed">
          Looks like you haven't added any products or printing services yet. Discover our photo frames, mugs, and customized gifts!
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            onClick={() => setCurrentPage('products')}
            className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
          >
            Start Shopping
          </button>
          <button
            onClick={() => setCurrentPage('photo-frame-customizer')}
            className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
          >
            Create Custom Frame
          </button>
        </div>
      </div>
    );
  }

  return (
    <div id="cart-container" className="max-w-7xl mx-auto px-4 py-8 pb-24 text-slate-800">
      <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">Shopping Cart</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            You have <strong className="text-slate-800">{cart.length} unique items</strong> in your shopping bag
          </p>
        </div>

        <button
          onClick={() => setCurrentPage('products')}
          className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1"
        >
          <span>Continue Shopping</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Cart Item List (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="divide-y divide-slate-100 bg-white rounded-3xl border border-slate-200 p-4 sm:p-6 shadow-xs">
            {cart.map((item) => (
              <div key={item.id} className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row gap-4">
                {/* Thumbnail */}
                <div
                  onClick={() => {
                    setSelectedProductId(item.productId);
                    setCurrentPage('product-detail');
                  }}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-slate-100 overflow-hidden border border-slate-200 cursor-pointer shrink-0"
                >
                  <img
                    src={item.customization?.uploadedImages?.[0] || item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                          {item.product.category.replace('-', ' ')}
                        </span>
                        <h3
                          onClick={() => {
                            setSelectedProductId(item.productId);
                            setCurrentPage('product-detail');
                          }}
                          className="font-bold text-sm sm:text-base text-slate-900 hover:text-red-600 cursor-pointer line-clamp-2"
                        >
                          {item.product.name}
                        </h3>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50 transition shrink-0"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Customization Details Badges */}
                    {item.customization && (
                      <div className="mt-2 p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-[11px] text-slate-600 space-y-1">
                        {item.customization.photoFrameConfig && (
                          <p>
                            <strong>Frame:</strong> {item.customization.photoFrameConfig.size},{' '}
                            {item.customization.photoFrameConfig.frameColor} (
                            {item.customization.photoFrameConfig.frameDesign})
                          </p>
                        )}
                        {item.customization.printingConfig && (
                          <p>
                            <strong>Print:</strong> {item.customization.printingConfig.printSize},{' '}
                            {item.customization.printingConfig.paperGsm}
                          </p>
                        )}
                        {item.customization.customText && (
                          <p>
                            <strong>Custom Text:</strong> "{item.customization.customText}"
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Price & Quantity Selector */}
                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-50">
                    <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden">
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                        className="p-2 hover:bg-slate-100 text-slate-600 font-bold"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 py-1 text-xs font-bold text-slate-900">{item.quantity}</span>
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-slate-100 text-slate-600 font-bold"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right">
                      <p className="text-base font-black text-slate-900">₹{item.totalPrice}</p>
                      <p className="text-[10px] text-slate-400">₹{item.unitPrice} each</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Delivery & Security Guarantees */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Free Delivery on orders above ₹499 across India</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
              <span>100% Quality & Safe Packaging Guarantee</span>
            </div>
          </div>
        </div>

        {/* Price Summary & Checkout Box (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider pb-3 border-b border-slate-100">
              Order Summary
            </h3>

            {/* Coupon Code Input */}
            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Apply Coupon Code</label>
              {appliedCoupon ? (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-emerald-800">
                  <div className="flex items-center gap-1.5">
                    <Tag className="w-4 h-4 text-emerald-600" />
                    <span className="font-bold uppercase">{appliedCoupon.code}</span>
                    <span className="text-[11px] text-emerald-600 font-medium">({appliedCoupon.discountPercentage}% OFF)</span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-xs font-bold text-red-600 hover:text-red-700"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder="Try: RPSFIRST, PRINT15"
                    className="flex-1 p-2.5 border border-slate-200 rounded-xl uppercase font-bold text-xs"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold transition"
                  >
                    Apply
                  </button>
                </form>
              )}
            </div>

            {/* Breakdown */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-semibold text-slate-800">₹{totals.subtotal}</span>
              </div>

              {totals.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Coupon Discount</span>
                  <span>- ₹{totals.discount}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Delivery Charges</span>
                <span className="font-semibold text-slate-800">
                  {totals.deliveryCharge === 0 ? <span className="text-emerald-600 font-bold">FREE</span> : `₹${totals.deliveryCharge}`}
                </span>
              </div>

              <div className="flex justify-between text-slate-500 text-[11px]">
                <span>Included GST (18%)</span>
                <span>₹{totals.gstAmount}</span>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
                <span className="text-base font-black text-slate-900">Total Amount</span>
                <span className="text-2xl font-black text-red-600">₹{totals.grandTotal}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-2">
              <button
                id="proceed-to-checkout-btn"
                onClick={() => setCurrentPage('checkout')}
                className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-md active:scale-95"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={`https://wa.me/91${settings.whatsappNumber || '8090524232'}?text=${encodeURIComponent(
                  `Hello RPS A2Z SERVICES, I want to confirm my cart of ${cart.length} items (Total: ₹${totals.grandTotal}).`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition shadow-sm"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Order Direct via WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
