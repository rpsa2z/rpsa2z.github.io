import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Category,
  CartItem,
  Order,
  CustomOrder,
  DeliveryBoy,
  Banner,
  Coupon,
  CustomerReview,
  NotificationItem,
  WebsiteSettings,
  OrderStatus,
  ProductCustomization,
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_CATEGORIES,
  INITIAL_BANNERS,
  INITIAL_PRODUCTS,
  INITIAL_COUPONS,
  INITIAL_DELIVERY_BOYS,
  INITIAL_ORDERS,
  INITIAL_CUSTOM_ORDERS,
  INITIAL_REVIEWS,
  INITIAL_NOTIFICATIONS,
} from '../data/initialData';

export type ActivePage =
  | 'home'
  | 'products'
  | 'product-detail'
  | 'photo-frame-customizer'
  | 'custom-order'
  | 'cart'
  | 'checkout'
  | 'order-success'
  | 'order-tracking'
  | 'my-orders'
  | 'customer-dashboard'
  | 'admin'
  | 'delivery-boy'
  | 'digital-services'
  | 'help-support';

export interface Toast {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'error' | 'warning';
}

export interface UserProfile {
  name: string;
  mobile: string;
  email: string;
  role: 'guest' | 'customer' | 'admin' | 'delivery-boy';
  deliveryBoyId?: string;
  address?: {
    house: string;
    street: string;
    area: string;
    city: string;
    state: string;
    pinCode: string;
  };
}

interface StoreContextType {
  // Page navigation
  currentPage: ActivePage;
  setCurrentPage: (page: ActivePage) => void;
  selectedProductId: string | null;
  setSelectedProductId: (id: string | null) => void;
  selectedCategoryId: string | null;
  setSelectedCategoryId: (id: string | null) => void;
  activeTrackingOrderId: string | null;
  setActiveTrackingOrderId: (id: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  deliveryPincode: string;
  setDeliveryPincode: (pin: string) => void;
  currentLanguage: 'en' | 'hi';
  setCurrentLanguage: (lang: 'en' | 'hi') => void;

  // Data
  products: Product[];
  categories: Category[];
  banners: Banner[];
  orders: Order[];
  customOrders: CustomOrder[];
  deliveryBoys: DeliveryBoy[];
  coupons: Coupon[];
  reviews: CustomerReview[];
  notifications: NotificationItem[];
  settings: WebsiteSettings;
  recentlyViewed: string[];

  // Cart & Wishlist
  cart: CartItem[];
  appliedCoupon: Coupon | null;
  wishlist: string[];
  addToCart: (
    product: Product,
    quantity?: number,
    customization?: ProductCustomization,
    selectedSize?: string,
    selectedColor?: string
  ) => void;
  removeFromCart: (cartItemId: string) => void;
  updateCartQuantity: (cartItemId: string, delta: number) => void;
  clearCart: () => void;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  getCartSubtotal: () => number;
  getCartDiscount: () => number;
  getCartDeliveryCharge: () => number;
  getCartGst: () => number;
  getCartGrandTotal: () => number;

  // User & Authentication
  user: UserProfile;
  loginUser: (profile: Partial<UserProfile>) => void;
  logoutUser: () => void;
  adminLoggedIn: boolean;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  deliveryBoyLoggedIn: boolean;
  currentDeliveryBoy: DeliveryBoy | null;
  loginDeliveryBoy: (userId: string, pin: string) => boolean;
  logoutDeliveryBoy: () => void;

  // Orders
  placeOrder: (orderData: Omit<Order, 'id' | 'createdAt' | 'trackingHistory'>) => Order;
  submitCustomOrder: (data: Omit<CustomOrder, 'id' | 'createdAt' | 'status'>) => CustomOrder;
  approveDesignProof: (orderId: string, comment?: string) => void;
  requestDesignChanges: (orderId: string, comment: string) => void;
  cancelCustomerOrder: (orderId: string, reason: string) => void;

  // Admin Management Actions
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  updateOrderStatus: (orderId: string, newStatus: OrderStatus, adminRemark?: string) => void;
  assignDeliveryBoy: (orderId: string, boyId: string) => void;
  uploadDesignProof: (orderId: string, proofUrl: string, adminNote?: string) => void;
  quoteCustomOrder: (customOrderId: string, quotePrice: number, adminRemark: string) => void;
  convertCustomOrderToNormalOrder: (customOrderId: string) => Order;
  updateSettings: (newSettings: WebsiteSettings) => void;
  addDeliveryBoy: (boy: Omit<DeliveryBoy, 'id' | 'assignedOrderCount'>) => void;
  updateDeliveryBoy: (boy: DeliveryBoy) => void;
  deleteDeliveryBoy: (boyId: string) => void;
  addCoupon: (coupon: Coupon) => void;
  toggleCoupon: (code: string) => void;
  addBanner: (banner: Omit<Banner, 'id'>) => void;
  toggleBanner: (id: string) => void;
  moderateReview: (reviewId: string, approved: boolean) => void;
  submitReview: (review: Omit<CustomerReview, 'id' | 'date' | 'approved'>) => void;

  // Delivery Boy Actions
  confirmDeliveryWithOtp: (orderId: string, enteredOtp: string) => { success: boolean; message: string };

  // Toasts
  toasts: Toast[];
  addToast: (title: string, message: string, type?: Toast['type']) => void;
  removeToast: (id: string) => void;

  // Modals / Overlays
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  isLocationModalOpen: boolean;
  setIsLocationModalOpen: (open: boolean) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation & Filter state
  const [currentPage, setCurrentPage] = useState<ActivePage>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [activeTrackingOrderId, setActiveTrackingOrderId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [deliveryPincode, setDeliveryPincode] = useState('226001');
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hi'>('en');

  // Quick view & modals
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  // Local storage helpers
  const loadStored = <T,>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(`rps_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  const saveStored = <T,>(key: string, data: T) => {
    try {
      localStorage.setItem(`rps_${key}`, JSON.stringify(data));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  };

  // State collections
  const [products, setProducts] = useState<Product[]>(() => loadStored('products', INITIAL_PRODUCTS));
  const [categories, setCategories] = useState<Category[]>(() => loadStored('categories', INITIAL_CATEGORIES));
  const [banners, setBanners] = useState<Banner[]>(() => loadStored('banners', INITIAL_BANNERS));
  const [orders, setOrders] = useState<Order[]>(() => loadStored('orders', INITIAL_ORDERS));
  const [customOrders, setCustomOrders] = useState<CustomOrder[]>(() => loadStored('custom_orders', INITIAL_CUSTOM_ORDERS));
  const [deliveryBoys, setDeliveryBoys] = useState<DeliveryBoy[]>(() => loadStored('delivery_boys', INITIAL_DELIVERY_BOYS));
  const [coupons, setCoupons] = useState<Coupon[]>(() => loadStored('coupons', INITIAL_COUPONS));
  const [reviews, setReviews] = useState<CustomerReview[]>(() => loadStored('reviews', INITIAL_REVIEWS));
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => loadStored('notifications', INITIAL_NOTIFICATIONS));
  const [settings, setSettings] = useState<WebsiteSettings>(() => loadStored('settings', INITIAL_SETTINGS));
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>(() => loadStored('recently_viewed', []));

  // User & Auth
  const [user, setUser] = useState<UserProfile>(() =>
    loadStored('user', {
      name: 'Rahul Sharma',
      mobile: '9839012345',
      email: 'rahul.sharma@example.com',
      role: 'customer',
      address: {
        house: 'Flat 402, Green Valley Apts',
        street: 'Kapoorthala Road',
        area: 'Aliganj',
        city: 'Lucknow',
        state: 'Uttar Pradesh',
        pinCode: '226024',
      },
    })
  );
  const [adminLoggedIn, setAdminLoggedIn] = useState<boolean>(() => loadStored('admin_auth', false));
  const [deliveryBoyLoggedIn, setDeliveryBoyLoggedIn] = useState<boolean>(() => loadStored('db_auth', false));
  const [currentDeliveryBoy, setCurrentDeliveryBoy] = useState<DeliveryBoy | null>(() => loadStored('current_db', null));

  // Cart & Wishlist
  const [cart, setCart] = useState<CartItem[]>(() => loadStored('cart', []));
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(() => loadStored('applied_coupon', null));
  const [wishlist, setWishlist] = useState<string[]>(() => loadStored('wishlist', ['RPS-PF-001', 'RPS-MG-002']));

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (title: string, message: string, type: Toast['type'] = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync to storage
  useEffect(() => saveStored('products', products), [products]);
  useEffect(() => saveStored('categories', categories), [categories]);
  useEffect(() => saveStored('banners', banners), [banners]);
  useEffect(() => saveStored('orders', orders), [orders]);
  useEffect(() => saveStored('custom_orders', customOrders), [customOrders]);
  useEffect(() => saveStored('delivery_boys', deliveryBoys), [deliveryBoys]);
  useEffect(() => saveStored('coupons', coupons), [coupons]);
  useEffect(() => saveStored('reviews', reviews), [reviews]);
  useEffect(() => saveStored('notifications', notifications), [notifications]);
  useEffect(() => saveStored('settings', settings), [settings]);
  useEffect(() => saveStored('recently_viewed', recentlyViewed), [recentlyViewed]);
  useEffect(() => saveStored('cart', cart), [cart]);
  useEffect(() => saveStored('wishlist', wishlist), [wishlist]);
  useEffect(() => saveStored('user', user), [user]);
  useEffect(() => saveStored('admin_auth', adminLoggedIn), [adminLoggedIn]);
  useEffect(() => saveStored('db_auth', deliveryBoyLoggedIn), [deliveryBoyLoggedIn]);
  useEffect(() => saveStored('current_db', currentDeliveryBoy), [currentDeliveryBoy]);

  // Track recently viewed products
  useEffect(() => {
    if (selectedProductId) {
      setRecentlyViewed((prev) => {
        const filtered = prev.filter((id) => id !== selectedProductId);
        return [selectedProductId, ...filtered].slice(0, 10);
      });
    }
  }, [selectedProductId]);

  // Cart operations
  const addToCart = (
    product: Product,
    quantity = 1,
    customization?: ProductCustomization,
    selectedSize?: string,
    selectedColor?: string
  ) => {
    let unitPrice = product.price;

    // Recalculate price if customized
    if (customization?.type === 'photo_frame' && customization.photoFrameConfig) {
      unitPrice = customization.photoFrameConfig.calculatedPrice;
    } else if (customization?.type === 'printing' && customization.printingConfig) {
      unitPrice = customization.printingConfig.calculatedPricePerUnit;
    }

    const newItemId = `${product.id}-${Date.now()}`;
    const newCartItem: CartItem = {
      cartItemId: newItemId,
      product,
      quantity,
      selectedSize: selectedSize || (product.availableSizes ? product.availableSizes[0] : undefined),
      selectedColor: selectedColor || (product.availableColors ? product.availableColors[0] : undefined),
      customization,
      unitPrice,
      totalPrice: unitPrice * quantity,
    };

    setCart((prev) => [...prev, newCartItem]);
    addToast('Added to Cart', `${product.name} has been added to your shopping cart.`);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
    addToast('Item Removed', 'Product removed from your cart.', 'info');
  };

  const updateCartQuantity = (cartItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.cartItemId === cartItemId) {
            const newQty = Math.max(1, Math.min(item.product.maxQuantity, item.quantity + delta));
            return {
              ...item,
              quantity: newQty,
              totalPrice: item.unitPrice * newQty,
            };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  // Cart price calculations
  const getCartSubtotal = () => {
    return cart.reduce((sum, item) => sum + item.totalPrice, 0);
  };

  const getCartDiscount = () => {
    const subtotal = getCartSubtotal();
    if (!appliedCoupon) return 0;
    if (subtotal < appliedCoupon.minOrder) return 0;

    if (appliedCoupon.discountType === 'flat') {
      return Math.min(appliedCoupon.value, subtotal);
    } else {
      const calc = (subtotal * appliedCoupon.value) / 100;
      return appliedCoupon.maxDiscount ? Math.min(calc, appliedCoupon.maxDiscount) : calc;
    }
  };

  const getCartDeliveryCharge = () => {
    const subtotal = getCartSubtotal();
    if (subtotal === 0) return 0;
    return subtotal >= settings.freeDeliveryThreshold ? 0 : settings.defaultDeliveryCharge;
  };

  const getCartGst = () => {
    const taxable = Math.max(0, getCartSubtotal() - getCartDiscount());
    return Math.round((taxable * (settings.gstRatePercentage / 100)) * 100) / 100;
  };

  const getCartGrandTotal = () => {
    const subtotal = getCartSubtotal();
    if (subtotal === 0) return 0;
    const discount = getCartDiscount();
    const delivery = getCartDeliveryCharge();
    const gst = getCartGst();
    return Math.max(0, Math.round(subtotal - discount + delivery + gst));
  };

  const applyCoupon = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const found = coupons.find((c) => c.code.toUpperCase() === cleanCode && c.active);
    if (!found) {
      return { success: false, message: 'Invalid or expired coupon code.' };
    }
    const subtotal = getCartSubtotal();
    if (subtotal < found.minOrder) {
      return {
        success: false,
        message: `Coupon requires a minimum order value of ₹${found.minOrder}. Add more items to apply!`,
      };
    }
    setAppliedCoupon(found);
    addToast('Coupon Applied!', `You saved ₹${found.discountType === 'flat' ? found.value : `${found.value}%`} on your order.`);
    return { success: true, message: `Coupon ${found.code} applied successfully!` };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    addToast('Coupon Removed', 'Coupon was removed from your cart.', 'info');
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      if (prev.includes(productId)) {
        addToast('Removed from Wishlist', 'Item removed from your wishlist.', 'info');
        return prev.filter((id) => id !== productId);
      } else {
        addToast('Saved to Wishlist', 'Item added to your wishlist.', 'success');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Authentication
  const loginUser = (profile: Partial<UserProfile>) => {
    setUser((prev) => ({
      ...prev,
      ...profile,
      role: 'customer',
    }));
    addToast('Welcome Back!', `Logged in as ${profile.name || user.name}.`);
  };

  const logoutUser = () => {
    setUser({
      name: 'Guest User',
      mobile: '',
      email: '',
      role: 'guest',
    });
    addToast('Logged Out', 'You have been signed out successfully.', 'info');
  };

  const loginAdmin = (password: string) => {
    // Admin password check: rpsadmin or 8090524232 or admin123
    if (password === 'rpsadmin' || password === '8090524232' || password === 'admin123') {
      setAdminLoggedIn(true);
      addToast('Admin Authenticated', 'Welcome to RPS A2Z Admin Control Center.');
      return true;
    }
    addToast('Authentication Failed', 'Invalid admin security credentials.', 'error');
    return false;
  };

  const logoutAdmin = () => {
    setAdminLoggedIn(false);
    addToast('Admin Logged Out', 'Admin session terminated.', 'info');
  };

  const loginDeliveryBoy = (userId: string, pin: string) => {
    const boy = deliveryBoys.find(
      (b) => b.userId.toLowerCase() === userId.toLowerCase() && (pin === '1234' || pin === 'delivery')
    );
    if (boy) {
      setDeliveryBoyLoggedIn(true);
      setCurrentDeliveryBoy(boy);
      addToast('Rider Logged In', `Welcome, ${boy.name}! Ready for deliveries.`);
      return true;
    }
    addToast('Login Failed', 'Invalid Rider ID or Security PIN.', 'error');
    return false;
  };

  const logoutDeliveryBoy = () => {
    setDeliveryBoyLoggedIn(false);
    setCurrentDeliveryBoy(null);
    addToast('Rider Logged Out', 'Rider session ended.', 'info');
  };

  // Order Placement
  const placeOrder = (orderData: Omit<Order, 'id' | 'createdAt' | 'trackingHistory'>): Order => {
    const orderIndex = orders.length + 1;
    const orderId = `ORDRPS${orderIndex.toString().padStart(6, '0')}`;
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const formattedTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    // Generate random 4-digit OTP for delivery verification
    const deliveryOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const newOrder: Order = {
      ...orderData,
      id: orderId,
      createdAt: now.toISOString(),
      deliveryOtp,
      trackingHistory: [
        {
          status: 'Order Placed',
          date: formattedDate,
          time: formattedTime,
          message: 'Order received and logged into RPS A2Z system.',
          completed: true,
          isCurrent: true,
        },
      ],
    };

    // Auto reduce inventory
    setProducts((prev) =>
      prev.map((prod) => {
        const orderItem = orderData.items.find((it) => it.product.id === prod.id);
        if (orderItem) {
          return {
            ...prod,
            stock: Math.max(0, prod.stock - orderItem.quantity),
          };
        }
        return prod;
      })
    );

    setOrders((prev) => [newOrder, ...prev]);

    // Send notification
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}`,
        title: 'Order Confirmed!',
        message: `Your order #${orderId} for ₹${newOrder.grandTotal} has been successfully placed.`,
        date: 'Just now',
        read: false,
        type: 'order',
        relatedId: orderId,
      },
      ...prev,
    ]);

    clearCart();
    setActiveTrackingOrderId(orderId);
    setCurrentPage('order-success');
    addToast('Order Placed Successfully!', `Order ID: ${orderId}. Estimated delivery in 2-3 days.`);
    return newOrder;
  };

  const submitCustomOrder = (data: Omit<CustomOrder, 'id' | 'createdAt' | 'status'>): CustomOrder => {
    const index = customOrders.length + 1;
    const customOrderId = `CUS${index.toString().padStart(6, '0')}`;

    const newCustomOrder: CustomOrder = {
      ...data,
      id: customOrderId,
      createdAt: new Date().toISOString(),
      status: 'Received',
    };

    setCustomOrders((prev) => [newCustomOrder, ...prev]);
    addToast('Custom Requirement Submitted!', `Order ID: ${customOrderId}. Our team will call you within 2 hours.`);
    return newCustomOrder;
  };

  const approveDesignProof = (orderId: string, comment?: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId && order.designProof) {
          const now = new Date();
          const formattedDate = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
          const formattedTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

          const updatedProof = {
            ...order.designProof,
            status: 'Approved' as const,
            customerComment: comment,
            respondedAt: `${formattedDate} ${formattedTime}`,
          };

          const newHistory = [
            ...order.trackingHistory.map((s) => ({ ...s, isCurrent: false })),
            {
              status: 'Design Approved' as OrderStatus,
              date: formattedDate,
              time: formattedTime,
              message: 'Customer approved design proof. Moving to production queue.',
              completed: true,
              isCurrent: false,
            },
            {
              status: 'Printing Started' as OrderStatus,
              date: formattedDate,
              time: formattedTime,
              message: 'Production started on high-precision digital machines.',
              completed: true,
              isCurrent: true,
            },
          ];

          return {
            ...order,
            orderStatus: 'Printing Started',
            designProof: updatedProof,
            trackingHistory: newHistory,
          };
        }
        return order;
      })
    );
    addToast('Design Approved!', 'Printing has started. We will notify you once dispatched.');
  };

  const requestDesignChanges = (orderId: string, comment: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId && order.designProof) {
          return {
            ...order,
            orderStatus: 'Design Pending',
            designProof: {
              ...order.designProof,
              status: 'Changes Requested',
              customerComment: comment,
              respondedAt: new Date().toLocaleString(),
            },
          };
        }
        return order;
      })
    );
    addToast('Change Request Sent', 'Our designer will revise your proof and re-upload soon.', 'info');
  };

  const cancelCustomerOrder = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          const now = new Date();
          return {
            ...order,
            orderStatus: 'Cancelled',
            adminRemarks: `Cancelled by customer. Reason: ${reason}`,
            trackingHistory: [
              ...order.trackingHistory.map((h) => ({ ...h, isCurrent: false })),
              {
                status: 'Cancelled' as OrderStatus,
                date: now.toLocaleDateString(),
                time: now.toLocaleTimeString(),
                message: `Order cancelled. Reason: ${reason}`,
                completed: true,
                isCurrent: true,
              },
            ],
          };
        }
        return order;
      })
    );
    addToast('Order Cancelled', `Order #${orderId} was cancelled.`, 'info');
  };

  // Admin Actions
  const addProduct = (productData: Omit<Product, 'id'>) => {
    const id = `RPS-${Date.now().toString().slice(-4)}`;
    const newProduct: Product = {
      ...productData,
      id,
    };
    setProducts((prev) => [newProduct, ...prev]);
    addToast('Product Added', `${newProduct.name} is now live in store!`);
  };

  const updateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    addToast('Product Updated', `Saved changes for ${updated.name}.`);
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    addToast('Product Deleted', 'Product removed from store catalog.', 'info');
  };

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus, adminRemark?: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          const now = new Date();
          const formattedDate = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
          const formattedTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

          const newStep = {
            status: newStatus,
            date: formattedDate,
            time: formattedTime,
            message: adminRemark || `Status progressed to ${newStatus}`,
            completed: true,
            isCurrent: true,
          };

          return {
            ...order,
            orderStatus: newStatus,
            adminRemarks: adminRemark ? `${order.adminRemarks ? `${order.adminRemarks} | ` : ''}${adminRemark}` : order.adminRemarks,
            trackingHistory: [...order.trackingHistory.map((h) => ({ ...h, isCurrent: false })), newStep],
          };
        }
        return order;
      })
    );
    addToast('Status Updated', `Order #${orderId} status changed to ${newStatus}.`);
  };

  const assignDeliveryBoy = (orderId: string, boyId: string) => {
    const boy = deliveryBoys.find((b) => b.id === boyId);
    if (!boy) return;

    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          const now = new Date();
          return {
            ...order,
            assignedDeliveryBoyId: boy.id,
            assignedDeliveryBoyName: boy.name,
            orderStatus: 'Assigned To Delivery Boy' as OrderStatus,
            trackingHistory: [
              ...order.trackingHistory.map((h) => ({ ...h, isCurrent: false })),
              {
                status: 'Assigned To Delivery Boy' as OrderStatus,
                date: now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
                time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
                message: `Assigned to delivery agent ${boy.name} (Mobile: ${boy.mobile})`,
                completed: true,
                isCurrent: true,
              },
            ],
          };
        }
        return order;
      })
    );

    // Increment boy's assigned count
    setDeliveryBoys((prev) =>
      prev.map((b) => (b.id === boyId ? { ...b, assignedOrderCount: b.assignedOrderCount + 1 } : b))
    );

    addToast('Delivery Boy Assigned', `Order #${orderId} assigned to ${boy.name}.`);
  };

  const uploadDesignProof = (orderId: string, proofUrl: string, adminNote?: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          const now = new Date();
          const formattedDate = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
          const formattedTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

          const newProof = {
            proofId: `PRF-${Date.now()}`,
            proofUrl,
            uploadedAt: `${formattedDate} ${formattedTime}`,
            adminNote: adminNote || 'Please review your design layout proof.',
            status: 'Pending Customer Approval' as const,
          };

          return {
            ...order,
            orderStatus: 'Design Ready' as OrderStatus,
            designProof: newProof,
            trackingHistory: [
              ...order.trackingHistory.map((h) => ({ ...h, isCurrent: false })),
              {
                status: 'Design Ready' as OrderStatus,
                date: formattedDate,
                time: formattedTime,
                message: 'Design layout proof uploaded by RPS designer. Awaiting customer confirmation.',
                completed: true,
                isCurrent: true,
              },
            ],
          };
        }
        return order;
      })
    );
    addToast('Proof Uploaded', `Design proof sent to customer for Order #${orderId}.`);
  };

  const quoteCustomOrder = (customOrderId: string, quotePrice: number, adminRemark: string) => {
    setCustomOrders((prev) =>
      prev.map((c) =>
        c.id === customOrderId
          ? {
              ...c,
              status: 'Quoted',
              quotedPrice: quotePrice,
              adminRemark,
            }
          : c
      )
    );
    addToast('Custom Order Quoted', `Quotation of ₹${quotePrice} saved for ${customOrderId}.`);
  };

  const convertCustomOrderToNormalOrder = (customOrderId: string): Order => {
    const custom = customOrders.find((c) => c.id === customOrderId);
    if (!custom) throw new Error('Custom order not found');

    const amount = custom.quotedPrice || custom.budget || 500;
    const normalOrder = placeOrder({
      customerName: custom.customerName,
      customerMobile: custom.customerMobile,
      customerEmail: custom.customerEmail,
      customerAddress: {
        fullName: custom.customerName,
        mobile: custom.customerMobile,
        email: custom.customerEmail,
        house: 'Custom Location',
        street: custom.deliveryAddress,
        area: 'Standard',
        city: 'Lucknow',
        district: 'Lucknow',
        state: 'Uttar Pradesh',
        pinCode: '226001',
      },
      billingAddressSameAsShipping: true,
      items: [
        {
          cartItemId: `custom-item-${Date.now()}`,
          product: {
            id: `PRD-CUSTOM-${Date.now()}`,
            sku: 'RPS-CUSTOM-SPEC',
            name: `[Custom Order] ${custom.serviceOrProductName}`,
            category: custom.category,
            mrp: Math.round(amount * 1.3),
            price: amount,
            discountPercentage: 20,
            rating: 5,
            reviewsCount: 1,
            stock: 99,
            minQuantity: 1,
            maxQuantity: 100,
            images: [
              custom.attachmentDataUrl ||
                'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&auto=format&fit=crop&q=80',
            ],
            description: custom.orderDescription,
            features: ['Customized specifications as per client agreement'],
            specifications: {
              'Required Size': custom.requiredSize,
              'Required Date': custom.requiredDate,
              'Quantity': custom.requiredQuantity.toString(),
            },
            isCustomizable: true,
            customizationType: 'standard_custom',
            deliveryDays: 3,
          },
          quantity: custom.requiredQuantity,
          unitPrice: Math.round(amount / custom.requiredQuantity),
          totalPrice: amount,
        },
      ],
      subtotal: amount,
      discount: 0,
      deliveryCharge: 0,
      gstAmount: Math.round(amount * 0.18),
      grandTotal: Math.round(amount * 1.18),
      paymentMethod: 'COD',
      paymentStatus: 'Pending',
      orderStatus: 'Order Accepted',
      expectedDeliveryDate: custom.requiredDate || 'Within 3 days',
    });

    setCustomOrders((prev) =>
      prev.map((c) => (c.id === customOrderId ? { ...c, status: 'Converted to Order', convertedOrderId: normalOrder.id } : c))
    );

    addToast('Converted to Normal Order', `Custom requirement converted to Order #${normalOrder.id}!`);
    return normalOrder;
  };

  const updateSettings = (newSettings: WebsiteSettings) => {
    setSettings(newSettings);
    addToast('Settings Saved', 'Business configuration updated successfully.');
  };

  const addDeliveryBoy = (boyData: Omit<DeliveryBoy, 'id' | 'assignedOrderCount'>) => {
    const id = `DB-${(deliveryBoys.length + 1).toString().padStart(2, '0')}`;
    const newBoy: DeliveryBoy = {
      ...boyData,
      id,
      assignedOrderCount: 0,
    };
    setDeliveryBoys((prev) => [...prev, newBoy]);
    addToast('Delivery Boy Added', `${newBoy.name} added to rider team.`);
  };

  const updateDeliveryBoy = (boy: DeliveryBoy) => {
    setDeliveryBoys((prev) => prev.map((b) => (b.id === boy.id ? boy : b)));
    addToast('Rider Updated', `Updated profile of ${boy.name}.`);
  };

  const deleteDeliveryBoy = (boyId: string) => {
    setDeliveryBoys((prev) => prev.filter((b) => b.id !== boyId));
    addToast('Rider Removed', 'Delivery boy record deleted.', 'info');
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [...prev, coupon]);
    addToast('Coupon Created', `Coupon code ${coupon.code} is now active.`);
  };

  const toggleCoupon = (code: string) => {
    setCoupons((prev) => prev.map((c) => (c.code === code ? { ...c, active: !c.active } : c)));
  };

  const addBanner = (bannerData: Omit<Banner, 'id'>) => {
    const id = `ban-${Date.now()}`;
    setBanners((prev) => [...prev, { ...bannerData, id }]);
    addToast('Banner Added', 'New promotional banner is now live on homepage.');
  };

  const toggleBanner = (id: string) => {
    setBanners((prev) => prev.map((b) => (b.id === id ? { ...b, active: !b.active } : b)));
  };

  const moderateReview = (reviewId: string, approved: boolean) => {
    setReviews((prev) => prev.map((r) => (r.id === reviewId ? { ...r, approved } : r)));
    addToast('Review Moderated', approved ? 'Review has been approved and published.' : 'Review rejected.', 'info');
  };

  const submitReview = (reviewData: Omit<CustomerReview, 'id' | 'date' | 'approved'>) => {
    const newReview: CustomerReview = {
      ...reviewData,
      id: `REV-${Date.now()}`,
      date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      approved: true, // auto approve in preview
    };
    setReviews((prev) => [newReview, ...prev]);
    addToast('Review Submitted', 'Thank you for your valuable feedback!');
  };

  // Delivery OTP confirmation
  const confirmDeliveryWithOtp = (orderId: string, enteredOtp: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, message: 'Order not found' };

    if (order.deliveryOtp && order.deliveryOtp !== enteredOtp.trim()) {
      return { success: false, message: 'Invalid OTP! Please ask customer for correct 4-digit OTP.' };
    }

    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const formattedTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            orderStatus: 'Delivered',
            paymentStatus: o.paymentMethod === 'COD' ? 'Paid' : o.paymentStatus,
            trackingHistory: [
              ...o.trackingHistory.map((h) => ({ ...h, isCurrent: false })),
              {
                status: 'Delivered' as OrderStatus,
                date: formattedDate,
                time: formattedTime,
                message: 'Product handed over to customer. Verified via OTP.',
                completed: true,
                isCurrent: true,
              },
            ],
          };
        }
        return o;
      })
    );

    addToast('Delivery Confirmed!', `Order #${orderId} marked as successfully delivered.`);
    return { success: true, message: 'Delivery successfully verified with OTP!' };
  };

  return (
    <StoreContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        selectedProductId,
        setSelectedProductId,
        selectedCategoryId,
        setSelectedCategoryId,
        activeTrackingOrderId,
        setActiveTrackingOrderId,
        searchQuery,
        setSearchQuery,
        deliveryPincode,
        setDeliveryPincode,
        currentLanguage,
        setCurrentLanguage,
        products,
        categories,
        banners,
        orders,
        customOrders,
        deliveryBoys,
        coupons,
        reviews,
        notifications,
        settings,
        recentlyViewed,
        cart,
        appliedCoupon,
        wishlist,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        applyCoupon,
        removeCoupon,
        toggleWishlist,
        isInWishlist,
        getCartSubtotal,
        getCartDiscount,
        getCartDeliveryCharge,
        getCartGst,
        getCartGrandTotal,
        user,
        loginUser,
        logoutUser,
        adminLoggedIn,
        loginAdmin,
        logoutAdmin,
        deliveryBoyLoggedIn,
        currentDeliveryBoy,
        loginDeliveryBoy,
        logoutDeliveryBoy,
        placeOrder,
        submitCustomOrder,
        approveDesignProof,
        requestDesignChanges,
        cancelCustomerOrder,
        addProduct,
        updateProduct,
        deleteProduct,
        updateOrderStatus,
        assignDeliveryBoy,
        uploadDesignProof,
        quoteCustomOrder,
        convertCustomOrderToNormalOrder,
        updateSettings,
        addDeliveryBoy,
        updateDeliveryBoy,
        deleteDeliveryBoy,
        addCoupon,
        toggleCoupon,
        addBanner,
        toggleBanner,
        moderateReview,
        submitReview,
        confirmDeliveryWithOtp,
        toasts,
        addToast,
        removeToast,
        quickViewProduct,
        setQuickViewProduct,
        isLocationModalOpen,
        setIsLocationModalOpen,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
};
